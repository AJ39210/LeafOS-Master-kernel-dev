#ifndef _LEAFOS_NET_H
#define _LEAFOS_NET_H

#include <stdint.h>

typedef struct {
    uint8_t mac[6];
} mac_addr_t;

typedef struct {
    uint8_t addr[4];
} ipv4_addr_t;

typedef struct {
    uint8_t addr[16];
} ipv6_addr_t;

typedef struct net_interface {
    char name[16];
    mac_addr_t mac;
    ipv4_addr_t ipv4;
    void (*send_packet)(struct net_interface* iface, uint8_t* data, uint32_t len);
    struct net_interface* next;
} net_interface_t;

void net_init(void);
void net_register_interface(net_interface_t* iface);
void net_receive_packet(net_interface_t* iface, uint8_t* data, uint32_t len);

/* Security Hook */
bool net_is_address_blocked(ipv4_addr_t addr);

#endif