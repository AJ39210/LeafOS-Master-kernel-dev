;
; LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
; 
; 1. SHARE ALIKE: This program is free software. If you modify this 
;    code and distribute it, you MUST provide the source code of your 
;    changes under this same license. 
; 
; 2. NO WARRANTY: This program is distributed in the hope that it will 
;    be useful, but WITHOUT ANY WARRANTY; without even the implied 
;    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
;
; 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
;    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
;    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
;
; Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
;

MBALIGN  equ 1<<0              ; Align loaded modules on page boundaries
MEMINFO  equ 1<<1              ; Provide memory map to kernel
FLAGS    equ MBALIGN | MEMINFO ; This is the Multiboot 'flag' field
MAGIC    equ 0x1BADB002        ; 'magic' field
CHECKSUM equ -(MAGIC + FLAGS)  ; 'checksum' field (magic + flags + checksum == 0)

; The Multiboot header. GRUB will look for this.
section .multiboot
    align 4
    dd MAGIC
    dd FLAGS
    dd CHECKSUM

section .text
global _start
extern kmain

_start:
    ; Set up the stack pointer
    mov esp, stack_top

    ; Call the main kernel function
    call kmain

    ; If kmain returns, halt the system
    cli
.loop:
    hlt
    jmp .loop

section .bss
align 16
stack_bottom:
    resb 16384 ; 16 KB stack
stack_top:

; Fix for "missing .note.GNU-stack section" warning
section .note.GNU-stack noalloc noexec nowrite progbits