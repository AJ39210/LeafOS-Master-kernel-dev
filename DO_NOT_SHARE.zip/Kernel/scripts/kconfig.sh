#!/bin/bash
# ============================================================================
# LeafOS Kernel Configuration Menu (menuconfig-style)
# ============================================================================

CONFIG_FILE=".config"
CONFIG_BAK=".config.bak"
TEMP_FILE="/tmp/leafos_config.tmp"

# Check if we have dialog or whiptail
if command -v dialog &> /dev/null; then
	DIALOG="dialog"
elif command -v whiptail &> /dev/null; then
	DIALOG="whiptail"
else
	DIALOG=""
fi

# Backup current config
if [ -f "$CONFIG_FILE" ]; then
	cp "$CONFIG_FILE" "$CONFIG_BAK"
fi

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Load current config
load_config() {
	[ -f "$CONFIG_FILE" ] && source "$CONFIG_FILE"
}

# Save config
save_config() {
	cat > "$CONFIG_FILE" << EOF
# ============================================================================
# LeafOS Kernel Configuration
# ============================================================================
# This file is auto-generated. Manual editing is discouraged.

# Kernel Information
KERNEL_NAME="$KERNEL_NAME"
KERNEL_VERSION="$KERNEL_VERSION"
KERNEL_CODENAME="$KERNEL_CODENAME"
BUILD_NUMBER=$BUILD_NUMBER

# OS Information
OS_NAME="$OS_NAME"
BOOT_BANNER="$BOOT_BANNER"

# Drivers
CONFIG_ENABLE_PS2_KEYBOARD=$CONFIG_ENABLE_PS2_KEYBOARD
CONFIG_ENABLE_VGA_FRAMEBUFFER=$CONFIG_ENABLE_VGA_FRAMEBUFFER
CONFIG_ENABLE_E1000_NETWORK=$CONFIG_ENABLE_E1000_NETWORK
CONFIG_ENABLE_I40E_NETWORK=$CONFIG_ENABLE_I40E_NETWORK

# Filesystems
CONFIG_ENABLE_EXT_FS=$CONFIG_ENABLE_EXT_FS
CONFIG_ENABLE_FAT_FS=$CONFIG_ENABLE_FAT_FS
CONFIG_ENABLE_NTFS_FS=$CONFIG_ENABLE_NTFS_FS
CONFIG_ENABLE_LFSFS=$CONFIG_ENABLE_LFSFS

# Security
CONFIG_ENABLE_SELEAF=$CONFIG_ENABLE_SELEAF
CONFIG_ENABLE_SANDBOX=$CONFIG_ENABLE_SANDBOX
CONFIG_ENABLE_CERTS=$CONFIG_ENABLE_CERTS
EOF
	echo -e "${GREEN}✓ Configuration saved${NC}"
}

# Toggle yes/no
toggle_option() {
	if [ "$1" == "y" ]; then
		echo "n"
	else
		echo "y"
	fi
}

# Text-based menu (fallback if dialog not available)
text_menu() {
	clear
	echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
	echo -e "${BLUE}║        LeafOS Kernel Configuration Menu (menuconfig)       ║${NC}"
	echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
	echo ""
	echo "  1) Kernel Settings"
	echo "  2) Drivers"
	echo "  3) Filesystems"
	echo "  4) Security"
	echo ""
	echo "  S) Save & Exit"
	echo "  Q) Quit without saving"
	echo "  R) Restore from backup"
	echo ""
	echo -n "Choose option: "
}

# Kernel settings submenu
kernel_menu() {
	while true; do
		clear
		echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
		echo -e "${BLUE}║           Kernel Information Settings                      ║${NC}"
		echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
		echo ""
		echo "  1) Kernel Name            : $KERNEL_NAME"
		echo "  2) Kernel Version         : $KERNEL_VERSION"
		echo "  3) Kernel Codename        : $KERNEL_CODENAME"
		echo "  4) Build Number           : $BUILD_NUMBER"
		echo "  5) OS Name                : $OS_NAME"
		echo ""
		echo "  B) Back to main menu"
		echo ""
		echo -n "Choose option: "
		read opt
		
		case $opt in
			1)
				echo -n "Enter Kernel Name [$KERNEL_NAME]: "
				read val
				[ -n "$val" ] && KERNEL_NAME="$val"
				;;
			2)
				echo -n "Enter Kernel Version [$KERNEL_VERSION]: "
				read val
				[ -n "$val" ] && KERNEL_VERSION="$val"
				;;
			3)
				echo -n "Enter Kernel Codename [$KERNEL_CODENAME]: "
				read val
				[ -n "$val" ] && KERNEL_CODENAME="$val"
				;;
			4)
				echo -n "Enter Build Number [$BUILD_NUMBER]: "
				read val
				[ -n "$val" ] && BUILD_NUMBER="$val"
				;;
			5)
				echo -n "Enter OS Name [$OS_NAME]: "
				read val
				[ -n "$val" ] && OS_NAME="$val"
				;;
			B|b)
				break
				;;
		esac
	done
}

# Drivers submenu
drivers_menu() {
	while true; do
		clear
		echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
		echo -e "${BLUE}║               Drivers Configuration                       ║${NC}"
		echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
		echo ""
		echo "  1) PS/2 Keyboard Driver      [$([ "$CONFIG_ENABLE_PS2_KEYBOARD" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  2) VGA Framebuffer Driver    [$([ "$CONFIG_ENABLE_VGA_FRAMEBUFFER" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  3) Intel E1000 Network       [$([ "$CONFIG_ENABLE_E1000_NETWORK" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  4) Intel i40e Network        [$([ "$CONFIG_ENABLE_I40E_NETWORK" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo ""
		echo "  B) Back to main menu"
		echo ""
		echo -n "Choose option: "
		read opt
		
		case $opt in
			1) CONFIG_ENABLE_PS2_KEYBOARD=$(toggle_option $CONFIG_ENABLE_PS2_KEYBOARD) ;;
			2) CONFIG_ENABLE_VGA_FRAMEBUFFER=$(toggle_option $CONFIG_ENABLE_VGA_FRAMEBUFFER) ;;
			3) CONFIG_ENABLE_E1000_NETWORK=$(toggle_option $CONFIG_ENABLE_E1000_NETWORK) ;;
			4) CONFIG_ENABLE_I40E_NETWORK=$(toggle_option $CONFIG_ENABLE_I40E_NETWORK) ;;
			B|b) break ;;
		esac
	done
}

# Filesystems submenu
filesystems_menu() {
	while true; do
		clear
		echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
		echo -e "${BLUE}║             Filesystems Configuration                     ║${NC}"
		echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
		echo ""
		echo "  1) Ext Filesystem            [$([ "$CONFIG_ENABLE_EXT_FS" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  2) FAT Filesystem            [$([ "$CONFIG_ENABLE_FAT_FS" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  3) NTFS Filesystem           [$([ "$CONFIG_ENABLE_NTFS_FS" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  4) LeafOS LFS Filesystem     [$([ "$CONFIG_ENABLE_LFSFS" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo ""
		echo "  B) Back to main menu"
		echo ""
		echo -n "Choose option: "
		read opt
		
		case $opt in
			1) CONFIG_ENABLE_EXT_FS=$(toggle_option $CONFIG_ENABLE_EXT_FS) ;;
			2) CONFIG_ENABLE_FAT_FS=$(toggle_option $CONFIG_ENABLE_FAT_FS) ;;
			3) CONFIG_ENABLE_NTFS_FS=$(toggle_option $CONFIG_ENABLE_NTFS_FS) ;;
			4) CONFIG_ENABLE_LFSFS=$(toggle_option $CONFIG_ENABLE_LFSFS) ;;
			B|b) break ;;
		esac
	done
}

# Security submenu
security_menu() {
	while true; do
		clear
		echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
		echo -e "${BLUE}║              Security Configuration                      ║${NC}"
		echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
		echo ""
		echo "  1) SELeaf Security          [$([ "$CONFIG_ENABLE_SELEAF" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  2) Process Sandbox Support  [$([ "$CONFIG_ENABLE_SANDBOX" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo "  3) Certificate Support     [$([ "$CONFIG_ENABLE_CERTS" = "y" ] && echo -e "${GREEN}●${NC}" || echo -e "${RED}○${NC}")]"
		echo ""
		echo "  B) Back to main menu"
		echo ""
		echo -n "Choose option: "
		read opt
		
		case $opt in
			1) CONFIG_ENABLE_SELEAF=$(toggle_option $CONFIG_ENABLE_SELEAF) ;;
			2) CONFIG_ENABLE_SANDBOX=$(toggle_option $CONFIG_ENABLE_SANDBOX) ;;
			3) CONFIG_ENABLE_CERTS=$(toggle_option $CONFIG_ENABLE_CERTS) ;;
			B|b) break ;;
		esac
	done
}

# Main loop
load_config

while true; do
	text_menu
	read option
	
	case $option in
		1) kernel_menu ;;
		2) drivers_menu ;;
		3) filesystems_menu ;;
		4) security_menu ;;
		S|s)
			save_config
			echo -e "${GREEN}Configuration saved. Exiting...${NC}"
			sleep 1
			exit 0
			;;
		Q|q)
			echo -e "${YELLOW}Exiting without saving...${NC}"
			exit 1
			;;
		R|r)
			if [ -f "$CONFIG_BAK" ]; then
				cp "$CONFIG_BAK" "$CONFIG_FILE"
				load_config
				echo -e "${GREEN}✓ Restored from backup${NC}"
			else
				echo -e "${RED}No backup found${NC}"
			fi
			sleep 1
			;;
		*)
			echo -e "${RED}Invalid option${NC}"
			sleep 1
			;;
	esac
done
