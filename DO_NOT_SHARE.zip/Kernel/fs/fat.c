/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <fat.h>
#include <kernel.h>
#include <string.h>
#include <block.h>

fs_node_t *fat_init(uint32_t device_id) {
    uint8_t buffer[512];
    
    /* 1. Read the BPB from the device */
    if (block_read(device_id, 0, 1, buffer) != 0) return NULL;
    fat_bpb_t *bpb = (fat_bpb_t*)buffer;

    /* 2. Determine if it's FAT12, 16, or 32 based on cluster count */
    uint32_t total_sectors = (bpb->total_sectors_16 == 0) ? bpb->total_sectors_32 : bpb->total_sectors_16;
    uint32_t fat_size = (bpb->table_size_16 == 0) ? ((fat32_ext_bpb_t*)((uint8_t*)bpb + 36))->table_size_32 : bpb->table_size_16;
    uint32_t root_dir_sectors = ((bpb->root_entry_count * 32) + (bpb->bytes_per_sector - 1)) / bpb->bytes_per_sector;
    uint32_t data_sectors = total_sectors - (bpb->reserved_sector_count + (bpb->table_count * fat_size) + root_dir_sectors);
    uint32_t cluster_count = data_sectors / bpb->sectors_per_cluster;

    fs_node_t *root_node = (fs_node_t*)kmalloc(sizeof(fs_node_t));
    memset(root_node, 0, sizeof(fs_node_t));
    
    if (cluster_count < 4085) root_node->flags = FS_FAT12;
    else if (cluster_count < 65525) root_node->flags = FS_FAT16;
    else root_node->flags = FS_FAT32;

    /* 3. Create and return a VFS node for the root directory */
    root_node->name[0] = '/';
    root_node->mask = root_node->uid = root_node->gid = 0;
    root_node->inode = 0;
    root_node->flags |= FS_DIRECTORY;
    
    return root_node; 
}

int fat_format(uint32_t device_id, uint64_t total_sectors, uint32_t block_size) {
    if (block_size != 512) { // FAT typically uses 512-byte sectors
        return -1;
    }

    uint8_t buffer[512];
    memset(buffer, 0, 512);
    fat_bpb_t *bpb = (fat_bpb_t*)buffer;
    fat32_ext_bpb_t *ext32 = (fat32_ext_bpb_t*)(buffer + 36);

    // Basic FAT16/FAT32 setup (simplified)
    bpb->bytes_per_sector = 512;
    bpb->sectors_per_cluster = 8; // 4KB clusters
    bpb->reserved_sector_count = 32; // For FAT32, usually 32
    bpb->table_count = 2;
    bpb->root_entry_count = 0; // For FAT32, root directory is a cluster chain
    bpb->total_sectors_16 = 0; // Use total_sectors_32 for large disks
    bpb->media_type = 0xF8; // Hard disk

    uint32_t data_sectors = total_sectors - (bpb->reserved_sector_count + (bpb->table_count * ext32->table_size_32));
    uint32_t cluster_count = data_sectors / bpb->sectors_per_cluster;

    // Determine FAT type (simplified logic)
    if (cluster_count < 4085) {
        // FAT12 (not fully supported here)
        return -1;
    } else if (cluster_count < 65525) {
        // FAT16
        bpb->table_size_16 = (total_sectors / (bpb->sectors_per_cluster * 256)) + 1; // Estimate
        bpb->total_sectors_16 = total_sectors;
        // ... other FAT16 specific fields
    } else {
        // FAT32
        ext32->table_size_32 = (total_sectors / (bpb->sectors_per_cluster * 256)) + 1; // Estimate
        ext32->root_cluster = 2; // First data cluster
        // ... other FAT32 specific fields
    }

    // Fill in common fields
    bpb->bootjmp[0] = 0xEB;
    bpb->bootjmp[1] = 0x58;
    bpb->bootjmp[2] = 0x90;
    memcpy(bpb->oem_name, "MSWIN4.1", 8);
    
    // Write BPB
    if (block_write(device_id, 0, 1, buffer) != 0) return -1;

    // Write empty FATs (zero out FAT tables)
    uint8_t zero_sector[512];
    memset(zero_sector, 0, 512);
    for (uint32_t i = 0; i < bpb->table_count * ext32->table_size_32; i++) {
        if (block_write(device_id, bpb->reserved_sector_count + i, 1, zero_sector) != 0) return -1;
    }

    // TODO: Initialize root directory for FAT16 or first cluster for FAT32
    return 0;
}