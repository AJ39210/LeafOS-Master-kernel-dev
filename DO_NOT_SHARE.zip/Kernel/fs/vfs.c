/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <vfs.h>
#include <kernel.h>
#include <string.h> // For strcmp
#include <fat.h>    // For fat_format
#include <ext.h>    // For ext_format
#include <lfsfs.h>
#include <ntfs.h>

fs_node_t *fs_root = NULL;

uint32_t vfs_read(fs_node_t *node, uint64_t offset, uint32_t size, uint8_t *buffer) {
    if (node && node->read) {
        return node->read(node, offset, size, buffer);
    }
    return 0;
}

uint32_t vfs_write(fs_node_t *node, uint64_t offset, uint32_t size, uint8_t *buffer) {
    if (node && node->write) {
        return node->write(node, offset, size, buffer);
    }
    return 0;
}

void vfs_open(fs_node_t *node, uint8_t read, uint8_t write) {
    if (node && node->open) {
        node->open(node);
    }
}

void vfs_close(fs_node_t *node) {
    if (node && node->close) {
        node->close(node);
    }
}

struct dirent *vfs_readdir(fs_node_t *node, uint32_t index) {
    if (node && (node->flags & FS_DIRECTORY) && node->readdir) {
        return node->readdir(node, index);
    }
    return NULL;
}

int vfs_format(uint32_t device_id, const char* fs_type, uint64_t total_sectors, uint32_t block_size) {
    if (!fs_type) return -1;

    if (strcmp(fs_type, "FAT") == 0) {
        return fat_format(device_id, total_sectors, block_size);
    } else if (strcmp(fs_type, "EXT") == 0) {
        return ext_format(device_id, total_sectors, block_size);
    } else if (strcmp(fs_type, "LFSFS") == 0) {
        return lfsfs_format(device_id, total_sectors, block_size);
    } else if (strcmp(fs_type, "NTFS") == 0) {
        return ntfs_format(device_id, total_sectors, block_size);
    }
    return -1; // Unknown filesystem type
}