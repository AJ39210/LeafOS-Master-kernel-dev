/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <ext.h>
#include <kernel.h>
#include <string.h>
#include <block.h>
#include <stdbool.h>

#define EXT_MAGIC 0xEF53

fs_node_t *ext_init(uint32_t device_id) {
    uint8_t buffer[1024];
    
    /* 1. Read Superblock at offset 1024 */
    if (block_read(device_id, 2, 2, buffer) != 0) return NULL;
    ext_superblock_t *sb = (ext_superblock_t*)buffer;

    /* 2. Check s_magic == 0xEF53 */
    if (sb->s_magic != EXT_MAGIC) return NULL;

    /* 3. Check feature flags to differentiate ext2, ext3 (journal), ext4 (extents) */
    (void)sb; // Placeholder for logic using feature flags

    /* 4. Return the root inode node */
    fs_node_t *root = (fs_node_t*)kmalloc(sizeof(fs_node_t));
    /* Setup root inode (usually inode 2) here */
    return root;
}

int ext_format(uint32_t device_id, uint64_t total_sectors, uint32_t block_size) {
    if (block_size < 1024 || block_size > 4096 || (block_size & (block_size - 1)) != 0) {
        // EXT filesystems typically use block sizes of 1024, 2048, or 4096 bytes
        return -1;
    }

    uint8_t buffer[block_size];
    memset(buffer, 0, block_size);
    ext_superblock_t *sb = (ext_superblock_t*)(buffer + 1024); // Superblock is at offset 1024 within the block

    // Basic EXT2/3/4 setup (simplified for EXT2)
    sb->s_inodes_count = (total_sectors * block_size / 4096) / 4; // Roughly 1 inode per 4KB of disk space
    sb->s_blocks_count = total_sectors * 512 / block_size;
    sb->s_r_blocks_count = sb->s_blocks_count / 20; // 5% reserved blocks
    sb->s_free_blocks_count = sb->s_blocks_count - sb->s_r_blocks_count;
    sb->s_free_inodes_count = sb->s_inodes_count;
    sb->s_first_data_block = (block_size == 1024) ? 1 : 0; // Block 0 for 2KB/4KB block sizes, Block 1 for 1KB
    sb->s_log_block_size = 0; // 1024 bytes
    if (block_size == 2048) sb->s_log_block_size = 1;
    if (block_size == 4096) sb->s_log_block_size = 2;

    sb->s_magic = EXT_MAGIC;
    sb->s_state = 1; // Cleanly unmounted
    sb->s_minor_rev_level = 0;
    sb->s_rev_level = 0;
    sb->s_def_resuid = 0;
    sb->s_def_resgid = 0;

    // Write Superblock
    if (block_write(device_id, 2, block_size / 512, buffer) != 0) return -1; // Superblock starts at sector 2 (1024 bytes)

    // TODO: Initialize Block Group Descriptors
    // TODO: Initialize Block Bitmap, Inode Bitmap, Inode Table
    // TODO: Create root directory inode (inode 2)

    return 0;
}