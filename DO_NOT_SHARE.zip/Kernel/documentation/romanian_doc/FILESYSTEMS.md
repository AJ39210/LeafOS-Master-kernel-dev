# Documentație Sisteme de Fișiere și Stocare

### /home/prede/LeafOS/Kernel/fs/vfs.c
- **Descriere**: Strat de abstracție Virtual File System.
- **Caracteristici**: Oferă o interfață unificată pentru interacțiunea cu diferite tipuri de sisteme de fișiere.

### /home/prede/LeafOS/Kernel/fs/fat.c
- **Descriere**: Implementare pentru familia FAT (FAT12, FAT16, FAT32).

### /home/prede/LeafOS/Kernel/fs/ext.c
- **Descriere**: Implementare pentru familia EXT (ext2/ext3/ext4).

### /home/prede/LeafOS/Kernel/include/block.c
- **Descriere**: Manager de dispozitive de tip Block. Gestionează discurile fizice și operațiunile I/O pe sectoare.