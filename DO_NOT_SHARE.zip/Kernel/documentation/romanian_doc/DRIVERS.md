# Documentație Subsistem Drivere

### /home/prede/LeafOS/Kernel/drivers/driver_daemon.c
- **Descriere**: Managerul central pentru toate driverele kernelului.
- **Caracteristici**: Gestionează înregistrarea, PID-urile și ciclul de viață al driverelor.
- **Securitate**: Necesită autorizare SELeaf înainte de înregistrare. Monitorizează driverul VGA și declanșează panică dacă acesta eșuează.

### /home/prede/LeafOS/Kernel/drivers/Framebuffer/vga/vga.c
- **Descriere**: Driver standard pentru modul text VGA (80x25).
- **Caracteristici**: Se ocupă de curățarea ecranului, afișarea caracterelor și scroll-ul automat.

### /home/prede/LeafOS/Kernel/drivers/input/ps2_keyboard.c
- **Descriere**: Driver complet pentru tastatură PS/2.
- **Caracteristici**: Traduce scancode-urile hardware în ASCII, gestionează Shift/Caps Lock și tastele de control precum Backspace.

### /home/prede/LeafOS/Kernel/drivers/sound/pc_speaker.c
- **Descriere**: Driver audio legacy folosind Programmable Interval Timer (PIT).
- **Caracteristici**: Generează frecvențe prin manipularea canalului 2 al PIT și a portului 0x61.

### /home/prede/LeafOS/Kernel/drivers/network/e1000/e1000.c
- **Descriere**: Driver pentru plăcile de rețea Intel 8254x Gigabit.

### /home/prede/LeafOS/Kernel/drivers/network/i40e/i40e.c
- **Descriere**: Driver pentru controllere Intel XL710 40GbE. Implementează mecanismul complex Admin Queue (AQ) pentru comunicarea cu firmware-ul.