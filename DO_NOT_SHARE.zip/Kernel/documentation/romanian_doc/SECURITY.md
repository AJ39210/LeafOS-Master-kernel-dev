# Documentație Securitate SELeaf

### /home/prede/LeafOS/Kernel/security/SELeaf/seleaf.c
- **Descriere**: Punctul principal de intrare pentru subsistemul SELeaf. Inițializează protecția kernelului și autorizarea driverelor.

### /home/prede/LeafOS/Kernel/security/SELeaf/kernel_prot.c
- **Descriere**: Securizează nucleul kernelului. Activează bitul Write-Protect în CR0 și oferă protecție împotriva coruperii stivei.

### /home/prede/LeafOS/Kernel/security/SELeaf/driver_prot.c
- **Descriere**: Validează driverele înainte de înregistrare folosind Autoritatea de Certificate.

### /home/prede/LeafOS/Kernel/security/SELeaf/sandbox.c
- **Descriere**: Implementează medii de execuție izolate pentru sarcini specifice sau nesigure.

### /home/prede/LeafOS/Kernel/security/certs/certs.c
- **Descriere**: Autoritatea Internă de Certificate. Stochează cheile publice pentru rețea și drivere și verifică semnăturile criptografice.

### /home/prede/LeafOS/Kernel/security/SELeaf/net_prot.c
- **Descriere**: Strat de securitate pentru rețea. Filtrează pachetele și gestionează politicile de acces.