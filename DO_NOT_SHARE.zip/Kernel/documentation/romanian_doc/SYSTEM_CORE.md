# Documentație Nucleu Sistem

### /home/prede/LeafOS/Kernel/panic.c
- **Descriere**: Gestionarea centralizată a erorilor critice.
- **Caracteristici**: Afișează mesajul de "Kernel Panic" și oprește procesorul.

### /home/prede/LeafOS/Kernel/net/net.c
- **Descriere**: Stiva de rețea LeafOS.
- **Caracteristici**: Implementează protocoalele Ethernet, ARP, IPv4 și ICMP (Ping).

### /home/prede/LeafOS/Kernel/LICENSES/credits.c
- **Descriere**: Un fișier de tip credit, tematic în limbajul C, conținând autorii și dezvoltatorii.

### /home/prede/LeafOS/Kernel/tools/makefile.mk
- **Descriere**: Automatizarea sistemului de build.