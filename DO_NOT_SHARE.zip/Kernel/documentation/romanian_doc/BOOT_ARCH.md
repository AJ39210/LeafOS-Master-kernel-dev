# Documentație Boot și Arhitectură

### /home/prede/LeafOS/Kernel/arch/x86/entry.s
- **Tip**: Assembler x86
- **Descriere**: Punctul de intrare de nivel scăzut pentru kernel. Definește antetul Multiboot cerut de GRUB, inițializează indicatorul de stivă (%esp) și transferă controlul către funcția C `kmain`.
- **Funcționalitate**: Conformitate Multiboot, configurarea stării inițiale a CPU.

### /home/prede/LeafOS/Kernel/arch/x86/linker.ld
- **Tip**: Script de Linker
- **Descriere**: Definește aspectul memoriei fizice și virtuale a binarului kernel-ului.
- **Funcționalitate**: Plasează secțiunea `.multiboot` la începutul binarului (offset 1MB) și definește secțiunile pentru cod, date și stivă.