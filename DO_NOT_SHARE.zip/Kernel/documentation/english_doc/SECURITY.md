# SELeaf Security Documentation

### /home/prede/LeafOS/Kernel/security/SELeaf/seleaf.c
- **Description**: The main entry point for the Security-Enhanced Leaf (SELeaf) subsystem. Initializes kernel protection, driver authorization, and filesystem hooks.

### /home/prede/LeafOS/Kernel/security/SELeaf/kernel_prot.c
- **Description**: Hardens the kernel core. Enables the Write-Protect (WP) bit in CR0 to prevent unauthorized code modification and provides `__stack_chk_fail` for stack smashing protection.

### /home/prede/LeafOS/Kernel/security/SELeaf/driver_prot.c
- **Description**: Validates drivers before registration. Uses the Certificate Authority to check cryptographic signatures.

### /home/prede/LeafOS/Kernel/security/SELeaf/sandbox.c
- **Description**: Implements isolated execution environments for untrusted or specific kernel tasks.

### /home/prede/LeafOS/Kernel/security/certs/certs.c
- **Description**: Internal Certificate Authority.
- **Key Features**: Stores the Root, Network, and Driver public keys. Implements a constant-time signature verification function to prevent timing attacks.

### /home/prede/LeafOS/Kernel/security/SELeaf/net_prot.c
- **Description**: Network security layer. Filters packets based on size and policy, and provides hooks for IP blacklisting.