# Filesystem and Storage Documentation

### /home/prede/LeafOS/Kernel/fs/vfs.c
- **Description**: Virtual File System abstraction layer.
- **Key Features**: Provides a unified interface (`fs_node_t`) for interacting with different filesystem types.

### /home/prede/LeafOS/Kernel/fs/fat.c
- **Description**: Implementation for the FAT (File Allocation Table) family, supporting FAT12, FAT16, and FAT32.

### /home/prede/LeafOS/Kernel/fs/ext.c
- **Description**: Implementation for the EXT family (ext2/ext3/ext4).

### /home/prede/LeafOS/Kernel/include/block.c
- **Description**: Block Device Manager. Handles registration of physical disks and abstracts sector-based I/O.