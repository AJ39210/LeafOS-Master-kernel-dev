# System Core Documentation

### /home/prede/LeafOS/Kernel/panic.c
- **Description**: Centralized error handling. 
- **Key Features**: Clears the VGA screen, prints a formatted "Kernel Panic" message with error details, and halts the CPU using a `cli/hlt` loop.

### /home/prede/LeafOS/Kernel/net/net.c
- **Description**: The LeafOS Network Stack.
- **Key Features**: Implements Big-Endian byte swapping (`htons`/`ntohs`), Ethernet frame handling, ARP (Address Resolution Protocol), and IPv4/ICMP echo response (Ping).

### /home/prede/LeafOS/Kernel/LICENSES/credits.c
- **Description**: A C-language themed credits file containing contributors and maintainers.

### /home/prede/LeafOS/Kernel/tools/makefile.mk
- **Description**: Build system automation. Handles dependency installation and kernel compilation.