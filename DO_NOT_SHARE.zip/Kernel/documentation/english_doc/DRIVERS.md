# Driver Subsystem Documentation

### /home/prede/LeafOS/Kernel/drivers/driver_daemon.c
- **Description**: The central manager for all kernel drivers.
- **Key Features**: Manages driver registration, PIDs, and lifecycle (Start/Stop/Restart). 
- **Security**: Requires SELeaf authorization before a driver can be registered. It monitors the VGA driver (PID 100029) and panics if it fails.

### /home/prede/LeafOS/Kernel/drivers/Framebuffer/vga/vga.c
- **Description**: Standard VGA text mode driver (80x25).
- **Key Features**: Handles screen clearing, character output, and automatic line wrapping/scrolling.

### /home/prede/LeafOS/Kernel/drivers/input/ps2_keyboard.c
- **Description**: Full PS/2 Keyboard driver using Scancode Set 1.
- **Key Features**: Maps raw hardware scancodes to ASCII, handles Shift and Caps Lock states, and interprets control keys like Backspace and Enter.

### /home/prede/LeafOS/Kernel/drivers/sound/pc_speaker.c
- **Description**: Legacy audio driver using the Programmable Interval Timer (PIT).
- **Key Features**: Generates frequencies by manipulating the PIT channel 2 and the PC Speaker gate (Port 0x61).

### /home/prede/LeafOS/Kernel/drivers/network/e1000/e1000.c
- **Description**: Driver for Intel 8254x series Gigabit Ethernet controllers.

### /home/prede/LeafOS/Kernel/drivers/network/i40e/i40e.c
- **Description**: Driver for Intel XL710 40GbE controllers. Implements the complex Admin Queue (AQ) descriptor mechanism for firmware communication.