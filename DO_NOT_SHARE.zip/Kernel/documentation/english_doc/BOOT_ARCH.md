# Boot and Architecture Documentation

### /home/prede/LeafOS/Kernel/arch/x86/entry.s
- **Type**: x86 Assembly
- **Description**: The low-level entry point for the kernel. It defines the Multiboot header required by GRUB, initializes the stack pointer (%esp), and transfers control to the C-level `kmain` function.
- **Functionality**: Multiboot compliance, initial CPU state setup.

### /home/prede/LeafOS/Kernel/arch/x86/linker.ld
- **Type**: Linker Script
- **Description**: Defines the physical and virtual memory layout of the kernel binary.
- **Functionality**: Places the `.multiboot` section at the start of the binary (1MB offset) and defines sections for `.text`, `.rodata`, `.data`, `.bss`, and the kernel stack.