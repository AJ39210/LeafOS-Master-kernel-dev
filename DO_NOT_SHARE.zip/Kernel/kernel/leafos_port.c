#include <stdint.h>
#include <stddef.h>
#include <syscalls.h> // For syscall numbers

/*
 * LeafOS porting layer for Embedded Artistry libc.
 * This provides the OS-specific functions required by the libc.
 */

// Heap management: sbrk is typically used by malloc
void* _sbrk(intptr_t increment) {
    // In a kernel, this would interact with the kernel's memory allocator (kmalloc/kfree).
    // For now, return -1 to indicate failure or a fixed heap boundary.
    // A proper implementation would extend the heap.
    return (void*)-1;
}

// File I/O: These map to LeafOS VFS syscalls
int _read(int file, char *ptr, int len) {
    // Map file descriptor to fs_node_t* and call SYS_VFS_READ
    // This is a placeholder; actual implementation needs fd management.
    return -1;
}

int _write(int file, char *ptr, int len) {
    // Map file descriptor to fs_node_t* and call SYS_VFS_WRITE
    // This is a placeholder; actual implementation needs fd management.
    return -1;
}

int _close(int file) { return -1; }
int _fstat(int file, void *st) { return -1; }
int _isatty(int file) { return 0; }
int _lseek(int file, int ptr, int dir) { return -1; }
int _exit(int status) {
    // Call SYS_EXIT syscall
    // For now, kernel_panic or halt.
    for(;;);
}
