#include <irq.h>
#include <io.h>
#include <vga.h>

static irq_handler_t irq_routines[16] = {0};

void irq_install_handler(int irq, irq_handler_t handler) {
    irq_routines[irq] = handler;
}

void irq_uninstall_handler(int irq) {
    irq_routines[irq] = 0;
}

void irq_init(void) {
    /* Remap the PIC (Programmable Interrupt Controller) */
    /* Restart the both PICs */
    outb(0x20, 0x11);
    outb(0xA0, 0x11);
    /* Map Master PIC to 0x20 (32) and Slave PIC to 0x28 (40) */
    outb(0x21, 0x20);
    outb(0xA1, 0x28);
    /* Setup cascading */
    outb(0x21, 0x04);
    outb(0xA1, 0x02);
    outb(0x21, 0x01);
    outb(0xA1, 0x01);
    /* Null out the data registers */
    outb(0x21, 0x0);
    outb(0xA1, 0x0);

    vga_puts("[IRQ] PIC remapped and hardware interrupts enabled.\n");
}

void irq_handler(registers_t *regs) {
    void (*handler)(registers_t *regs);

    /* Check if we have a custom handler for this IRQ */
    handler = irq_routines[regs->int_no - 32];
    if (handler) {
        handler(regs);
    }

    /* Send EOI (End of Interrupt) to the PICs */
    if (regs->int_no >= 40) {
        /* Reset slave PIC */
        outb(0xA0, 0x20);
    }
    /* Reset master PIC */
    outb(0x20, 0x20);
}