#include <isr.h>
#include <irq.h> // Assuming irq.h is also directly in include/ now
#include <string.h>

idt_entry_t idt_entries[256];
idt_ptr_t   idt_ptr;

void idt_init(void) {
    idt_ptr.limit = sizeof(idt_entry_t) * 256 - 1;
    idt_ptr.base  = (uint32_t)&idt_entries;

    memset(&idt_entries, 0, sizeof(idt_entry_t) * 256);

    /* Remap the PIC so hardware interrupts don't clash with exceptions */
    irq_init();
    
    // Set up Syscall Gate (0x80)
    // sel 0x08 is Kernel Code, flags 0xEF allows user-mode (DPL 3) calling
    // Note: base would be the assembly stub address
    // idt_set_gate(0x80, (uint32_t)isr128, 0x08, 0xEF);

    asm volatile("lidt %0" : : "m" (idt_ptr));
}

void idt_set_gate(uint8_t num, uint32_t base, uint16_t sel, uint8_t flags) {
    idt_entries[num].base_lo = base & 0xFFFF;
    idt_entries[num].base_hi = (base >> 16) & 0xFFFF;
    idt_entries[num].sel     = sel;
    idt_entries[num].always0 = 0;
    idt_entries[num].flags   = flags;
}

void isr_handler(registers_t regs) {
    if (regs.int_no == 0x80) {
        syscall_handler(&regs);
    } else if (regs.int_no >= 32 && regs.int_no < 48) {
        /* Dispatch to the IRQ subsystem */
        irq_handler(&regs);
    }
}