#include <kernel.h>
#include <stdint.h>

/* A very simple bump allocator starting at 16MB */
static uint32_t placement_address = 0x1000000;

void* kmalloc(size_t size) {
    uint32_t tmp = placement_address;
    placement_address += size;

    /* Maintain 4-byte alignment */
    if (placement_address & 0x3) {
        placement_address = (placement_address & ~0x3) + 0x4;
    }
    return (void*)tmp;
}