#include <stdint.h>
#include <syscalls.h>
#include <errno.h> // For errno

/* 
 * Global errno storage. 
 * Freestanding environments must provide this variable for the C library.
 */
int errno;

/* 
 * musl and Newlib both expect an internal __syscall function 
 * to be defined by the OS port.
 */
long __syscall(long n, long a1, long a2, long a3, long a4, long a5, long a6) {
    long ret;
    (void)a6; // a6 is currently unused in our 5-parameter syscall handler

    /* 
     * x86 System Call Convention:
     * EAX: Syscall Number (n)
     * EBX: Arg 1 (a1)
     * ECX: Arg 2 (a2)
     * EDX: Arg 3 (a3)
     * ESI: Arg 4 (a4)
     * EDI: Arg 5 (a5)
     */
    asm volatile (
        "mov %1, %%eax\n"
        "mov %2, %%ebx\n"
        "mov %3, %%ecx\n"
        "mov %4, %%edx\n"
        "mov %5, %%esi\n"
        "mov %6, %%edi\n"
        "int $0x80\n"
        "mov %%eax, %0\n"
        : "=m"(ret)
        : "m"(n), "m"(a1), "m"(a2), "m"(a3), "m"(a4), "m"(a5)
        : "eax", "ebx", "ecx", "edx", "esi", "edi"
    );
    return ret;
}

/* Required for Newlib/musl heap management */
void* sbrk(intptr_t increment) {
    errno = ENOMEM; // Indicate out of memory
    return (void*)-1; /* Managed by Kmalloc */
}
