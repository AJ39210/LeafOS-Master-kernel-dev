/*
 * LeafOS Kernel - Main Entry Point
 * Copyright (C) 2022-2026 [Predescu Ciprian]
 */

#include <vga.h>
#include <kernel.h>
#include <panic.h>
#include <gdt.h>
#include <isr.h>
#include <irq.h>
#include <syscalls.h>
#include <ps2_keyboard.h>
#include <sound.h>
#include <block.h>
#include <vfs.h>
#include <fat.h>
#include <ext.h>
#include <lfsfs.h>
#include <ntfs.h>
#include <driver_daemon.h>
#include <seleaf.h>
#include <certs.h>
#include <kernel_prot.h>
#include <fs_prot.h>
#include <net_prot.h>
#include <lib/stdio.h>
#include <lib/string.h>
#include <leafos_glue.h>
#include <leafos_entropy.h>
#include <lib/decompreser/tar_gz/tar_gz.h>
#include <lib/decompreser/zip/zip.h>

/**
 * kmain - The kernel entry point.
 * This function is called after the assembly bootstrap loader 
 * has set up the initial stack and processor state.
 */
void kmain(void) {
    /* 1. Initialize Terminal Output */
    vga_clear();
    vga_puts(BOOT_BANNER);
    vga_puts("\nKernel: "); vga_puts(KERNEL_NAME);
    vga_puts(" v"); vga_puts(KERNEL_VERSION);
    vga_puts(" ("); vga_puts(KERNEL_CODENAME); vga_puts(")\n");
    vga_puts("Copyright (C) 2022-2026 Predescu Ciprian\n");
    
    vga_puts(KERNEL_NAME);
    vga_puts(" kernel is running the ");
    vga_puts(OS_NAME);
    vga_puts(" initrd/ramdisk.\n\n");

    /* 2. Initialize Segmentation (GDT) */
    vga_puts(BOOT_MSG_GDT); vga_puts("\n");
    gdt_init();

    /* 3. Initialize Interrupts (IDT, ISRs, and PIC/IRQ) */
    vga_puts(BOOT_MSG_IDT); vga_puts("\n");
    idt_init();

    /* 4. Initialize System Call Interface */
    vga_puts(BOOT_MSG_SYSCALL); vga_puts("\n");
    syscalls_init();

    /* 5. Initialize Security (SELeaf) */
    vga_puts("[INIT] Engaging SELeaf Security Modules...\n");
    seleaf_init();
    kernel_prot_init();

    /* 5. Initialize Basic Hardware Drivers */
    vga_puts(BOOT_MSG_KEYBOARD); vga_puts("\n");
    ps2_keyboard_init();

    /* 6. Enable Hardware Interrupts */
    asm volatile("sti");

    /* 7. Initialize Virtual File System */
    vga_puts(BOOT_MSG_VFS); vga_puts("\n");
    /* Note: In a real boot, we would mount the initrd here using tar_gz_parse */

    vga_puts("\nLeafOS Kernel is active and ready.\n");
    vga_puts("System idle. Press keys to test input.\n");

    /* 8. Enter Kernel Idle Loop */
    /* We halt the CPU to save power until the next interrupt (like a keystroke) occurs. */
    while (1) {
        asm volatile("hlt");
    }
}