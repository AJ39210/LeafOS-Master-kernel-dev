/*
 * LeafOS Kernel - System Call Implementation
 */

#include <syscalls.h>
#include <kernel.h> // For kernel_panic
#include <vga.h>    // For vga_puts
#include <vfs.h>    // For VFS operations
#include <driver_daemon.h> // For driver operations
#include <sound.h>  // For sound operations

// Define the signature for a generic syscall function
typedef int (*syscall_func_t)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);

// Array of function pointers for system calls
static syscall_func_t syscall_table[MAX_SYSCALL_NUM];

void syscalls_init(void) {
    // Initialize syscall table with NULL pointers
    for (int i = 0; i < MAX_SYSCALL_NUM; i++) {
        syscall_table[i] = NULL;
    }

    // Register VFS syscalls
    syscall_table[SYS_VFS_READ] = (syscall_func_t)vfs_read;
    syscall_table[SYS_VFS_WRITE] = (syscall_func_t)vfs_write;
    // Note: vfs_open and vfs_close take fs_node_t* which is a kernel pointer.
    // A real syscall would need to map user-space file descriptors to kernel fs_node_t*.
    // For now, these are stubs.
    syscall_table[SYS_VFS_OPEN] = (syscall_func_t)vfs_open;
    syscall_table[SYS_VFS_CLOSE] = (syscall_func_t)vfs_close;
    syscall_table[SYS_VFS_READDIR] = (syscall_func_t)vfs_readdir;
    syscall_table[SYS_VFS_FORMAT] = (syscall_func_t)vfs_format;

    // Register Driver Daemon syscalls
    syscall_table[SYS_DRIVER_START] = (syscall_func_t)driver_start;
    syscall_table[SYS_DRIVER_STOP] = (syscall_func_t)driver_stop;
    syscall_table[SYS_DRIVER_RESTART] = (syscall_func_t)driver_restart;
    syscall_table[SYS_DRIVER_UNLOAD] = (syscall_func_t)driver_unload;
    // driver_register is typically not a user-space syscall

    // Register Sound syscalls
    syscall_table[SYS_PLAY_SOUND] = (syscall_func_t)play_sound;
    syscall_table[SYS_NOSOUND] = (syscall_func_t)nosound;

    vga_puts("[SYSCALLS] System call table initialized.\n");
}

void syscall_handler(registers_t *regs) {
    // EAX contains the syscall number
    if (regs->eax >= MAX_SYSCALL_NUM) return;

    syscall_func_t func = syscall_table[regs->eax];
    if (!func) return;

    // Map register args to syscall parameters
    // In x86, common convention uses EBX, ECX, EDX, ESI, EDI for args
    int ret = func(regs->ebx, regs->ecx, regs->edx, regs->esi, regs->edi);

    // Store result back in EAX
    regs->eax = ret;
}
