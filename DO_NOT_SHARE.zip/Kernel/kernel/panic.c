/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <panic.h>
#include <vga.h>

void kernel_panic(const char* message) {
    /* Clear the screen for the panic message */
    vga_init();

    vga_puts("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    vga_puts("                                 KERNEL PANIC                                   \n");
    vga_puts("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n");
    vga_puts("LeafOS has encountered a critical error and must halt.\n\n");
    vga_puts("Error details:\n");
    vga_puts(message);
    vga_puts("\n\n--------------------------------------------------------------------------------\n");
    vga_puts("The system has been halted to prevent data corruption.\n");
    vga_puts("Please restart your computer.");

    /* Disable interrupts and enter an infinite halt loop */
    asm volatile("cli");
    for (;;) {
        asm volatile("hlt");
    }
}