#include <block.h>
#include <vga.h>

static block_device_t* devices[10] = {0};
static int device_count = 0;

void block_init(void) {
    vga_puts("[BLOCK] Block device subsystem initialized.\n");
}

int block_register_device(block_device_t* dev) {
    if (device_count >= 10) return -1;
    devices[device_count++] = dev;
    return 0;
}

block_device_t* block_get_device(uint32_t id) {
    for (int i = 0; i < device_count; i++) {
        if (devices[i]->id == id) return devices[i];
    }
    return (void*)0;
}

int block_read(uint32_t id, uint64_t start, uint32_t count, uint8_t* buffer) {
    block_device_t* dev = block_get_device(id);
    if (dev && dev->read_sectors) {
        return dev->read_sectors(dev, start, count, buffer);
    }
    return -1;
}

int block_write(uint32_t id, uint64_t start, uint32_t count, uint8_t* buffer) {
    block_device_t* dev = block_get_device(id);
    if (dev && dev->write_sectors) {
        return dev->write_sectors(dev, start, count, buffer);
    }
    return -1;
}