#ifndef LWIP_HDR_DEBUG_H
#define LWIP_HDR_DEBUG_H

#include <lwip/arch.h>
#include <lwip/opt.h>

/* Define LWIP_DBG_ON to enable debug output for a specific module */
#define LWIP_DBG_ON            0x80U
#define LWIP_DBG_OFF           0x00U

/**
 * LWIP_DEBUGF: Main debug message printer
 */
#ifdef LWIP_DEBUG
#define LWIP_DEBUGF(debug, message) do { \
                               if ((debug) & LWIP_DBG_ON) { \
                                 LWIP_PLATFORM_DIAG(message); \
                               } \
                             } while(0)
#else
#define LWIP_DEBUGF(debug, message)
#endif

#endif /* LWIP_HDR_DEBUG_H */
