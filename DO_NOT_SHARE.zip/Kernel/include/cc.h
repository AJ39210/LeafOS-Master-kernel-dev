#ifndef LWIP_ARCH_CC_H
#define LWIP_ARCH_CC_H

#include <stdint.h>
#include <lib/stdio.h>

/* Basic types used by lwIP */
typedef uint8_t    u8_t;
typedef int8_t     s8_t;
typedef uint16_t   u16_t;
typedef int16_t    s16_t;
typedef uint32_t   u32_t;
typedef int32_t    s32_t;
typedef uintptr_t  mem_ptr_t;

/* Architecture-specific macros */
#define BYTE_ORDER LITTLE_ENDIAN

/* Diagnostic output */
#define LWIP_PLATFORM_DIAG(x) do { char buf[128]; sprintf buf; vga_puts(buf); } while(0)
#define LWIP_PLATFORM_ASSERT(x) do { vga_puts("ASSERT: "); vga_puts(x); vga_puts("\n"); } while(0)

#define LWIP_ERR_T int

#endif /* LWIP_ARCH_CC_H */