#ifndef LWIP_HDR_OPT_H
#define LWIP_HDR_OPT_H

/* Include user configuration */
#include "lwipopts.h"

/* Basic defaults if not defined in lwipopts.h */
#ifndef LWIP_DEBUG
#define LWIP_DEBUG 0
#endif

#include <debug.h>

#endif /* LWIP_HDR_OPT_H */