/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_LFSFS_H
#define _LEAFOS_LFSFS_H

#include <stdint.h>
#include <vfs.h>

#define LFSFS_MAGIC 0x4C46

typedef struct {
    uint64_t low;
    uint64_t high;
} uint128_t;

typedef struct {
    uint16_t magic;
    uint16_t version;
    uint128_t total_blocks;    /* 128-bit block count */
    uint128_t root_inode_ptr;  /* 128-bit pointer to root */
    uint32_t block_size;       /* Typically 4KB to 1MB */
    uint8_t reserved[472];
} __attribute__((packed)) lfsfs_header_t;

typedef struct {
    uint32_t permissions;
    uint128_t file_size;       /* Ronnabyte support! */
    uint128_t data_ptr;
    uint32_t flags;
} __attribute__((packed)) lfsfs_inode_t;

fs_node_t *lfsfs_init(uint32_t device_id);
int lfsfs_format(uint32_t device_id, uint64_t total_sectors, uint32_t block_size);

#endif