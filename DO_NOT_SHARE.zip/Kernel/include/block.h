/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_BLOCK_H
#define _LEAFOS_BLOCK_H

#include <stdint.h>

typedef struct block_device {
    char name[32];
    uint32_t id;
    uint32_t sector_size;   /* Usually 512 bytes */
    uint64_t total_sectors;

    /* Driver-specific implementation functions */
    int (*read_sectors)(struct block_device* dev, uint64_t start_lba, uint32_t count, uint8_t* buffer);
    int (*write_sectors)(struct block_device* dev, uint64_t start_lba, uint32_t count, uint8_t* buffer);

    void* private_data;     /* Storage for driver-specific state (e.g., IO ports) */
} block_device_t;

void block_init(void);
int block_register_device(block_device_t* dev);
block_device_t* block_get_device(uint32_t id);
int block_read(uint32_t id, uint64_t start, uint32_t count, uint8_t* buffer);
int block_write(uint32_t id, uint64_t start, uint32_t count, uint8_t* buffer);

#endif