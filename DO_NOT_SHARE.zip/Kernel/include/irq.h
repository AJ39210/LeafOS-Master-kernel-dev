#ifndef _LEAFOS_IRQ_H
#define _LEAFOS_IRQ_H

#include <isr.h>

typedef void (*irq_handler_t)(registers_t *);

void irq_init(void);
void irq_install_handler(int irq, irq_handler_t handler);
void irq_uninstall_handler(int irq);
void irq_handler(registers_t *regs);

#endif