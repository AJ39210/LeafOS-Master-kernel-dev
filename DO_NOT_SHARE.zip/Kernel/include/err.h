#ifndef LWIP_HDR_ERR_H
#define LWIP_HDR_ERR_H

#include <opt.h>
#include <cc.h>

typedef s8_t err_t;

#define ERR_OK          0
#define ERR_MEM        -1
#define ERR_TIMEOUT    -2

#endif /* LWIP_HDR_ERR_H */