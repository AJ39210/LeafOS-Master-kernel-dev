#ifndef LWIP_HDR_ARCH_H
#define LWIP_HDR_ARCH_H

#include <cc.h>

/* This file is often empty in simple ports but required by core headers */

#endif /* LWIP_HDR_ARCH_H */