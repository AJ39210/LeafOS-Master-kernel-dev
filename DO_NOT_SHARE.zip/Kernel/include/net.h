/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 *
 * Network Stack Interface
 * This file defines the common structures and functions for network drivers.
 */

#ifndef _LEAFOS_NET_H
#define _LEAFOS_NET_H

#include <stdint.h>
#include <stdbool.h>

typedef struct mac_addr {
    uint8_t mac[6];
} mac_addr_t;

typedef struct ipv4_addr {
    uint8_t addr[4];
} ipv4_addr_t;

typedef struct net_interface {
    char name[32];
    mac_addr_t mac;
    ipv4_addr_t ipv4;
    // Function pointer for sending a packet
    void (*send_packet)(struct net_interface* iface, uint8_t* data, uint32_t len);
    // Add more fields like IP address, gateway, etc. later
    void* private_data; // For driver-specific data
    struct net_interface* next;
} net_interface_t;

typedef mac_addr_t net_mac_t;
void net_register_interface(net_interface_t* iface);
bool net_is_address_blocked(ipv4_addr_t addr);

#endif