/*
 * LeafOS Kernel - NTFS Filesystem Driver
 */

#ifndef _LEAFOS_NTFS_H
#define _LEAFOS_NTFS_H

#include <stdint.h>
#include <vfs.h>

// Function to initialize/mount an NTFS volume
fs_node_t *ntfs_init(uint32_t device_id);

// Function to format a drive with NTFS
// (Simplified for initial implementation)
int ntfs_format(uint32_t device_id, uint64_t total_sectors, uint32_t block_size);

#endif
