/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_VFS_H
#define _LEAFOS_VFS_H

#include <stdint.h>
#include <stddef.h>

#define FS_FILE        0x01
#define FS_DIRECTORY   0x02
#define FS_FAT12       0x04
#define FS_FAT16       0x08
#define FS_FAT32       0x10
#define FS_EXT2        0x20
#define FS_LFSFS       0x40
#define FS_NTFS        0x80

struct dirent {
    char name[128];
    uint32_t inode;
};

struct fs_node;

typedef uint32_t (*read_type_t)(struct fs_node*, uint64_t, uint32_t, uint8_t*);
typedef uint32_t (*write_type_t)(struct fs_node*, uint64_t, uint32_t, uint8_t*);
typedef void (*open_type_t)(struct fs_node*);
typedef void (*close_type_t)(struct fs_node*);
typedef struct dirent * (*readdir_type_t)(struct fs_node*, uint32_t);
typedef struct fs_node * (*finddir_type_t)(struct fs_node*, char *name);

typedef struct fs_node {
    char name[128];
    uint32_t mask;
    uint32_t uid;
    uint32_t gid;
    uint32_t flags;
    uint32_t inode;
    uint32_t length;
    read_type_t read;
    write_type_t write;
    open_type_t open;
    close_type_t close;
    readdir_type_t readdir;
    finddir_type_t finddir;
    struct fs_node *ptr; /* Used for mountpoints and symlinks */
} fs_node_t;

extern fs_node_t *fs_root;

uint32_t vfs_read(fs_node_t *node, uint64_t offset, uint32_t size, uint8_t *buffer);
uint32_t vfs_write(fs_node_t *node, uint64_t offset, uint32_t size, uint8_t *buffer);
void vfs_open(fs_node_t *node, uint8_t read, uint8_t write);
void vfs_close(fs_node_t *node);
struct dirent *vfs_readdir(fs_node_t *node, uint32_t index);
int vfs_format(uint32_t device_id, const char* fs_type, uint64_t total_sectors, uint32_t block_size);

#endif
