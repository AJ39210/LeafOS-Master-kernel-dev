/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_I40E_HW_H
#define _LEAFOS_I40E_HW_H

#include <stdint.h>

/* Admin Queue Command Descriptor (32 bytes) */
struct i40e_aq_desc {
    uint16_t flags;
    uint16_t opcode;
    uint16_t datalen;
    uint16_t retval;
    uint32_t cookie_high;
    uint32_t cookie_low;
    uint32_t params[4];
} __attribute__((packed));

/* Admin Queue Flags */
#define I40E_AQ_FLAG_DD      (1 << 0)  /* Done */
#define I40E_AQ_FLAG_SI      (1 << 1)  /* Send Interrupt */
#define I40E_AQ_FLAG_ERR     (1 << 2)  /* Error */
#define I40E_AQ_FLAG_FE      (1 << 3)  /* Flush Error */

/* Opcodes */
#define i40e_aqc_opc_get_version    0x0001

/* Register Offsets (PF space) */
#define I40E_PF_ATQBAL          0x00080100 /* ASQ Base Address Low */
#define I40E_PF_ATQBAH          0x00080180 /* ASQ Base Address High */
#define I40E_PF_ATQLEN          0x00080200 /* ASQ Length */
#define I40E_PF_ATQH            0x00080000 /* ASQ Head */
#define I40E_PF_ATQT            0x00080080 /* ASQ Tail */

#define I40E_PF_ARQBAL          0x00080300 /* ARQ Base Address Low */
#define I40E_PF_ARQBAH          0x00080380 /* ARQ Base Address High */
#define I40E_PF_ARQLEN          0x00080400 /* ARQ Length */
#define I40E_PF_ARQH            0x00080280 /* ARQ Head */
#define I40E_PF_ARQT            0x00080300 /* ARQ Tail */

/* MMIO Helpers */
static inline void i40e_write32(uintptr_t base, uint32_t reg, uint32_t val) {
    *(volatile uint32_t*)(base + reg) = val;
}

static inline uint32_t i40e_read32(uintptr_t base, uint32_t reg) {
    return *(volatile uint32_t*)(base + reg);
}

/* Internal state */
#define I40E_AQ_LEN 32 /* Descriptors in the ring */

typedef struct {
    uintptr_t mmio_base;
    struct i40e_aq_desc* asq_ring;
    struct i40e_aq_desc* arq_ring;
    uint16_t asq_next_to_use;
    uint16_t arq_next_to_use;
} i40e_device_t;

int i40e_asq_send_command(i40e_device_t* dev, struct i40e_aq_desc* cmd);
void i40e_init_admin_queue(i40e_device_t* dev);

#endif
