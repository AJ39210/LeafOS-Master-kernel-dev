#ifndef _LEAFOS_LIB_MBEDTLS_ENTROPY_H
#define _LEAFOS_LIB_MBEDTLS_ENTROPY_H

#include <stddef.h>

/* mbedTLS hardware entropy source */
int leafos_entropy_source(void *data, unsigned char *output, size_t len, size_t *olen);

/* Platform memory functions for mbedTLS */
void *mbedtls_platform_zeroize_free(void *ptr, size_t size);
void *mbedtls_platform_calloc(size_t nmemb, size_t size);

#endif