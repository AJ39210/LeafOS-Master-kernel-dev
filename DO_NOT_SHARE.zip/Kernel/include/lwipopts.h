#ifndef LWIP_HDR_LWIPOPTS_H
#define LWIP_HDR_LWIPOPTS_H

/* Minimal lwIP configuration for LeafOS */
#define NO_SYS                     0
#define LWIP_SOCKET                0
#define LWIP_NETCONN               0

#define MEM_ALIGNMENT              4

#endif /* LWIP_HDR_LWIPOPTS_H */