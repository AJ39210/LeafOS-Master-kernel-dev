#ifndef LWIP_HDR_SYS_H
#define LWIP_HDR_SYS_H

#include <opt.h>
#include <err.h>
#include <sys_arch.h>

/* Function prototypes for the OS abstraction layer implemented in leafos_sys_arch.c */

typedef void (* lwip_thread_fn)(void *arg);

void lwip_update_ticks(void);
uint32_t sys_now(void);

sys_thread_t sys_thread_new(const char *name, lwip_thread_fn thread, void *arg, int stacksize, int prio);

sys_sem_t sys_sem_new(u8_t count);
void sys_sem_free(sys_sem_t sem);
void sys_sem_signal(sys_sem_t sem);
u32_t sys_arch_sem_wait(sys_sem_t sem, u32_t timeout);

sys_mbox_t sys_mbox_new(int size);
void sys_mbox_free(sys_mbox_t mbox);
void sys_mbox_post(sys_mbox_t mbox, void *msg);
u32_t sys_arch_mbox_fetch(sys_mbox_t mbox, void **msg, u32_t timeout);
u32_t sys_arch_mbox_tryfetch(sys_mbox_t mbox, void **msg);

sys_mutex_t sys_mutex_new(void);
void sys_mutex_free(sys_mutex_t mutex);
void sys_mutex_lock(sys_mutex_t mutex);
void sys_mutex_unlock(sys_mutex_t mutex);

#endif /* LWIP_HDR_SYS_H */