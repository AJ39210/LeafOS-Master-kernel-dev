/*
 * LeafOS Kernel - Error Numbers
 */

#ifndef _LEAFOS_ERRNO_H
#define _LEAFOS_ERRNO_H

/* Common Error Codes */
#define EPERM            1      /* Operation not permitted */
#define ENOENT           2      /* No such file or directory */
#define EIO              5      /* I/O error */
#define EBADF            9      /* Bad file number */
#define ENOMEM          12      /* Out of memory */
#define EINVAL          22      /* Invalid argument */

extern int errno;

#endif