#ifndef LWIP_ARCH_SYS_ARCH_H
#define LWIP_ARCH_SYS_ARCH_H

#include <cc.h>

/* Define the types used in leafos_sys_arch.c */
typedef u32_t sys_sem_t;
typedef u32_t sys_mutex_t;
typedef u32_t sys_mbox_t;
typedef u32_t sys_thread_t;

#define SYS_MBOX_NULL 0
#define SYS_SEM_NULL  0

/* Timeout value used in sys_arch_sem_wait and sys_arch_mbox_fetch */
#define SYS_ARCH_TIMEOUT 0xffffffff

/* Infrastructure requirement for sys.h */
#include <arch.h>

#endif /* LWIP_ARCH_SYS_ARCH_H */