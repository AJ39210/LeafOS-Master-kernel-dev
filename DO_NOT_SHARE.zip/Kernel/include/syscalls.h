/*
 * LeafOS Kernel - System Call Interface
 */

#ifndef _LEAFOS_SYSCALLS_H
#define _LEAFOS_SYSCALLS_H

#include <stdint.h>
#include <isr.h>

/* System Call Numbers */
enum {
    SYS_EXIT = 0,
    SYS_VFS_READ,
    SYS_VFS_WRITE,
    SYS_VFS_OPEN,
    SYS_VFS_CLOSE,
    SYS_VFS_READDIR,
    SYS_VFS_FORMAT,
    SYS_DRIVER_START,
    SYS_DRIVER_STOP,
    SYS_DRIVER_RESTART,
    SYS_DRIVER_UNLOAD,
    SYS_PLAY_SOUND,
    SYS_NOSOUND,
    // Add more syscalls here
    MAX_SYSCALL_NUM
};

void syscalls_init(void);
void syscall_handler(registers_t *regs); // The entry point for the software interrupt

#endif