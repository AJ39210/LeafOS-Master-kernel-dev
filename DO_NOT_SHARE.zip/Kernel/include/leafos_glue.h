#ifndef _LEAFOS_LIB_MUSL_GLUE_H
#define _LEAFOS_LIB_MUSL_GLUE_H

#include <stdint.h>

/* Internal syscall bridge for standard libraries */
long __syscall(long n, long a1, long a2, long a3, long a4, long a5, long a6);

/* Heap management hook */
void* sbrk(intptr_t increment);

#endif