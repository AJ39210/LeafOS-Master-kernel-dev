/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_CERTS_H
#define _LEAFOS_CERTS_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_CERT_NAME 64
#define KEY_SIZE 256 /* Placeholder for 2048-bit RSA or similar */

typedef struct {
    char subject[MAX_CERT_NAME];
    uint8_t public_key[KEY_SIZE];
    uint32_t key_id;
    bool is_revoked;
} certificate_t;

void certs_init(void);

/* Verifies a payload against a signature using the embedded root certificate */
bool certs_verify_signature(const uint8_t* data, uint32_t len, const uint8_t* signature, uint32_t sig_len, uint32_t key_id);

/* Retrieves the root certificate */
certificate_t* certs_get_root(void);

/* Specialized certificate getters */
certificate_t* certs_get_net_auth(void);
certificate_t* certs_get_driver_auth(void);

#endif