/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#ifndef _LEAFOS_DRIVER_DAEMON_H
#define _LEAFOS_DRIVER_DAEMON_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_DRIVERS 64
#define VGA_DRIVER_PID 100029

typedef enum {
    DRIVER_STOPPED,
    DRIVER_RUNNING,
    DRIVER_FAILED
} driver_state_t;

typedef struct {
    uint32_t pid;
    const char* name;
    driver_state_t state;
    void (*start_func)(void);
    void (*stop_func)(void);
} driver_t;

void driver_daemon_init(void);
uint32_t driver_register(const char* name, void (*start)(void), void (*stop)(void), uint32_t preferred_pid);
bool driver_start(uint32_t pid);
bool driver_stop(uint32_t pid);
bool driver_restart(uint32_t pid);
bool driver_unload(uint32_t pid);

void driver_daemon_update(void); /* Called in kernel loop to check health */

#endif