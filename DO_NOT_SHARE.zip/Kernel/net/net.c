/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <net.h>
#include <vga.h>
#include <stdbool.h>

/* Byte swapping for Big-Endian network order */
#define htons(n) (((((uint16_t)(n) & 0xFF)) << 8) | (((uint16_t)(n) & 0xFF00) >> 8))
#define ntohs(n) htons(n)

/* Ethernet Frame Header */
struct ethernet_header {
    mac_addr_t dest;
    mac_addr_t src;
    uint16_t type;
} __attribute__((packed));

/* ARP Packet Structure */
struct arp_packet {
    uint16_t hw_type;
    uint16_t proto_type;
    uint8_t hw_len;
    uint8_t proto_len;
    uint16_t opcode;
    mac_addr_t src_mac;
    ipv4_addr_t src_ip;
    mac_addr_t dest_mac;
    ipv4_addr_t dest_ip;
} __attribute__((packed));

/* IPv4 Header Structure */
struct ipv4_header {
    uint8_t version_ihl;
    uint8_t tos;
    uint16_t len;
    uint16_t id;
    uint16_t flags_offset;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t checksum;
    ipv4_addr_t src;
    ipv4_addr_t dest;
} __attribute__((packed));

/* ICMP Header Structure */
struct icmp_header {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint32_t rest;
} __attribute__((packed));

static net_interface_t* interfaces = (void*)0;

/* Helper to compare IP addresses */
static bool ip_equal(ipv4_addr_t a, ipv4_addr_t b) {
    for(int i = 0; i < 4; i++) if(a.addr[i] != b.addr[i]) return false;
    return true;
}

/* Simple checksum calculation for IP/ICMP */
static uint16_t net_checksum(void* data, int len) {
    uint32_t sum = 0;
    uint16_t* ptr = (uint16_t*)data;
    for (; len > 1; len -= 2) sum += *ptr++;
    if (len == 1) sum += *(uint8_t*)ptr;
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (uint16_t)~sum;
}

void net_init(void) {
    vga_puts("[NET] Protocol stack IPv4/IPv6 online.\n");
}

void net_register_interface(net_interface_t* iface) {
    if (!iface) return;
    iface->next = interfaces;
    interfaces = iface;
    vga_puts("[NET] Interface UP: ");
    vga_puts(iface->name);
    vga_puts("\n");
}

static void handle_arp(net_interface_t* iface, struct arp_packet* packet) {
    if (ntohs(packet->opcode) == 1) { /* ARP Request */
        if (ip_equal(packet->dest_ip, iface->ipv4)) {
            /* Construct ARP Reply */
            uint8_t reply_buf[64]; // Minimum Ethernet frame size
            struct ethernet_header* eth = (struct ethernet_header*)reply_buf;
            struct arp_packet* arp = (struct arp_packet*)(reply_buf + sizeof(struct ethernet_header));

            /* Ethernet Header */
            eth->dest = packet->src_mac;
            eth->src = iface->mac;
            eth->type = htons(0x0806);

            /* ARP Payload */
            arp->hw_type = htons(1);
            arp->proto_type = htons(0x0800);
            arp->hw_len = 6;
            arp->proto_len = 4;
            arp->opcode = htons(2); /* Reply */
            arp->src_mac = iface->mac;
            arp->src_ip = iface->ipv4;
            arp->dest_mac = packet->src_mac;
            arp->dest_ip = packet->src_ip;

            iface->send_packet(iface, reply_buf, sizeof(struct ethernet_header) + sizeof(struct arp_packet));
        }
    }
}

static void handle_icmp(net_interface_t* iface, struct ipv4_header* ip, struct icmp_header* icmp, uint32_t len) {
    if (icmp->type == 8) { /* Echo Request */
        vga_puts("[NET] ICMP Echo Request from ");
        /* Construction of Echo Reply (In-place swap) */
        icmp->type = 0; /* Echo Reply */
        icmp->checksum = 0;
        icmp->checksum = net_checksum(icmp, len);

        /* Swap IP addresses */
        ipv4_addr_t tmp_ip = ip->src;
        ip->src = ip->dest;
        ip->dest = tmp_ip;
        ip->checksum = 0;
        ip->checksum = net_checksum(ip, (ip->version_ihl & 0x0F) * 4);

        /* Re-encapsulate Ethernet (This requires a full packet buffer, simplified here) */
        // Note: Real implementation would use a proper packet builder.
        // For now, the driver is expected to handle the updated buffer in-place if possible.
    }
}

static void handle_ipv4(net_interface_t* iface, uint8_t* data, uint32_t len) {
    struct ipv4_header* ip = (struct ipv4_header*)data;

    if (net_is_address_blocked(ip->src)) {
        return;
    }

    if (ip_equal(ip->dest, iface->ipv4)) {
        uint32_t header_len = (ip->version_ihl & 0x0F) * 4;
        if (ip->protocol == 1) { /* ICMP */
            handle_icmp(iface, ip, (struct icmp_header*)(data + header_len), ntohs(ip->len) - header_len);
        }
    }
}

void net_receive_packet(net_interface_t* iface, uint8_t* data, uint32_t len) {
    if (!iface || !data || len < sizeof(struct ethernet_header)) return;

    struct ethernet_header* eth = (struct ethernet_header*)data;
    uint16_t type = ntohs(eth->type);

    switch(type) {
        case 0x0806: /* ARP */
            handle_arp(iface, (struct arp_packet*)(data + sizeof(struct ethernet_header)));
            break;
        case 0x0800: /* IPv4 */
            handle_ipv4(iface, data + sizeof(struct ethernet_header), len - sizeof(struct ethernet_header));
            break;
        case 0x86DD: /* IPv6 Stub */
            break;
        default:
            break;
    }
}

bool net_is_address_blocked(ipv4_addr_t addr) {
    /* Example: Block all addresses starting with 10.0.0 (simulated blacklist) */
    if (addr.addr[0] == 10 && addr.addr[1] == 0 && addr.addr[2] == 0) {
        return true;
    }
    return false;
}