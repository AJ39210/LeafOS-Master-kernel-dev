#include <vga.h>
#include <stdint.h>

static uint16_t* const vga_buffer = (uint16_t*)0xB8000;
static const int vga_width = 80;
static const int vga_height = 25;
static int cursor = 0;

void vga_clear(void) {
    for (int i = 0; i < vga_width * vga_height; i++) {
        vga_buffer[i] = (uint16_t)' ' | (uint16_t)(0x07 << 8);
    }
}

void vga_putc(char c) {
    if (c == '\n') {
        cursor = (cursor / vga_width + 1) * vga_width;
    } else {
        vga_buffer[cursor++] = (uint16_t)c | (uint16_t)(0x07 << 8);
    }

    /* Basic wrap-around check */
    if (cursor >= vga_width * vga_height) {
        cursor = 0;
    }
}

void vga_init(void) {
    cursor = 0;
    vga_clear();
}

void vga_puts(const char* str) {
    while (*str) {
        vga_putc(*str++);
    }
}