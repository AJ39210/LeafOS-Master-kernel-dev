/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <driver_daemon.h>
#include <net.h>
#include <vga.h>

static net_interface_t e1000_iface;

void e1000_send(net_interface_t* iface, uint8_t* data, uint32_t len) {
    /* Write to e1000 Transmit Descriptors */
}

void e1000_init(void) {
    vga_puts("[e1000] Initializing Intel 8254x NIC...\n");
    
    e1000_iface.send_packet = e1000_send;
    for(int i=0; i<6; i++) e1000_iface.mac.mac[i] = 0x52; // Placeholder MAC
    
    net_register_interface(&e1000_iface);
}

void e1000_stop(void) {
    /* Disable TX/RX */
}

/* Register with Driver Daemon */
void e1000_register(void) {
    driver_register("intel_e1000", e1000_init, e1000_stop, 0);
}