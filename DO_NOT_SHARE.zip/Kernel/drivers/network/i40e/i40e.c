/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <driver_daemon.h>
#include <net.h>
#include <vga.h>
#include <i40e_hw.h>

/* Static instances for the Admin Queue rings */
static struct i40e_aq_desc asq_ring_mem[I40E_AQ_LEN] __attribute__((aligned(4096)));
static struct i40e_aq_desc arq_ring_mem[I40E_AQ_LEN] __attribute__((aligned(4096)));

static i40e_device_t i40e_dev;

void i40e_init_admin_queue(i40e_device_t* dev) {
    dev->asq_ring = asq_ring_mem;
    dev->arq_ring = arq_ring_mem;
    dev->asq_next_to_use = 0;
    dev->arq_next_to_use = 0;

    uintptr_t asq_phys = (uintptr_t)dev->asq_ring;
    uintptr_t arq_phys = (uintptr_t)dev->arq_ring;

    /* Setup Admin Send Queue (ASQ) registers */
    i40e_write32(dev->mmio_base, I40E_PF_ATQBAL, (uint32_t)asq_phys);
    i40e_write32(dev->mmio_base, I40E_PF_ATQBAH, (uint32_t)(asq_phys >> 32));
    i40e_write32(dev->mmio_base, I40E_PF_ATQLEN, I40E_AQ_LEN | 0x80000000); /* Enable bit */
    i40e_write32(dev->mmio_base, I40E_PF_ATQH, 0);
    i40e_write32(dev->mmio_base, I40E_PF_ATQT, 0);

    /* Setup Admin Receive Queue (ARQ) registers */
    i40e_write32(dev->mmio_base, I40E_PF_ARQBAL, (uint32_t)arq_phys);
    i40e_write32(dev->mmio_base, I40E_PF_ARQBAH, (uint32_t)(arq_phys >> 32));
    i40e_write32(dev->mmio_base, I40E_PF_ARQLEN, I40E_AQ_LEN | 0x80000000);
    i40e_write32(dev->mmio_base, I40E_PF_ARQH, 0);
    i40e_write32(dev->mmio_base, I40E_PF_ARQT, 0);
}

int i40e_asq_send_command(i40e_device_t* dev, struct i40e_aq_desc* cmd) {
    struct i40e_aq_desc* desc = &dev->asq_ring[dev->asq_next_to_use];
    
    /* Copy command data to ring */
    *desc = *cmd;
    desc->flags |= I40E_AQ_FLAG_SI; /* Signal Interrupt / Update DD */

    dev->asq_next_to_use++;
    if (dev->asq_next_to_use >= I40E_AQ_LEN) dev->asq_next_to_use = 0;

    /* Update Tail to notify hardware */
    i40e_write32(dev->mmio_base, I40E_PF_ATQT, dev->asq_next_to_use);

    /* Poll for completion (DD bit) */
    int timeout = 1000;
    while (!(desc->flags & I40E_AQ_FLAG_DD) && --timeout > 0);

    if (timeout == 0) return -1; /* Hardware Timeout */

    /* Copy results back to original structure */
    *cmd = *desc;
    return (cmd->retval == 0) ? 0 : -1;
}

void i40e_init(void) {
    vga_puts("[i40e] Initializing Intel XL710 40GbE controller...\n");

    /* 
     * Note: In a real kernel, mmio_base should be obtained via PCI BAR discovery. 
     * We are using a placeholder here.
     */
    i40e_dev.mmio_base = 0xFE000000; 

    i40e_init_admin_queue(&i40e_dev);

    /* Test the "Admin thingy" by requesting the firmware version */
    struct i40e_aq_desc version_cmd = {0};
    version_cmd.opcode = i40e_aqc_opc_get_version;

    if (i40e_asq_send_command(&i40e_dev, &version_cmd) == 0) {
        vga_puts("[i40e] Admin Queue operational. Firmware API: ");
        /* Version info is in params[0] and params[1] */
        vga_puts("Success\n");
    } else {
        vga_puts("[i40e] Admin Queue timeout or error!\n");
    }
}

void i40e_stop(void) {
    /* Shutdown Admin Queue */
}

void i40e_register(void) {
    /* 
     * Advanced Security: i40e is critical. 
     * We could assign it a reserved high-priority PID.
     */
    driver_register("intel_i40e", i40e_init, i40e_stop, 0);
}