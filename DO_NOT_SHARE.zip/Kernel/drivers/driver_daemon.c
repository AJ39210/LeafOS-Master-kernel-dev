/*
 * LeafOS Kernel - Copyright (C) 2022-2026 [Predescu Ciprian]
 * 
 * 1. SHARE ALIKE: This program is free software. If you modify this 
 *    code and distribute it, you MUST provide the source code of your 
 *    changes under this same license. 
 * 
 * 2. NO WARRANTY: This program is distributed in the hope that it will 
 *    be useful, but WITHOUT ANY WARRANTY; without even the implied 
 *    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * 3. LIMITATION OF LIABILITY: IN NO EVENT SHALL THE AUTHOR BE LIABLE 
 *    FOR ANY DAMAGES (INCLUDING SYSTEM FAILURE, DATA LOSS, OR BRAKED 
 *    HARDWARE) ARISING OUT OF THE USE OF THIS KERNEL.
 *
 * Full License: GNU General Public License v3.0 <https://www.gnu.org/licenses/gpl-3.0.txt>
 */

#include <driver_daemon.h>
#include <kernel.h>
#include <panic.h>
#include <stdint.h>
#include <seleaf.h>
#include <driver_prot.h>
#include <vga.h>

static driver_t driver_list[MAX_DRIVERS];
static uint32_t next_auto_pid = 1;

static driver_t* find_driver(uint32_t pid) {
    if (pid == 0) return (void*)0;
    for (int i = 0; i < MAX_DRIVERS; i++) {
        if (driver_list[i].pid == pid) {
            return &driver_list[i];
        }
    }
    return (void*)0;
}

void driver_daemon_init(void) {
    for (int i = 0; i < MAX_DRIVERS; i++) {
        driver_list[i].pid = 0;
        driver_list[i].name = (void*)0;
        driver_list[i].state = DRIVER_STOPPED;
        driver_list[i].start_func = (void*)0;
        driver_list[i].stop_func = (void*)0;
    }
}

uint32_t driver_register(const char* name, void (*start)(void), void (*stop)(void), uint32_t preferred_pid) {
    uint32_t pid_to_assign = (preferred_pid != 0) ? preferred_pid : next_auto_pid;

    /* Security Authorization check before registration */
    if (!driver_prot_authorize(pid_to_assign, name)) {
        seleaf_log("DRIVER_DAEMON", "Driver registration blocked by SELeaf security policy.");
        return 0;
    }

    int slot = -1;
    for (int i = 0; i < MAX_DRIVERS; i++) {
        if (driver_list[i].pid == pid_to_assign) return 0; /* PID Collision */
        if (slot == -1 && driver_list[i].pid == 0) slot = i;
    }

    if (slot != -1) {
        driver_list[slot].pid = pid_to_assign;
        driver_list[slot].name = name;
        driver_list[slot].start_func = start;
        driver_list[slot].stop_func = stop;
        driver_list[slot].state = DRIVER_STOPPED;
        
        if (preferred_pid == 0) {
            next_auto_pid++;
        }
        return pid_to_assign;
    }
    return 0;
}

bool driver_start(uint32_t pid) {
    driver_t* drv = find_driver(pid);
    if (drv && drv->start_func && drv->state != DRIVER_RUNNING) {
        drv->start_func();
        drv->state = DRIVER_RUNNING;
        return true;
    }
    return false;
}

bool driver_stop(uint32_t pid) {
    if (pid == VGA_DRIVER_PID) {
        kernel_panic("CRITICAL: Attempted to stop VGA Driver (PID 100029). System halted.");
    }

    driver_t* drv = find_driver(pid);
    if (drv && drv->stop_func && drv->state == DRIVER_RUNNING) {
        drv->stop_func();
        drv->state = DRIVER_STOPPED;
        return true;
    }
    return false;
}

bool driver_restart(uint32_t pid) {
    if (driver_stop(pid)) {
        return driver_start(pid);
    }
    return false;
}

bool driver_unload(uint32_t pid) {
    if (pid == VGA_DRIVER_PID) {
        kernel_panic("CRITICAL: Attempted to unload VGA Driver. System halted.");
    }

    driver_t* drv = find_driver(pid);
    if (drv) {
        if (drv->state == DRIVER_RUNNING) driver_stop(pid);
        drv->pid = 0;
        drv->name = (void*)0;
        drv->state = DRIVER_STOPPED;
        return true;
    }
    return false;
}

void driver_daemon_update(void) {
    /* Check critical drivers */
    driver_t* vga = find_driver(VGA_DRIVER_PID);
    if (vga && vga->state != DRIVER_RUNNING) {
        kernel_panic("CRITICAL: VGA Driver is not running.");
    }
}