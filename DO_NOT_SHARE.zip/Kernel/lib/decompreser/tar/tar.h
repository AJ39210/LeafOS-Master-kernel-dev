#ifndef _LEAFOS_LIB_TAR_H
#define _LEAFOS_LIB_TAR_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char checksum[8];
    char typeflag;
    char linkname[100];
    char magic[6];
    char version[2];
    char uname[32];
    char gname[32];
    char devmajor[8];
    char devminor[8];
    char prefix[155];
} __attribute__((packed)) tar_header_t;

void tar_parse(void* tar_data, size_t size);

#endif