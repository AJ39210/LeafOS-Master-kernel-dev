#include <lib/decompreser/tar/tar.h>
#include <lib/string.h>
#include <vga.h>

/* Helper to convert octal string to integer */
static uint32_t octal_to_int(const char* str, int size) {
    uint32_t n = 0;
    for (int i = 0; i < size && str[i]; i++) {
        if (str[i] >= '0' && str[i] <= '7') {
            n = n * 8 + (str[i] - '0');
        }
    }
    return n;
}

void tar_parse(void* tar_data, size_t size) {
    uint8_t* ptr = (uint8_t*)tar_data;
    size_t offset = 0;

    while (offset < size) {
        tar_header_t* header = (tar_header_t*)(ptr + offset);
        
        /* Check magic for USTAR format */
        if (memcmp(header->magic, "ustar", 5) != 0) break;

        uint32_t file_size = octal_to_int(header->size, 12);
        
        vga_puts("[TAR] Found file: ");
        vga_puts(header->name);
        vga_puts("\n");

        /* Files are aligned to 512-byte blocks */
        offset += 512; // Skip header
        offset += (file_size + 511) & ~511; // Skip data + alignment
    }
}