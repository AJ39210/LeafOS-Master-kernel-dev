#ifndef _LEAFOS_LIB_ZIP_H
#define _LEAFOS_LIB_ZIP_H

#include <stdint.h>

typedef struct {
    uint32_t signature;
    uint16_t version;
    uint16_t flags;
    uint16_t compression_method;
    uint16_t mod_time;
    uint16_t mod_date;
    uint32_t crc32;
    uint32_t compressed_size;
    uint32_t uncompressed_size;
    uint16_t name_length;
    uint16_t extra_length;
} __attribute__((packed)) zip_local_header_t;

void zip_parse(void* zip_data);

#endif