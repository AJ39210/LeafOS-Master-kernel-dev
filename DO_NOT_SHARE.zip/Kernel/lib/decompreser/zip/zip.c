#include <stdint.h>
#include <lib/decompreser/zip/zip.h>
#include <lib/string.h>
#include <vga.h>

void zip_parse(void* zip_data) {
    zip_local_header_t* header = (zip_local_header_t*)zip_data;

    if (header->signature == 0x04034b50) {
        vga_puts("[ZIP] Local Header Detected. Compression Method: ");
        /* Real ZIP decompression requires a Deflate implementation (e.g., miniz) */
        if (header->compression_method == 0) vga_puts("Stored\n");
        else vga_puts("Deflated\n");
    }
}