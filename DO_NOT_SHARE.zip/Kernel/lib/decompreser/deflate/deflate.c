#include <lib/decompreser/deflate/deflate.h>
#include <lib/string.h>
#include <stdbool.h>
#include <vga.h> // For debugging output

// --- Bitstream Reader ---
static uint32_t bit_buffer;
static int bit_count;
static uint8_t* in_ptr;
static size_t in_len_current;

static void init_bitstream(uint8_t* in, size_t len) {
    in_ptr = in;
    in_len_current = len;
    bit_buffer = 0;
    bit_count = 0;
}

static uint32_t read_bits(int n) {
    while (bit_count < n) {
        if (in_len_current == 0) {
            // Ran out of input bytes
            return 0xFFFFFFFF; // Indicate error
        }
        bit_buffer |= (*in_ptr++) << bit_count;
        bit_count += 8;
        in_len_current--;
    }
    uint32_t bits = bit_buffer & ((1 << n) - 1);
    bit_buffer >>= n;
    bit_count -= n;
    return bits;
}

// --- Huffman Decoding (Simplified for Fixed Codes) ---

// Fixed Huffman codes for literals/lengths
// 0-143: 8 bits (00110000 to 10111111)
// 144-255: 9 bits (110000000 to 111111111)
// 256-279: 7 bits (0000000 to 0010111)
// 280-287: 8 bits (11000000 to 11000111)
// This is a simplified representation. A real decoder would build trees.
// For now, we'll just hardcode the ranges for fixed Huffman.

// Length codes (257-285) and extra bits
static const uint16_t length_base[] = {
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
    35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258
};
static const uint8_t length_extra_bits[] = {
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0
};
// Distance codes (0-29) and extra bits
static const uint16_t dist_base[] = {
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
    257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577
};
static const uint8_t dist_extra_bits[] = {
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13
};

// Simplified Huffman decode for fixed codes (very basic, not a full tree walk)
// This function would be replaced by a proper Huffman tree lookup.
// For now, it's a placeholder that assumes we can "read" the code directly.
static uint16_t decode_fixed_literal_length(void) {
    uint32_t bits;

    bits = read_bits(7); // 0000000-0010111 (0-23)
    if (bits <= 0x17) return bits + 256;

    bits = (bits << 1) | read_bits(1); // 00101110-00101111 (24-27)
    if (bits <= 0x5F) return bits - 0x30 + 0; // 0-143

    bits = (bits << 1) | read_bits(1); // 001011110-001011111 (28-29)
    if (bits <= 0x117) return bits - 0x100 + 144; // 144-255

    bits = (bits << 1) | read_bits(1); // 0010111110-0010111111 (30-31)
    if (bits <= 0x11F) return bits - 0x118 + 280; // 280-287

    return 0xFFFF; // Error
}

static uint16_t decode_fixed_distance(void) {
    // Fixed distance codes are 5 bits
    return read_bits(5);
}

int deflate_decompress(uint8_t* in, size_t in_len, uint8_t* out, size_t out_len) {
    init_bitstream(in, in_len);
    uint32_t out_idx = 0;
    bool bfinal = false;

    while (!bfinal) {
        uint32_t block_header = read_bits(3);
        if (block_header == 0xFFFFFFFF) return -1; // Error reading bits

        bfinal = (block_header & 0x01);
        uint8_t btype = (block_header >> 1) & 0x03;

        if (btype == 0) { // Uncompressed block
            // Align to byte boundary
            bit_count = 0; // Discard remaining bits in current byte
            in_ptr += (bit_count + 7) / 8; // Advance input pointer to next byte boundary

            uint16_t len = read_bits(16);
            uint16_t nlen = read_bits(16);
            if (len != (~nlen & 0xFFFF)) {
                vga_puts("[DEFLATE] Uncompressed block length mismatch!\n");
                return -1;
            }
            if (out_idx + len > out_len) {
                vga_puts("[DEFLATE] Output buffer overflow (uncompressed block)!\n");
                return -1;
            }
            if (in_len_current < len) {
                vga_puts("[DEFLATE] Input buffer underrun (uncompressed block)!\n");
                return -1;
            }
            memcpy(out + out_idx, in_ptr, len);
            in_ptr += len;
            in_len_current -= len;
            out_idx += len;
        } else if (btype == 1) { // Fixed Huffman codes
            // vga_puts("[DEFLATE] Processing Fixed Huffman block.\n");
            while (true) {
                uint16_t code = decode_fixed_literal_length();
                if (code == 0xFFFF) return -1; // Error

                if (code < 256) { // Literal byte
                    if (out_idx >= out_len) {
                        vga_puts("[DEFLATE] Output buffer overflow (literal)!\n");
                        return -1;
                    }
                    out[out_idx++] = (uint8_t)code;
                } else if (code == 256) { // End of block
                    break;
                } else if (code > 256 && code <= 285) { // Length code
                    uint32_t len_code_idx = code - 257;
                    uint32_t length = length_base[len_code_idx];
                    if (length_extra_bits[len_code_idx] > 0) {
                        length += read_bits(length_extra_bits[len_code_idx]);
                    }

                    uint32_t dist_code = decode_fixed_distance();
                    if (dist_code == 0xFFFFFFFF) return -1; // Error
                    uint32_t distance = dist_base[dist_code];
                    if (dist_extra_bits[dist_code] > 0) {
                        distance += read_bits(dist_extra_bits[dist_code]);
                    }

                    if (out_idx < distance || out_idx + length > out_len) {
                        vga_puts("[DEFLATE] Invalid back-reference or output buffer overflow!\n");
                        return -1;
                    }
                    // Copy back-reference
                    for (uint32_t i = 0; i < length; i++) {
                        out[out_idx] = out[out_idx - distance];
                        out_idx++;
                    }
                } else {
                    vga_puts("[DEFLATE] Invalid fixed Huffman code!\n");
                    return -1;
                }
            }
        } else if (btype == 2) { // Dynamic Huffman codes
            vga_puts("[DEFLATE] Dynamic Huffman blocks are not fully supported in this simplified decompressor.\n");
            // A full implementation would build Huffman trees here.
            return -1;
        } else { // Reserved
            vga_puts("[DEFLATE] Reserved block type encountered!\n");
            return -1;
        }
    }
    return out_idx;
}