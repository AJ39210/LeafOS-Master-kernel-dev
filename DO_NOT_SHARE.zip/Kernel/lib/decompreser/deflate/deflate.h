#ifndef _LEAFOS_LIB_DEFLATE_H
#define _LEAFOS_LIB_DEFLATE_H

#include <stdint.h>
#include <stddef.h>

// Decompresses DEFLATE data. Returns the size of uncompressed data or negative on error.
int deflate_decompress(uint8_t* in, size_t in_len, uint8_t* out, size_t out_len);

#endif
