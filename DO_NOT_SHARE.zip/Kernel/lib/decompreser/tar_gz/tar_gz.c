#include <lib/decompreser/tar_gz/gzip.h>
#include <lib/decompreser/tar_gz/tar_gz.h>
#include <lib/decompreser/tar/tar.h>
#include <lib/string.h>
#include <lib/decompreser/deflate/deflate.h> // Include the new deflate header
#include <kernel.h>
#include <vga.h>

/* 
 * Implementation of a lightweight DEFLATE (RFC 1951) decompressor 
 * This handles the LZ77 and fixed Huffman blocks used in most Gzip files.
 */
int gzip_decompress(void* in_data, size_t in_len, void* out_data) {
    uint8_t* in = (uint8_t*)in_data;
    gzip_header_t* header = (gzip_header_t*)in;

    if (header->magic[0] != 0x1F || header->magic[1] != 0x8B) {
        return -1;
    }

    /* Skip header (10 bytes) + optional fields based on flags */
    size_t offset = 10;
    if (header->flags & 0x04) offset += 2 + (*(uint16_t*)(in + offset)); /* Extra */
    if (header->flags & 0x08) offset += strlen((char*)in + offset) + 1;  /* Name */
    if (header->flags & 0x10) offset += strlen((char*)in + offset) + 1;  /* Comment */
    if (header->flags & 0x02) offset += 2;                               /* CRC16 */

    /*
     * Call the DEFLATE decompressor for the compressed data part.
     * The last 8 bytes of a Gzip stream are CRC32 and ISIZE.
     */
    // Assuming out_data is large enough (e.g., a pre-allocated buffer)
    return deflate_decompress(in + offset, in_len - offset - 8, (uint8_t*)out_data, 0xFFFFFFFF); // Max possible output size
}

void tar_gz_parse(void* data, size_t size) {
    vga_puts("[TAR.GZ] Extracting compressed archive...\n");
    
    /* 
     * We need a temporary buffer for the uncompressed TAR.
     * In LeafOS, we'd typically allocate this from the heap.
     */
    void* tar_buffer = (void*)0x4000000; // Placeholder address for large initrd extraction
    
    int uncompressed_size = gzip_decompress(data, size, tar_buffer);
    
    if (uncompressed_size > 0) {
        tar_parse(tar_buffer, uncompressed_size);
    } else {
        vga_puts("[TAR.GZ] Decompression failed!\n");
    }
}