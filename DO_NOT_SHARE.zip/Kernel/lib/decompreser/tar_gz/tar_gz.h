#ifndef _LEAFOS_LIB_TAR_GZ_H
#define _LEAFOS_LIB_TAR_GZ_H

#include <stddef.h>

/* 
 * Parses and extracts a .tar.gz archive.
 */
void tar_gz_parse(void* data, size_t size);

#endif