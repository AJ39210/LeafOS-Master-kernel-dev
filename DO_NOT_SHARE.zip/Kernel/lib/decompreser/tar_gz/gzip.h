#ifndef _LEAFOS_LIB_GZIP_H
#define _LEAFOS_LIB_GZIP_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint8_t magic[2];      /* 0x1f 0x8b */
    uint8_t method;        /* 8 = deflate */
    uint8_t flags;
    uint32_t mtime;
    uint8_t xflags;
    uint8_t os;
} __attribute__((packed)) gzip_header_t;

/* 
 * Decompresses Gzip data. 
 * Returns the size of uncompressed data or negative on error.
 */
int gzip_decompress(void* in_data, size_t in_len, void* out_data);

#endif