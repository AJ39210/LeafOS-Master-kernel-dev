#include <leafos_entropy.h>
#include <io.h>
#include <vga.h> // For debugging

/*
 * Provides hardware-based entropy for mbed TLS using 
 * the system clock jitter from the PIT.
 */
int leafos_entropy_source(void *data, unsigned char *output, size_t len, size_t *olen) {
    (void)data;
    for(size_t i = 0; i < len; i++) {
        /* Use the PIT counter as a simple entropy source */
        uint8_t entropy = inb(0x40);
        output[i] = entropy;
    }
    *olen = len;
    return 0;
}

/*
 * LeafOS mbed TLS memory allocation hooks.
 */
void *mbedtls_platform_zeroize_free( void *ptr, size_t size ) {
    (void)size;
    vga_puts("[mbedTLS] mbedtls_platform_zeroize_free (stub)\n");
    return NULL;
}

void *mbedtls_platform_calloc( size_t nmemb, size_t size ) {
    (void)nmemb; (void)size;
    vga_puts("[mbedTLS] mbedtls_platform_calloc (stub)\n");
    return NULL;
}