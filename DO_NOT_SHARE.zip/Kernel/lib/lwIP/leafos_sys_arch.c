#include <opt.h>
#include <sys.h>
#include <vga.h> // For debugging

/* 
 * LeafOS lwIP System Architecture Layer.
 * Provides timing for the TCP/IP stack.
 */
static uint32_t system_ticks = 0;
static sys_thread_t dummy_thread_id = 1; // Simple placeholder

uint32_t sys_now(void) {
    return system_ticks;
}

/* Called by the IRQ 0 (Timer) handler */
void lwip_update_ticks(void) { // Assuming 1ms tick
    system_ticks++;
}

sys_thread_t sys_thread_new(const char *name, lwip_thread_fn thread, void *arg, int stacksize, int prio) {
    vga_puts("[lwIP] sys_thread_new: ");
    vga_puts(name);
    vga_puts(" (stub)\n");
    // In a real OS, this would create a new keWrnel thread.
    // For now, return a dummy ID.
    return dummy_thread_id++;
}

sys_sem_t sys_sem_new(u8_t count) {
    vga_puts("[lwIP] sys_sem_new (stub)\n");
    return (sys_sem_t)1; // Dummy semaphore
}

void sys_sem_free(sys_sem_t sem) {
    vga_puts("[lwIP] sys_sem_free (stub)\n");
}

void sys_sem_signal(sys_sem_t sem) {
    // vga_puts("[lwIP] sys_sem_signal (stub)\n");
}

u32_t sys_arch_sem_wait(sys_sem_t sem, u32_t timeout) {
    // vga_puts("[lwIP] sys_arch_sem_wait (stub)\n");
    return SYS_ARCH_TIMEOUT; // Always timeout for now
}

sys_mbox_t sys_mbox_new(int size) { return (sys_mbox_t)1; }
void sys_mbox_free(sys_mbox_t mbox) {}
void sys_mbox_post(sys_mbox_t mbox, void *msg) {}
u32_t sys_arch_mbox_fetch(sys_mbox_t mbox, void **msg, u32_t timeout) { return SYS_ARCH_TIMEOUT; }
u32_t sys_arch_mbox_tryfetch(sys_mbox_t mbox, void **msg) { return SYS_ARCH_TIMEOUT; }

sys_mutex_t sys_mutex_new(void) { return (sys_mutex_t)1; }
void sys_mutex_free(sys_mutex_t mutex) {}
void sys_mutex_lock(sys_mutex_t mutex) {}
void sys_mutex_unlock(sys_mutex_t mutex) {}
