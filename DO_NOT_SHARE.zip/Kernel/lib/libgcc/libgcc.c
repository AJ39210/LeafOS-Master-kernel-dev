#include <stdint.h>
#include <stddef.h> // For size_t
#include <lib/string.h> // For memcpy, memset

/* 64-bit integer division and modulo for 32-bit architecture */
int64_t __divdi3(int64_t a, int64_t b) {
    uint64_t ua = (a < 0) ? -a : a;
    uint64_t ub = (b < 0) ? -b : b;
    uint64_t res = ua / ub; 
    if ((a ^ b) < 0) return -(int64_t)res;
    return (int64_t)res;
}

uint64_t __udivdi3(uint64_t num, uint64_t den) {
    // This is a placeholder. A full implementation involves a loop of shifts and subtractions.
    // For now, relying on compiler's intrinsic or a more complex algorithm.
    // This is often provided by the actual libgcc.a.
    return num / den;
}

uint64_t __umoddi3(uint64_t num, uint64_t den) {
    return num - (den * __udivdi3(num, den));
}

int64_t __moddi3(int64_t num, int64_t den) {
    int64_t res = num - (den * __divdi3(num, den));
    if ((num < 0) != (res < 0)) {
        res += den;
    }
    return res;
}

int64_t __ashrdi3(int64_t a, int b) {
    // Arithmetic shift right for 64-bit
    return a >> b;
}

uint64_t __lshrdi3(uint64_t a, int b) {
    // Logical shift right for 64-bit
    return a >> b;
}

uint64_t __muldi3(uint64_t a, uint64_t b) {
    // 64-bit multiplication. For 32-bit, this is usually a series of 32-bit multiplications and additions.
    // For now, rely on compiler's intrinsic.
    return a * b;
}

/* Logic for stack-protector (linked to SELeaf) */
uintptr_t __stack_chk_guard = 0x595e9fbd;

extern void __stack_chk_fail(void); 
/* __stack_chk_fail is implemented in security/SELeaf/kernel_prot.c */

/* Memory operations the compiler might insert */
void __aeabi_memcpy(void *dest, const void *src, size_t n) { memcpy(dest, src, n); }
void __aeabi_memclr(void *dest, size_t n) { memset(dest, 0, n); }
void __aeabi_memset(void *dest, int c, size_t n) { memset(dest, c, n); }
