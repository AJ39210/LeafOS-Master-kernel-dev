#ifndef _LEAFOS_LIB_STDIO_H
#define _LEAFOS_LIB_STDIO_H

#include <stdarg.h>

/* Formatted string functions */
int vsprintf(char* str, const char* format, va_list ap);
int sprintf(char* str, const char* format, ...);

#endif
