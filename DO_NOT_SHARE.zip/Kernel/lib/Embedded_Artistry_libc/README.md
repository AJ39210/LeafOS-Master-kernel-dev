# Embedded Artistry libc for LeafOS

This directory is intended to house the Embedded Artistry libc port for LeafOS.

**Integration Steps:**
1.  **Source Code**: Clone or copy the Embedded Artistry libc source into this directory.
2.  **Porting Layer**: Create a `leafos_port.c` (similar to `musl_libc/leafos_glue.c`) to implement the necessary OS-specific functions:
    *   `_sbrk`: For heap management (to be backed by LeafOS's `kmalloc`).
    *   `_read`, `_write`, `_close`, `_fstat`, `_isatty`, `_lseek`, `_exit`: To map standard C library I/O to LeafOS VFS and syscalls.
3.  **Build System**: Configure the build system to compile the libc and link it with the kernel or user-space applications.
