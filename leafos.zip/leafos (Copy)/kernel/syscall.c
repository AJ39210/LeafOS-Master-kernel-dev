/**
 * kernel/syscall.c
 * 
 * LeafOS System Call Implementation
 * 
 * Provides syscalls for userspace programs to:
 * - Read/Write disk sectors via ATA/SATA
 * - Control GPIO pins
 * - Query device information
 * 
 * Syscall numbers:
 * 0x100-0x10F: Disk I/O (ATA/SATA)
 * 0x110-0x11F: GPIO operations
 * 0x120-0x12F: Device info
 */

#include <stdint.h>
#include <stddef.h>

#include "serial.h"

/* Forward declarations for drivers */
extern int ata_init(void);
extern int ata_detect_devices(void);
extern int ata_read_sectors(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer);
extern int ata_write_sectors(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer);
extern int ata_identify_device(uint8_t channel, uint8_t drive);

extern int sata_init(void);
extern int sata_probe_ports(void);
extern int sata_read_sectors(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer);
extern int sata_write_sectors(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer);
extern int sata_detect_device(uint32_t port);

extern int gpio_init(void);
extern int gpio_configure_pin(uint8_t port, uint8_t pin, uint8_t mode);
extern int gpio_set_pin(uint8_t port, uint8_t pin, uint8_t state);
extern uint8_t gpio_read_pin(uint8_t port, uint8_t pin);
extern int gpio_toggle_pin(uint8_t port, uint8_t pin);
extern int gpio_configure_advanced(void *config);

/* Syscall numbers */
#define SYS_ATA_READ        0x100
#define SYS_ATA_WRITE       0x101
#define SYS_ATA_IDENTIFY    0x102
#define SYS_ATA_DETECT      0x103

#define SYS_SATA_READ       0x110
#define SYS_SATA_WRITE      0x111
#define SYS_SATA_DETECT     0x112
#define SYS_SATA_PROBE      0x113

#define SYS_GPIO_CONFIG     0x120
#define SYS_GPIO_SET        0x121
#define SYS_GPIO_READ       0x122
#define SYS_GPIO_TOGGLE     0x123

#define SYS_DISK_INFO       0x130
#define SYS_GPIO_INFO       0x131

/**
 * Result structure for syscalls
 */
typedef struct {
    int32_t result;      /* Return value (-1 on error, >=0 on success) */
    uint32_t error_code; /* Error details */
    uint32_t data;       /* Additional data (e.g., GPIO read value) */
} syscall_result_t;

static syscall_result_t last_result = {0};

/**
 * ATA Syscalls
 */

/* SYS_ATA_READ: Read sectors from ATA drive
 * Args: channel, drive, lba, count, buffer
 */
static void syscall_ata_read(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    if (!buffer) {
        last_result.result = -1;
        last_result.error_code = 1; /* Invalid buffer */
        return;
    }
    
    int result = ata_read_sectors(channel, drive, lba, count, buffer);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] ATA Read: ch=");
    serial_putchar(SERIAL_PORT_A, '0' + channel);
    serial_puts(SERIAL_PORT_A, " drv=");
    serial_putchar(SERIAL_PORT_A, '0' + drive);
    serial_puts(SERIAL_PORT_A, " result=");
    serial_putchar(SERIAL_PORT_A, (result < 0) ? 'E' : 'O');
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
}

/* SYS_ATA_WRITE: Write sectors to ATA drive
 * Args: channel, drive, lba, count, buffer
 */
static void syscall_ata_write(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    if (!buffer) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = ata_write_sectors(channel, drive, lba, count, buffer);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] ATA Write: ch=");
    serial_putchar(SERIAL_PORT_A, '0' + channel);
    serial_puts(SERIAL_PORT_A, " drv=");
    serial_putchar(SERIAL_PORT_A, '0' + drive);
    serial_puts(SERIAL_PORT_A, " result=");
    serial_putchar(SERIAL_PORT_A, (result < 0) ? 'E' : 'O');
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
}

/* SYS_ATA_IDENTIFY: Identify ATA device
 * Args: channel, drive
 */
static void syscall_ata_identify(uint8_t channel, uint8_t drive)
{
    int result = ata_identify_device(channel, drive);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
}

/* SYS_ATA_DETECT: Detect ATA devices */
static void syscall_ata_detect(void)
{
    int result = ata_detect_devices();
    last_result.result = result;
    last_result.error_code = 0;
}

/**
 * SATA Syscalls
 */

/* SYS_SATA_READ: Read sectors from SATA drive
 * Args: port, lba, count, buffer
 */
static void syscall_sata_read(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    if (!buffer || port >= 32) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = sata_read_sectors(port, lba, count, buffer);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] SATA Read: port=");
    serial_putchar(SERIAL_PORT_A, '0' + (port % 10));
    serial_puts(SERIAL_PORT_A, " result=");
    serial_putchar(SERIAL_PORT_A, (result < 0) ? 'E' : 'O');
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
}

/* SYS_SATA_WRITE: Write sectors to SATA drive
 * Args: port, lba, count, buffer
 */
static void syscall_sata_write(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    if (!buffer || port >= 32) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = sata_write_sectors(port, lba, count, buffer);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
}

/* SYS_SATA_DETECT: Detect SATA device on port
 * Args: port
 */
static void syscall_sata_detect(uint32_t port)
{
    if (port >= 32) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = sata_detect_device(port);
    last_result.result = result;
    last_result.error_code = 0;
}

/* SYS_SATA_PROBE: Probe all SATA ports */
static void syscall_sata_probe(void)
{
    int result = sata_probe_ports();
    last_result.result = result;
    last_result.error_code = 0;
}

/**
 * GPIO Syscalls
 */

/* SYS_GPIO_CONFIG: Configure GPIO pin
 * Args: port (A-F as 0-5), pin (0-15), mode
 * Modes: 0=input, 1=output, 2=alternate, 3=analog
 */
static void syscall_gpio_config(uint8_t port, uint8_t pin, uint8_t mode)
{
    if (port > 5 || pin > 15) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = gpio_configure_pin(port, pin, mode);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    char port_char = 'A' + port;
    serial_puts(SERIAL_PORT_A, "[SYSCALL] GPIO Config: P");
    serial_putchar(SERIAL_PORT_A, port_char);
    serial_putchar(SERIAL_PORT_A, '0' + (pin % 10));
    serial_puts(SERIAL_PORT_A, " M");
    serial_putchar(SERIAL_PORT_A, '0' + mode);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
}

/* SYS_GPIO_SET: Set GPIO pin state
 * Args: port, pin, state (0=low, 1=high)
 */
static void syscall_gpio_set(uint8_t port, uint8_t pin, uint8_t state)
{
    if (port > 5 || pin > 15 || state > 1) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = gpio_set_pin(port, pin, state);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
}

/* SYS_GPIO_READ: Read GPIO pin state
 * Args: port, pin
 * Returns: 0=low, 1=high, <0=error
 */
static void syscall_gpio_read(uint8_t port, uint8_t pin)
{
    if (port > 5 || pin > 15) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    uint8_t value = gpio_read_pin(port, pin);
    last_result.result = value;
    last_result.error_code = 0;
    last_result.data = value;
}

/* SYS_GPIO_TOGGLE: Toggle GPIO pin state
 * Args: port, pin
 */
static void syscall_gpio_toggle(uint8_t port, uint8_t pin)
{
    if (port > 5 || pin > 15) {
        last_result.result = -1;
        last_result.error_code = 1;
        return;
    }
    
    int result = gpio_toggle_pin(port, pin);
    last_result.result = result;
    last_result.error_code = (result < 0) ? 2 : 0;
}

/**
 * Query syscalls
 */

/* SYS_DISK_INFO: Query disk device information
 * Returns number of ATA/SATA devices found
 */
static void syscall_disk_info(void)
{
    // This would query device info - for now just return count
    last_result.result = 0; /* Placeholder */
    last_result.error_code = 0;
}

/* SYS_GPIO_INFO: Query GPIO information
 * Returns: max ports (6), max pins per port (16), total pins (96)
 */
static void syscall_gpio_info(void)
{
    last_result.result = 6;     /* 6 ports */
    last_result.data = 16;      /* 16 pins per port */
    last_result.error_code = 0;
}

/**
 * syscall_dispatch()
 * 
 * Main syscall dispatcher. Routes syscalls to appropriate handlers.
 * 
 * Parameters:
 *   - syscall_num: Syscall number (0x100-0x13F)
 *   - arg0-arg4: Up to 5 arguments (varies by syscall)
 * 
 * Returns: syscall_result_t via global last_result
 */
void syscall_dispatch(uint32_t syscall_num, uint32_t arg0, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Dispatch\n");
    #endif
    
    switch (syscall_num) {
        /* ATA I/O Syscalls */
        case SYS_ATA_READ:
            syscall_ata_read((uint8_t)arg0, (uint8_t)arg1, (uint32_t)arg2, (uint16_t)arg3, (uint8_t*)arg4);
            break;
        case SYS_ATA_WRITE:
            syscall_ata_write((uint8_t)arg0, (uint8_t)arg1, (uint32_t)arg2, (uint16_t)arg3, (uint8_t*)arg4);
            break;
        case SYS_ATA_IDENTIFY:
            syscall_ata_identify((uint8_t)arg0, (uint8_t)arg1);
            break;
        case SYS_ATA_DETECT:
            syscall_ata_detect();
            break;
        
        /* SATA I/O Syscalls */
        case SYS_SATA_READ:
            syscall_sata_read((uint32_t)arg0, (uint32_t)arg1, (uint16_t)arg2, (uint8_t*)arg3);
            break;
        case SYS_SATA_WRITE:
            syscall_sata_write((uint32_t)arg0, (uint32_t)arg1, (uint16_t)arg2, (uint8_t*)arg3);
            break;
        case SYS_SATA_DETECT:
            syscall_sata_detect((uint32_t)arg0);
            break;
        case SYS_SATA_PROBE:
            syscall_sata_probe();
            break;
        
        /* GPIO Control Syscalls */
        case SYS_GPIO_CONFIG:
            syscall_gpio_config((uint8_t)arg0, (uint8_t)arg1, (uint8_t)arg2);
            break;
        case SYS_GPIO_SET:
            syscall_gpio_set((uint8_t)arg0, (uint8_t)arg1, (uint8_t)arg2);
            break;
        case SYS_GPIO_READ:
            syscall_gpio_read((uint8_t)arg0, (uint8_t)arg1);
            break;
        case SYS_GPIO_TOGGLE:
            syscall_gpio_toggle((uint8_t)arg0, (uint8_t)arg1);
            break;
        
        /* Query Syscalls */
        case SYS_DISK_INFO:
            syscall_disk_info();
            break;
        case SYS_GPIO_INFO:
            syscall_gpio_info();
            break;
        
        default:
            last_result.result = -1;
            last_result.error_code = 255; /* Unknown syscall */
            #ifdef CONFIG_SERIAL_DRIVER
            serial_puts(SERIAL_PORT_A, "[SYSCALL] Unknown syscall\n");
            #endif
            break;
    }
}

/**
 * syscall_get_result()
 * Retrieve the result from the last syscall
 */
syscall_result_t syscall_get_result(void)
{
    return last_result;
}

/**
 * syscall_init()
 * Initialize syscall subsystem
 * This is called during kernel boot
 */
void syscall_init(void)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Initializing syscall subsystem\n");
    #endif
    
    /* Initialize all drivers that have syscall support */
    #ifdef CONFIG_ATA_DRIVER
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Initializing ATA driver\n");
    #endif
    ata_init();
    #endif
    
    #ifdef CONFIG_SATA_DRIVER
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Initializing SATA driver\n");
    #endif
    sata_init();
    #endif
    
    #ifdef CONFIG_GPIO_DRIVER
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Initializing GPIO driver\n");
    #endif
    gpio_init();
    #endif
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[SYSCALL] Syscall subsystem ready\n");
    #endif
}
