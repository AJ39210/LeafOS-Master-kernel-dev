#include "printk.h"
#include "serial.h"
#include "ram.h"

/**
 * kernel/bootmsg.c
 * 
 * Boot message module.
 * Responsible for all boot-time messaging and debug output.
 * Handles both VGA and serial console output.
 */

void bootmsg_clear_screen(void)
{
    printk_clear();
}

void bootmsg_header(void)
{
    printk(VGA_LIGHT_GREY, "\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "LeafOS 0.1 (LeafOS 0.1 [build])\n");
    #endif
    printk(VGA_LIGHT_GREY, "LeafOS 0.1 (LeafOS 0.1 [build])\n");
}

void bootmsg_memory_map(void)
{
    printk(VGA_LIGHT_GREY, "BIOS-provided physical RAM map:\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "BIOS-provided physical RAM map:\n");
    ram_print_memory_map();
    #endif
    
    #ifdef CONFIG_RAM_DRIVER
    /* Print real memory map to VGA display */
    e820_entry_t mem_entries[32];
    int num_entries = ram_get_memory_map(mem_entries, 32);
    
    for (int i = 0; i < num_entries; i++) {
        uint64_t base = mem_entries[i].base_address;
        uint64_t end = base + mem_entries[i].length;
        
        printk(VGA_LIGHT_GREY, "BIOS-e820: [mem 0x");
        
        /* Print base address in hex */
        for (int j = 12; j >= 0; j--) {
            uint8_t nibble = (base >> (j * 4)) & 0xF;
            printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789ABCDEF"[nibble], 0});
        }
        
        printk(VGA_LIGHT_GREY, "-0x");
        
        /* Print end address in hex */
        for (int j = 12; j >= 0; j--) {
            uint8_t nibble = (end >> (j * 4)) & 0xF;
            printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789ABCDEF"[nibble], 0});
        }
        
        printk(VGA_LIGHT_GREY, "] ");
        
        switch (mem_entries[i].type) {
            case 1:
                printk(VGA_LIGHT_GREY, "usable\n");
                break;
            case 2:
                printk(VGA_LIGHT_GREY, "reserved\n");
                break;
            case 3:
                printk(VGA_LIGHT_GREY, "ACPI reclaim\n");
                break;
            case 4:
                printk(VGA_LIGHT_GREY, "ACPI NVS\n");
                break;
            default:
                printk(VGA_LIGHT_GREY, "type:");
                printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789"[mem_entries[i].type], 0});
                printk(VGA_LIGHT_GREY, "\n");
        }
    }
    #endif
    printk(VGA_LIGHT_GREY, "\n");
}

void bootmsg_multiboot(unsigned long magic)
{
    if (magic == 0x2BADB002) {
        #ifdef CONFIG_SERIAL_DRIVER
        serial_puts(SERIAL_PORT_A, "[    ] Bootloader: GRUB 2.04\n");
        serial_puts(SERIAL_PORT_A, "[0.000000] multiboot: 0x2BADB002\n");
        serial_puts(SERIAL_PORT_A, "[0.000000] multiboot: mmap: [0x0, 0x100000), type: 1\n");
        #endif
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "    ");
        printk(VGA_LIGHT_GREY, "    ");
        printk(VGA_GREEN, "] Bootloader: GRUB 2.04\n");
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "0.000000");
        printk(VGA_LIGHT_GREY, "] multiboot: 0x2BADB002\n");
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "0.000000");
        printk(VGA_LIGHT_GREY, "] multiboot: mmap: [0x0, 0x100000), type: 1\n");
    }
}

void bootmsg_status(void)
{
    printk(VGA_LIGHT_GREY, "\n");
    printk(VGA_CYAN, "[");
    printk(VGA_CYAN, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_CYAN, "] Status: Multiboot OK\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] Status: Multiboot OK\n");
    #endif
}

void bootmsg_drivers(void)
{
    #ifdef CONFIG_VGA_DRIVER
    printk(VGA_LIGHT_GREEN, "[");
    printk(VGA_LIGHT_GREEN, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREEN, "] VGA Driver: enabled\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] VGA Driver: enabled\n");
    #endif
    #endif
    
    #ifdef CONFIG_SERIAL_DRIVER
    printk(VGA_YELLOW, "[");
    printk(VGA_YELLOW, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_YELLOW, "] Serial Driver: enabled\n");
    serial_puts(SERIAL_PORT_A, "[    ] Serial Driver: enabled\n");
    #endif
}

void bootmsg_complete(void)
{
    printk(VGA_LIGHT_GREY, "[");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREY, "] Kernel Init Complete\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] Kernel Init Complete\n");
    #endif
    printk(VGA_LIGHT_GREY, "\n");
}
