#include "printk.h"
#include "serial.h"
#include "ram.h"
#include "vfs.h"
#include "fat12.h"
#include "fat16.h"
#include "fat32.h"
#include "exfat.h"
#include "ext2.h"
#include "vmm.h"
#include "panic.h"
#include "memdump.h"

/* Forward declarations for hardware drivers */
extern int ata_init(void);
extern int sata_init(void);
extern int gpio_init(void);

/* Forward declaration for syscall system */
extern void syscall_init(void);

/**
 * kernel/initializer.c
 * 
 * Kernel subsystem initialization module.
 * Responsible for initializing all drivers and filesystem modules
 * in the correct order with proper error handling.
 */

void kernel_init_serial(void)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_init(SERIAL_PORT_A);
    serial_puts(SERIAL_PORT_A, "=== LeafOS Serial Console ===\n");
    #endif
}

void kernel_init_memory(void)
{
    #ifdef CONFIG_RAM_DRIVER
    ram_driver_init();
    ram_detect_memory();
    #endif
}

void kernel_init_vfs(void)
{
    #ifdef CONFIG_VFS_DRIVER
    vfs_driver_init();
    vfs_mount_root();
    #endif
}

void kernel_init_filesystems(void)
{
    // Initialize filesystem drivers
    #ifdef CONFIG_FAT12_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT12 Filesystem: mounting\n");
    fat12_mount();
    #endif
    
    #ifdef CONFIG_FAT16_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT16 Filesystem: mounting\n");
    fat16_mount();
    #endif
    
    #ifdef CONFIG_FAT32_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT32 Filesystem: mounting\n");
    fat32_mount();
    #endif
    
    #ifdef CONFIG_EXFAT_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] exFAT Filesystem: mounting\n");
    exfat_mount();
    #endif
    
    #ifdef CONFIG_EXT2_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] ext2 Filesystem: mounting\n");
    ext2_mount();
    #endif
}

void kernel_init_hardware_drivers(void)
{
    #ifdef CONFIG_ATA_DRIVER
    serial_puts(SERIAL_PORT_A, "[INIT] ATA Driver: initializing\n");
    ata_init();
    #endif
    
    #ifdef CONFIG_SATA_DRIVER
    serial_puts(SERIAL_PORT_A, "[INIT] SATA Driver: initializing\n");
    sata_init();
    #endif
    
    #ifdef CONFIG_GPIO_DRIVER
    serial_puts(SERIAL_PORT_A, "[INIT] GPIO Driver: initializing\n");
    gpio_init();
    #endif
}

void kernel_init_syscalls(void)
{
    serial_puts(SERIAL_PORT_A, "[INIT] Syscall System: initializing\n");
    syscall_init();
}

void kernel_init_vmm(void)
{
    serial_puts(SERIAL_PORT_A, "[INIT] Virtual Memory Manager: initializing\n");
    vmm_init();
}

void kernel_init_panic(void)
{
    serial_puts(SERIAL_PORT_A, "[INIT] Kernel Panic Handler: ready\n");
}
