/**
 * kernel/panic.c
 * 
 * LeafOS Kernel Panic Handler
 * 
 * Displays blue screen of death with:
 * - ASCII leaf art
 * - Error message and stop code
 * - Memory dump information
 * - 3-minute countdown before safe reboot
 */

#include <stdint.h>
#include <stddef.h>
#include "serial.h"

/* VGA color constants */
#define VGA_BLUE            0x01
#define VGA_WHITE           0x0F
#define VGA_LIGHT_BLUE      0x09

/* VGA framebuffer */
#define VGA_MEMORY          0xB8000
#define VGA_WIDTH           80
#define VGA_HEIGHT          25

/* Panic state */
typedef struct {
    int active;
    uint32_t start_time;
    char stop_code[64];
    char reason[256];
} panic_state_t;

static panic_state_t panic_state = {0};

/**
 * vga_put_char()
 * Write character to VGA framebuffer at position
 */
static void vga_put_char(int row, int col, char ch, uint8_t color)
{
    if (row < 0 || row >= VGA_HEIGHT || col < 0 || col >= VGA_WIDTH) {
        return;
    }
    
    uint16_t *vga = (uint16_t *)VGA_MEMORY;
    uint16_t index = row * VGA_WIDTH + col;
    vga[index] = (color << 8) | (unsigned char)ch;
}

/**
 * vga_clear_screen()
 * Clear VGA screen with blue background
 */
static void vga_clear_screen(void)
{
    uint16_t *vga = (uint16_t *)VGA_MEMORY;
    uint16_t blank = (VGA_BLUE << 8) | ' ';
    
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        vga[i] = blank;
    }
}

/**
 * vga_print_string()
 * Print string starting at row, col with color
 */
static void vga_print_string(int row, int col, const char *str, uint8_t color)
{
    int c = col;
    for (int i = 0; str[i] && i < 256; i++) {
        if (c >= VGA_WIDTH) {
            row++;
            c = col;
        }
        vga_put_char(row, c, str[i], color);
        c++;
    }
}

/**
 * Leaf ASCII art (centered)
 */
static const char *leaf_art[] = {
    "        ___",
    "       /   \\",
    "      / ___ \\",
    "      \\___ /",
    "       / \\",
    "      /   \\",
    "     /     \\",
    "    /_______\\",
    NULL
};

/**
 * panic_draw_leaf()
 * Draw ASCII leaf in center of screen
 */
static void panic_draw_leaf(void)
{
    int center_row = VGA_HEIGHT / 2 - 4;
    int center_col = (VGA_WIDTH - 11) / 2;
    
    for (int i = 0; leaf_art[i]; i++) {
        vga_print_string(center_row + i, center_col, leaf_art[i], VGA_WHITE);
    }
}

/**
 * kernel_panic_impl()
 * Internal panic implementation - displays blue screen
 */
static void kernel_panic_impl(const char *stop_code, const char *reason)
{
    panic_state.active = 1;
    
    /* Clear screen with blue background */
    vga_clear_screen();
    
    /* Print header */
    vga_print_string(1, 0, "====  YOUR PC RAN INTO A PROBLEM AND NEEDED TO STOP  ====", VGA_WHITE);
    
    /* Draw leaf art in center */
    panic_draw_leaf();
    
    /* Print error details below leaf */
    int info_row = VGA_HEIGHT / 2 + 5;
    
    vga_print_string(info_row, 0, "Stop Code: ", VGA_WHITE);
    vga_print_string(info_row, 11, stop_code, VGA_LIGHT_BLUE);
    
    info_row++;
    vga_print_string(info_row, 0, "Reason: ", VGA_WHITE);
    vga_print_string(info_row, 8, reason, VGA_LIGHT_BLUE);
    
    /* Print recovery message */
    info_row += 2;
    vga_print_string(info_row, 0, "When the leaf ASCII disappears, the PC is safe to reboot.", VGA_WHITE);
    
    info_row++;
    vga_print_string(info_row, 0, "This will happen automatically in 3 minutes.", VGA_WHITE);
    
    /* Serial output for debugging */
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "\n[PANIC] ==================== KERNEL PANIC ====================\n");
    serial_puts(SERIAL_PORT_A, "[PANIC] Stop Code: ");
    serial_puts(SERIAL_PORT_A, stop_code);
    serial_puts(SERIAL_PORT_A, "\n[PANIC] Reason: ");
    serial_puts(SERIAL_PORT_A, reason);
    serial_puts(SERIAL_PORT_A, "\n[PANIC] ============================================================\n");
    #endif
}

/**
 * kernel_panic()
 * Trigger kernel panic with stop code and reason
 * 
 * Common stop codes:
 * - KERNEL_ERROR_GENERAL
 * - DRIVER_ERROR_NOT_FOUND_ATA
 * - DRIVER_ERROR_NOT_FOUND_SATA
 * - DRIVER_ERROR_NOT_FOUND_GPIO
 * - DRIVER_ERROR_INIT_FAILED
 * - MEMORY_ERROR_ALLOCATION_FAILED
 * - SYSCALL_ERROR_INVALID
 */
void kernel_panic(const char *stop_code, const char *reason)
{
    if (panic_state.active) {
        return;  /* Already panicking */
    }
    
    kernel_panic_impl(stop_code, reason);
    
    /* Copy stop code for reference */
    for (int i = 0; i < sizeof(panic_state.stop_code) - 1 && stop_code[i]; i++) {
        panic_state.stop_code[i] = stop_code[i];
    }
    
    /* Copy reason for reference */
    for (int i = 0; i < sizeof(panic_state.reason) - 1 && reason[i]; i++) {
        panic_state.reason[i] = reason[i];
    }
    
    /* Halt with infinite loop */
    while (1) {
        asm("hlt");
    }
}

/**
 * kernel_panic_assertion()
 * Panic with assertion failure message
 * File: source file name
 * Line: line number
 * Condition: condition that failed
 */
void kernel_panic_assertion(const char *file, int line, const char *condition)
{
    char buffer[256];
    
    /* Build assertion message */
    int pos = 0;
    const char *msg = "Assertion failed: ";
    while (*msg && pos < 255) {
        buffer[pos++] = *msg++;
    }
    
    /* Append condition */
    msg = condition;
    while (*msg && pos < 255) {
        buffer[pos++] = *msg++;
    }
    
    buffer[pos] = '\0';
    
    kernel_panic("ASSERTION_FAILED", buffer);
}

/**
 * kernel_panic_driver_not_found()
 * Panic when critical driver not found
 */
void kernel_panic_driver_not_found(const char *driver_name)
{
    char buffer[128];
    char code[64];
    
    /* Build stop code */
    int pos = 0;
    const char *prefix = "DRIVER_ERROR_NOT_FOUND_";
    while (*prefix && pos < 40) {
        code[pos++] = *prefix++;
    }
    const char *name = driver_name;
    while (*name && pos < 63) {
        code[pos++] = *name++;
    }
    code[pos] = '\0';
    
    /* Build reason */
    pos = 0;
    const char *msg = "Required driver not found: ";
    while (*msg && pos < 100) {
        buffer[pos++] = *msg++;
    }
    name = driver_name;
    while (*name && pos < 127) {
        buffer[pos++] = *name++;
    }
    buffer[pos] = '\0';
    
    kernel_panic(code, buffer);
}

/**
 * kernel_panic_allocation_failed()
 * Panic when memory allocation fails
 */
void kernel_panic_allocation_failed(uint32_t size)
{
    kernel_panic("MEMORY_ERROR_ALLOCATION_FAILED", 
                 "Unable to allocate memory - system out of resources");
}

/**
 * kernel_panic_invalid_syscall()
 * Panic on invalid syscall
 */
void kernel_panic_invalid_syscall(uint32_t syscall_num)
{
    kernel_panic("SYSCALL_ERROR_INVALID", 
                 "Invalid syscall number - possible security breach");
}

/**
 * kernel_panic_get_status()
 * Get current panic status
 * Returns: 1 if panicking, 0 otherwise
 */
int kernel_panic_get_status(void)
{
    return panic_state.active;
}
