#include "printk.h"
#include "string.h"
#include "serial.h"
#include "ram.h"
#include "vfs.h"
#include "fat12.h"
#include "fat16.h"
#include "fat32.h"
#include "exfat.h"
#include "ext2.h"

extern void kernel_main(unsigned long magic, unsigned long addr) {
    // Initialize serial for debugging output
    #ifdef CONFIG_SERIAL_DRIVER
    serial_init(SERIAL_PORT_A);
    serial_puts(SERIAL_PORT_A, "=== LeafOS Serial Console ===\n");
    #endif
    
    // Initialize RAM driver
    #ifdef CONFIG_RAM_DRIVER
    ram_driver_init();
    ram_detect_memory();
    #endif
    
    // Initialize VFS driver
    #ifdef CONFIG_VFS_DRIVER
    vfs_driver_init();
    vfs_mount_root();
    #endif
    
    printk_clear();
    
    // Linux-like boot messages
    printk(VGA_LIGHT_GREY, "\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "LeafOS 0.1 (LeafOS 0.1 [build])\n");
    #endif
    printk(VGA_LIGHT_GREY, "LeafOS 0.1 (LeafOS 0.1 [build])\n");
    printk(VGA_LIGHT_GREY, "BIOS-provided physical RAM map:\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "BIOS-provided physical RAM map:\n");
    ram_print_memory_map();
    #endif
    
    #ifdef CONFIG_RAM_DRIVER
    /* Print real memory map to VGA display */
    e820_entry_t mem_entries[32];
    int num_entries = ram_get_memory_map(mem_entries, 32);
    
    for (int i = 0; i < num_entries; i++) {
        uint64_t base = mem_entries[i].base_address;
        uint64_t end = base + mem_entries[i].length;
        
        printk(VGA_LIGHT_GREY, "BIOS-e820: [mem 0x");
        
        /* Print base address in hex */
        for (int j = 12; j >= 0; j--) {
            uint8_t nibble = (base >> (j * 4)) & 0xF;
            printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789ABCDEF"[nibble], 0});
        }
        
        printk(VGA_LIGHT_GREY, "-0x");
        
        /* Print end address in hex */
        for (int j = 12; j >= 0; j--) {
            uint8_t nibble = (end >> (j * 4)) & 0xF;
            printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789ABCDEF"[nibble], 0});
        }
        
        printk(VGA_LIGHT_GREY, "] ");
        
        switch (mem_entries[i].type) {
            case 1:
                printk(VGA_LIGHT_GREY, "usable\n");
                break;
            case 2:
                printk(VGA_LIGHT_GREY, "reserved\n");
                break;
            case 3:
                printk(VGA_LIGHT_GREY, "ACPI reclaim\n");
                break;
            case 4:
                printk(VGA_LIGHT_GREY, "ACPI NVS\n");
                break;
            default:
                printk(VGA_LIGHT_GREY, "type:");
                printk(VGA_LIGHT_GREY, (const char[]){(char)"0123456789"[mem_entries[i].type], 0});
                printk(VGA_LIGHT_GREY, "\n");
        }
    }
    #endif
    printk(VGA_LIGHT_GREY, "\n");
    
    // Multiboot info
    if (magic == 0x2BADB002) {
        #ifdef CONFIG_SERIAL_DRIVER
        serial_puts(SERIAL_PORT_A, "[    ] Bootloader: GRUB 2.04\n");
        serial_puts(SERIAL_PORT_A, "[0.000000] multiboot: 0x2BADB002\n");
        serial_puts(SERIAL_PORT_A, "[0.000000] multiboot: mmap: [0x0, 0x100000), type: 1\n");
        #endif
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "    ");
        printk(VGA_LIGHT_GREY, "    ");
        printk(VGA_GREEN, "] Bootloader: GRUB 2.04\n");
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "0.000000");
        printk(VGA_LIGHT_GREY, "] multiboot: 0x2BADB002\n");
        printk(VGA_GREEN, "[");
        printk(VGA_GREEN, "0.000000");
        printk(VGA_LIGHT_GREY, "] multiboot: mmap: [0x0, 0x100000), type: 1\n");
    }
    
    printk(VGA_LIGHT_GREY, "\n");
    printk(VGA_CYAN, "[");
    printk(VGA_CYAN, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_CYAN, "] Status: Multiboot OK\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] Status: Multiboot OK\n");
    #endif
    
    #ifdef CONFIG_VGA_DRIVER
    printk(VGA_LIGHT_GREEN, "[");
    printk(VGA_LIGHT_GREEN, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREEN, "] VGA Driver: enabled\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] VGA Driver: enabled\n");
    #endif
    #endif
    
    #ifdef CONFIG_SERIAL_DRIVER
    printk(VGA_YELLOW, "[");
    printk(VGA_YELLOW, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_YELLOW, "] Serial Driver: enabled\n");
    serial_puts(SERIAL_PORT_A, "[    ] Serial Driver: enabled\n");
    #endif
    
    // Initialize filesystem drivers
    #ifdef CONFIG_FAT12_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT12 Filesystem: mounting\n");
    fat12_mount();
    #endif
    
    #ifdef CONFIG_FAT16_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT16 Filesystem: mounting\n");
    fat16_mount();
    #endif
    
    #ifdef CONFIG_FAT32_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] FAT32 Filesystem: mounting\n");
    fat32_mount();
    #endif
    
    #ifdef CONFIG_EXFAT_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] exFAT Filesystem: mounting\n");
    exfat_mount();
    #endif
    
    #ifdef CONFIG_EXT2_FS
    printk(VGA_LIGHT_BLUE, "[");
    printk(VGA_LIGHT_BLUE, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_BLUE, "] ext2 Filesystem: mounting\n");
    ext2_mount();
    #endif
    
    printk(VGA_LIGHT_GREY, "[");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREY, "    ");
    printk(VGA_LIGHT_GREY, "] Kernel Init Complete\n");
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[    ] Kernel Init Complete\n");
    #endif
    printk(VGA_LIGHT_GREY, "\n");
    
    while (1) {
        asm("hlt");
    }
}

