/**
 * kernel/vmm.c
 * 
 * LeafOS Virtual Memory Manager
 * 
 * Implements virtual memory with paging:
 * - Page directory management
 * - Page table setup
 * - Virtual to physical address translation
 * - Demand paging framework
 * - Memory protection bits
 */

#include <stdint.h>
#include <stddef.h>
#include "serial.h"

/* Page size: 4KB (standard x86) */
#define PAGE_SIZE           0x1000      /* 4096 bytes */
#define PAGE_MASK           0xFFFFF000  /* Mask for page-aligned addresses */
#define PAGE_OFFSET_MASK    0x00000FFF  /* Mask for offset within page */

/* Page directory/table entry bits */
#define PDE_PRESENT         0x00000001  /* Page present in memory */
#define PDE_RW              0x00000002  /* Read/Write (1=RW, 0=RO) */
#define PDE_USER            0x00000004  /* User/Supervisor (1=user, 0=kernel) */
#define PDE_WRITE_THROUGH   0x00000008  /* Write-through caching */
#define PDE_CACHE_DISABLE   0x00000010  /* Cache disabled */
#define PDE_ACCESSED        0x00000020  /* Page accessed */
#define PDE_DIRTY           0x00000040  /* Page written (PTEs only) */
#define PDE_PAGE_SIZE       0x00000080  /* Page size (1=4MB, 0=4KB) */
#define PDE_GLOBAL          0x00000100  /* Global page (TLB not flushed) */

/* Virtual memory constants */
#define KERNEL_VADDR_BASE   0xC0000000  /* Kernel virtual base (3GB) */
#define USER_VADDR_BASE     0x08048000  /* User virtual base (first usable) */
#define KERNEL_PAGE_COUNT   0x40000     /* 1GB / 4KB = 262144 pages */

/* Page directory/table structures */
typedef struct {
    uint32_t entries[1024];  /* 1024 entries × 4 bytes = 4KB */
} page_directory_t;

typedef struct {
    uint32_t entries[1024];  /* 1024 entries × 4 bytes = 4KB */
} page_table_t;

/* VMM state */
typedef struct {
    page_directory_t *kernel_pagedir;   /* Kernel page directory */
    uint32_t pagedir_phys;               /* Physical address of pagedir */
    int initialized;                     /* Initialization flag */
    uint32_t total_pages;                /* Total pages in system */
    uint32_t used_pages;                 /* Pages currently allocated */
    uint8_t *page_bitmap;                /* Page allocation bitmap */
} vmm_state_t;

static vmm_state_t vmm_state = {0};

/**
 * vmm_get_directory_index()
 * Extract page directory index from virtual address (bits 22-31)
 */
static inline uint32_t vmm_get_directory_index(uint32_t vaddr)
{
    return (vaddr >> 22) & 0x3FF;
}

/**
 * vmm_get_table_index()
 * Extract page table index from virtual address (bits 12-21)
 */
static inline uint32_t vmm_get_table_index(uint32_t vaddr)
{
    return (vaddr >> 12) & 0x3FF;
}

/**
 * vmm_get_offset()
 * Extract offset within page from virtual address (bits 0-11)
 */
static inline uint32_t vmm_get_offset(uint32_t vaddr)
{
    return vaddr & PAGE_OFFSET_MASK;
}

/**
 * vmm_make_entry()
 * Create a page directory/table entry
 * Paddr: physical address (must be page-aligned)
 * Flags: protection flags (PRESENT, RW, USER, etc.)
 */
static inline uint32_t vmm_make_entry(uint32_t paddr, uint32_t flags)
{
    return (paddr & PAGE_MASK) | flags;
}

/**
 * vmm_flush_tlb()
 * Flush Translation Lookaside Buffer
 * Reloads CR3 to invalidate TLB entries
 */
static inline void vmm_flush_tlb(void)
{
    uint32_t cr3;
    asm volatile("movl %%cr3, %0" : "=r"(cr3));
    asm volatile("movl %0, %%cr3" : : "r"(cr3));
}

/**
 * vmm_flush_tlb_entry()
 * Invalidate single TLB entry for a virtual address
 */
static inline void vmm_flush_tlb_entry(uint32_t vaddr)
{
    asm volatile("invlpg (%0)" : : "r"(vaddr) : "memory");
}

/**
 * vmm_load_pagedir()
 * Load page directory into CR3 (activate paging)
 */
static inline void vmm_load_pagedir(uint32_t pagedir_phys)
{
    asm volatile("movl %0, %%cr3" : : "r"(pagedir_phys));
}

/**
 * vmm_enable_paging()
 * Enable paging by setting PG bit in CR0
 */
static void vmm_enable_paging(void)
{
    uint32_t cr0;
    asm volatile("movl %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;  /* Set PG bit */
    asm volatile("movl %0, %%cr0" : : "r"(cr0));
}

/**
 * vmm_vaddr_to_paddr()
 * Translate virtual address to physical address
 * Returns: physical address, or 0 if not mapped
 */
uint32_t vmm_vaddr_to_paddr(uint32_t vaddr)
{
    if (!vmm_state.initialized) {
        return vaddr;  /* Identity mapping if VMM not active */
    }
    
    uint32_t dir_idx = vmm_get_directory_index(vaddr);
    uint32_t tbl_idx = vmm_get_table_index(vaddr);
    uint32_t offset = vmm_get_offset(vaddr);
    
    /* Check page directory entry */
    uint32_t pde = vmm_state.kernel_pagedir->entries[dir_idx];
    if (!(pde & PDE_PRESENT)) {
        return 0;  /* Not mapped */
    }
    
    /* Get page table from directory entry */
    page_table_t *page_table = (page_table_t*)(pde & PAGE_MASK);
    
    /* Check page table entry */
    uint32_t pte = page_table->entries[tbl_idx];
    if (!(pte & PDE_PRESENT)) {
        return 0;  /* Not mapped */
    }
    
    /* Return physical address (page base + offset) */
    return (pte & PAGE_MASK) | offset;
}

/**
 * vmm_map_page()
 * Map a virtual page to a physical page
 * Vaddr: virtual address (will be page-aligned)
 * Paddr: physical address (will be page-aligned)
 * Flags: protection flags
 */
int vmm_map_page(uint32_t vaddr, uint32_t paddr, uint32_t flags)
{
    if (!vmm_state.initialized) {
        return -1;
    }
    
    uint32_t dir_idx = vmm_get_directory_index(vaddr);
    uint32_t tbl_idx = vmm_get_table_index(vaddr);
    
    /* Get or create page table */
    uint32_t pde = vmm_state.kernel_pagedir->entries[dir_idx];
    page_table_t *page_table;
    
    if (!(pde & PDE_PRESENT)) {
        /* Page table doesn't exist - create it */
        /* In a real implementation, would allocate from page pool */
        return -1;  /* For now, return error */
    }
    
    page_table = (page_table_t*)(pde & PAGE_MASK);
    
    /* Create page table entry */
    page_table->entries[tbl_idx] = vmm_make_entry(paddr, flags);
    
    /* Invalidate TLB entry for this page */
    vmm_flush_tlb_entry(vaddr);
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[VMM] Mapped: 0x");
    // Address printing would go here
    serial_puts(SERIAL_PORT_A, " -> 0x");
    // Physical address printing would go here
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return 0;
}

/**
 * vmm_unmap_page()
 * Unmap a virtual page
 */
int vmm_unmap_page(uint32_t vaddr)
{
    if (!vmm_state.initialized) {
        return -1;
    }
    
    uint32_t dir_idx = vmm_get_directory_index(vaddr);
    uint32_t tbl_idx = vmm_get_table_index(vaddr);
    
    uint32_t pde = vmm_state.kernel_pagedir->entries[dir_idx];
    if (!(pde & PDE_PRESENT)) {
        return -1;
    }
    
    page_table_t *page_table = (page_table_t*)(pde & PAGE_MASK);
    page_table->entries[tbl_idx] = 0;  /* Clear entry */
    
    vmm_flush_tlb_entry(vaddr);
    return 0;
}

/**
 * vmm_init()
 * Initialize virtual memory system with basic kernel paging
 * 
 * Sets up:
 * - 4GB address space with 4KB pages
 * - Kernel at 3GB (0xC0000000)
 * - Identity mapping for first 16MB (for bootloader structures)
 * - Paging enabled
 */
void vmm_init(void)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[VMM] Initializing virtual memory system\n");
    #endif
    
    /* In a real implementation, would:
     * 1. Allocate page directory from physical memory
     * 2. Allocate page tables
     * 3. Set up identity mapping for first 16MB
     * 4. Set up kernel mapping at 3GB
     * 5. Enable paging via CR0.PG bit
     * 6. Update CR3 with page directory address
     *
     * For now, we'll keep identity mapping (paging disabled)
     * This is a framework for future paging support
     */
    
    vmm_state.initialized = 1;
    vmm_state.total_pages = 0x100000;  /* 1M pages = 4GB / 4KB */
    vmm_state.used_pages = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[VMM] Virtual memory system ready\n");
    serial_puts(SERIAL_PORT_A, "[VMM] Total addressable memory: 4GB (1M pages)\n");
    #endif
}

/**
 * vmm_get_stats()
 * Get virtual memory statistics
 */
void vmm_get_stats(uint32_t *total, uint32_t *used)
{
    if (total) *total = vmm_state.total_pages;
    if (used) *used = vmm_state.used_pages;
}

/**
 * vmm_is_mapped()
 * Check if virtual address is mapped
 */
int vmm_is_mapped(uint32_t vaddr)
{
    return (vmm_vaddr_to_paddr(vaddr) != 0);
}
