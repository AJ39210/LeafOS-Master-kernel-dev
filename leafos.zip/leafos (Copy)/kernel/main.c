/**
 * kernel/main.c
 * 
 * LeafOS Kernel Main Entry Point
 * 
 * Orchestrates the boot process by calling initialization modules
 * in the proper sequence. This is the primary kernel entry point
 * called by the bootloader.
 */

#include <stdint.h>

// Forward declarations from initializer.c
extern void kernel_init_serial(void);
extern void kernel_init_memory(void);
extern void kernel_init_vfs(void);
extern void kernel_init_filesystems(void);
extern void kernel_init_hardware_drivers(void);
extern void kernel_init_syscalls(void);
extern void kernel_init_vmm(void);
extern void kernel_init_panic(void);

// Forward declarations from bootmsg.c
extern void bootmsg_clear_screen(void);
extern void bootmsg_header(void);
extern void bootmsg_memory_map(void);
extern void bootmsg_multiboot(unsigned long magic);
extern void bootmsg_status(void);
extern void bootmsg_drivers(void);
extern void bootmsg_complete(void);

// Forward declarations from SELeaf/seleaf.c
extern int seleaf_init(int mode);
extern int seleaf_encrypt_init(int algorithm);
extern int seleaf_set_encryption_key(uint8_t *key, uint32_t key_length);
extern int seleaf_kernel_protect_enable(void);

#define SELEAF_MODE_PERMISSIVE 1
#define SELEAF_ENC_XOR 1

// Kernel master key for encryption (static data)
static uint8_t kernel_master_key[32] = {
    0x4C, 0x65, 0x61, 0x66, 0x4F, 0x53, 0x53, 0x65,  // "LeafOSSe"
    0x6C, 0x65, 0x61, 0x66, 0x56, 0x31, 0x2E, 0x30,  // "leafV1.0"
    0x4B, 0x52, 0x59, 0x50, 0x54, 0x4F, 0x47, 0x52,  // "KRYPTOGR"
    0x41, 0x50, 0x48, 0x59, 0x32, 0x30, 0x32, 0x36   // "APHY2026"
};

/**
 * kernel_main()
 * 
 * Main kernel entry point called by bootloader (boot/boot.s).
 * 
 * Parameters:
 *   - magic: Multiboot magic number (0x2BADB002)
 *   - addr: Multiboot information structure address
 */
extern void kernel_main(unsigned long magic, unsigned long addr)
{
    // Phase 1: Initialize low-level communication
    // Serial console must be initialized first for debug output
    kernel_init_serial();
    
    // Phase 1B: Initialize panic handler early
    kernel_init_panic();
    
    // Phase 2: Initialize core hardware
    // Memory detection and VFS setup
    kernel_init_memory();
    kernel_init_vfs();
    
    // Phase 3: Clear display and print boot banner
    bootmsg_clear_screen();
    bootmsg_header();
    bootmsg_memory_map();
    
    // Phase 4: Bootloader information
    bootmsg_multiboot(magic);
    bootmsg_status();
    
    // Phase 5: Driver status
    bootmsg_drivers();
    
    // Phase 5B: Initialize SELeaf Security Module
    seleaf_init(SELEAF_MODE_PERMISSIVE);
    
    // Phase 5C: Initialize SELeaf Encryption
    seleaf_encrypt_init(SELEAF_ENC_XOR);
    
    // Set the default encryption key (kernel master key)
    seleaf_set_encryption_key(kernel_master_key, 32);
    
    // Enable kernel protection
    seleaf_kernel_protect_enable();
    
    // Phase 6: Initialize Virtual Memory Manager
    kernel_init_vmm();
    
    // Phase 7: Initialize hardware drivers (ATA, SATA, GPIO)
    kernel_init_hardware_drivers();
    
    // Phase 8: Initialize syscall system
    kernel_init_syscalls();
    
    // Phase 9: Initialize filesystems
    kernel_init_filesystems();
    
    // Phase 10: Boot complete
    bootmsg_complete();
    
    // Infinite loop - kernel stays alive
    while (1) {
        asm("hlt");
    }
}
