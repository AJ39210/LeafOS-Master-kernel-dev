/**
 * kernel/memdump.c
 * 
 * LeafOS Memory Inspector and Dumper
 * 
 * Provides:
 * - Memory hexdumps
 * - Memory statistics
 * - Memory range scanning
 * - Core dump capabilities (memory snapshot)
 */

#include <stdint.h>
#include <stddef.h>
#include "serial.h"

/* Memory dump buffer */
#define MEMDUMP_MAX_SIZE    (64 * 1024)  /* 64KB max dump */

typedef struct {
    uint32_t start_addr;
    uint32_t size;
    uint8_t buffer[MEMDUMP_MAX_SIZE];
    int valid;
} memdump_t;

static memdump_t core_dump = {0};

/**
 * mem_hexdump()
 * Print hex dump of memory to serial port
 * 
 * addr: starting address
 * size: number of bytes to dump
 * line_width: bytes per line (typically 16)
 */
void mem_hexdump(uint32_t addr, uint32_t size, int line_width)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "\n=== Memory Hexdump ===\n");
    serial_puts(SERIAL_PORT_A, "Address  : [hexadecimal] - [hexadecimal] (");
    serial_puts(SERIAL_PORT_A, " bytes)\n\n");
    
    if (line_width <= 0) line_width = 16;
    if (line_width > 64) line_width = 64;
    
    uint8_t *ptr = (uint8_t *)addr;
    uint32_t lines = (size + line_width - 1) / line_width;
    
    for (uint32_t line = 0; line < lines && line < 64; line++) {  /* Limit to 64 lines */
        /* Print address */
        serial_puts(SERIAL_PORT_A, "[addr]: ");
        
        /* Print hex values */
        uint32_t bytes_this_line = (size - (line * line_width) > line_width) ? line_width : (size - (line * line_width));
        
        for (int i = 0; i < line_width; i++) {
            if (i < bytes_this_line) {
                uint8_t byte = ptr[i];
                serial_puts(SERIAL_PORT_A, " [byte]");
            } else {
                serial_puts(SERIAL_PORT_A, "    ");
            }
        }
        
        serial_puts(SERIAL_PORT_A, " | ");
        
        /* Print ASCII representation */
        for (int i = 0; i < bytes_this_line; i++) {
            uint8_t ch = ptr[i];
            if (ch >= 32 && ch < 127) {
                serial_putchar(SERIAL_PORT_A, ch);
            } else {
                serial_putchar(SERIAL_PORT_A, '.');
            }
        }
        
        serial_puts(SERIAL_PORT_A, "\n");
        ptr += line_width;
    }
    
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
}

/**
 * mem_search()
 * Search for a byte pattern in memory
 * 
 * search_addr: starting address
 * search_size: size of search region
 * pattern: bytes to search for
 * pattern_size: length of pattern
 * 
 * Returns: address of first match, or 0 if not found
 */
uint32_t mem_search(uint32_t search_addr, uint32_t search_size, uint8_t *pattern, uint32_t pattern_size)
{
    uint8_t *ptr = (uint8_t *)search_addr;
    
    for (uint32_t i = 0; i < search_size - pattern_size; i++) {
        int match = 1;
        for (uint32_t j = 0; j < pattern_size; j++) {
            if (ptr[i + j] != pattern[j]) {
                match = 0;
                break;
            }
        }
        if (match) {
            return search_addr + i;
        }
    }
    
    return 0;
}

/**
 * mem_statistics()
 * Print memory statistics to serial
 */
void mem_statistics(void)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "\n=== Memory Statistics ===\n");
    
    /* Total addressable memory */
    serial_puts(SERIAL_PORT_A, "Total Memory: 4GB (32-bit addressing)\n");
    
    /* Memory zones */
    serial_puts(SERIAL_PORT_A, "Kernel Space: 0xC0000000 - 0xFFFFFFFF (1GB)\n");
    serial_puts(SERIAL_PORT_A, "User Space:   0x08048000 - 0xBFFFFFFF (3GB-ish)\n");
    serial_puts(SERIAL_PORT_A, "DMA Zone:     0x00000000 - 0x0FFFFFFF (256MB)\n");
    
    /* Page size */
    serial_puts(SERIAL_PORT_A, "Page Size: 4KB\n");
    serial_puts(SERIAL_PORT_A, "Total Pages: 1048576 (1M)\n");
    
    #endif
}

/**
 * mem_compare()
 * Compare two memory regions
 * 
 * Returns: 0 if identical, first differing byte offset if different
 */
uint32_t mem_compare(uint32_t addr1, uint32_t addr2, uint32_t size)
{
    uint8_t *ptr1 = (uint8_t *)addr1;
    uint8_t *ptr2 = (uint8_t *)addr2;
    
    for (uint32_t i = 0; i < size; i++) {
        if (ptr1[i] != ptr2[i]) {
            return i;
        }
    }
    
    return 0;  /* Identical */
}

/**
 * mem_fill()
 * Fill memory region with a value
 * 
 * addr: starting address
 * size: number of bytes
 * value: byte value to fill
 */
void mem_fill(uint32_t addr, uint32_t size, uint8_t value)
{
    uint8_t *ptr = (uint8_t *)addr;
    for (uint32_t i = 0; i < size; i++) {
        ptr[i] = value;
    }
}

/**
 * mem_copy()
 * Copy memory region
 * 
 * dest: destination address
 * src: source address
 * size: number of bytes
 */
void mem_copy(uint32_t dest, uint32_t src, uint32_t size)
{
    uint8_t *d = (uint8_t *)dest;
    uint8_t *s = (uint8_t *)src;
    for (uint32_t i = 0; i < size; i++) {
        d[i] = s[i];
    }
}

/**
 * memdump_capture_core()
 * Capture a region of memory for core dump
 * 
 * addr: starting address
 * size: number of bytes to capture
 * 
 * Returns: 0 on success, -1 if size too large
 */
int memdump_capture_core(uint32_t addr, uint32_t size)
{
    if (size > MEMDUMP_MAX_SIZE) {
        return -1;
    }
    
    mem_copy((uint32_t)core_dump.buffer, addr, size);
    
    core_dump.start_addr = addr;
    core_dump.size = size;
    core_dump.valid = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[MEMDUMP] Core dump captured\n");
    #endif
    
    return 0;
}

/**
 * memdump_dump_core()
 * Output captured core dump to serial
 */
void memdump_dump_core(void)
{
    if (!core_dump.valid) {
        #ifdef CONFIG_SERIAL_DRIVER
        serial_puts(SERIAL_PORT_A, "[MEMDUMP] No core dump available\n");
        #endif
        return;
    }
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "\n=== Core Dump ===\n");
    #endif
    
    mem_hexdump((uint32_t)core_dump.buffer, core_dump.size, 16);
}

/**
 * mem_checksum()
 * Calculate simple checksum of memory region
 */
uint32_t mem_checksum(uint32_t addr, uint32_t size)
{
    uint32_t sum = 0;
    uint8_t *ptr = (uint8_t *)addr;
    
    for (uint32_t i = 0; i < size; i++) {
        sum += ptr[i];
    }
    
    return sum;
}

/**
 * mem_scan_for_pattern()
 * Scan entire memory for pattern and report all matches
 */
void mem_scan_for_pattern(uint8_t *pattern, uint32_t pattern_size)
{
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[MEMSCAN] Scanning for pattern... (max 10 matches)\n");
    #endif
    
    int matches = 0;
    uint32_t addr = 0;
    
    /* Limit search to avoid hanging */
    while (addr < 0x10000000 && matches < 10) {
        uint32_t found = mem_search(addr, 0x1000, pattern, pattern_size);
        if (found == 0) {
            addr += 0x1000;
        } else {
            #ifdef CONFIG_SERIAL_DRIVER
            serial_puts(SERIAL_PORT_A, "  Match found\n");
            #endif
            matches++;
            addr = found + pattern_size;
        }
    }
    
    #ifdef CONFIG_SERIAL_DRIVER
    if (matches == 0) {
        serial_puts(SERIAL_PORT_A, "  No matches found\n");
    }
    #endif
}
