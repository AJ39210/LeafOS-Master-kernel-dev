#include "fat12.h"
#include "serial.h"
#include <stddef.h>

static int fat12_mounted = 0;

int fat12_mount(void) {
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT12] Mounting FAT12 filesystem...\n");
    #endif
    
    fat12_mounted = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT12] FAT12 filesystem mounted successfully\n");
    #endif
    
    return 0;
}

int fat12_unmount(void) {
    fat12_mounted = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT12] FAT12 filesystem unmounted\n");
    #endif
    
    return 0;
}

int fat12_read_file(const char *filename, void *buffer, uint32_t size) {
    if (!fat12_mounted || !filename || !buffer) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT12] Reading file: ");
    serial_puts(SERIAL_PORT_A, filename);
    serial_puts(SERIAL_PORT_A, " size=");
    serial_putchar(SERIAL_PORT_A, "0123456789"[(size / 100) % 10]);
    serial_putchar(SERIAL_PORT_A, "0123456789"[(size / 10) % 10]);
    serial_putchar(SERIAL_PORT_A, "0123456789"[size % 10]);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return size;
}

int fat12_list_directory(void) {
    if (!fat12_mounted) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT12] Directory listing:\n");
    serial_puts(SERIAL_PORT_A, "[FAT12]   boot.bin\n");
    serial_puts(SERIAL_PORT_A, "[FAT12]   kernel.bin\n");
    #endif
    
    return 0;
}

int fat12_get_file_size(const char *filename) {
    if (!fat12_mounted || !filename) return -1;
    return 4096;
}
