#include "fat32.h"
#include "serial.h"
#include <stddef.h>

static int fat32_mounted = 0;

int fat32_mount(void) {
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT32] Mounting FAT32 filesystem...\n");
    #endif
    
    fat32_mounted = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT32] FAT32 filesystem mounted successfully\n");
    #endif
    
    return 0;
}

int fat32_unmount(void) {
    fat32_mounted = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT32] FAT32 filesystem unmounted\n");
    #endif
    
    return 0;
}

int fat32_read_file(const char *filename, void *buffer, uint32_t size) {
    if (!fat32_mounted || !filename || !buffer) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT32] Reading file: ");
    serial_puts(SERIAL_PORT_A, filename);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return size;
}

int fat32_list_directory(void) {
    if (!fat32_mounted) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT32] Directory listing\n");
    #endif
    
    return 0;
}
