#include "ext2.h"
#include "serial.h"
#include <stddef.h>

static int ext2_mounted = 0;

int ext2_mount(void) {
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[ext2] Mounting ext2 filesystem...\n");
    #endif
    
    ext2_mounted = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[ext2] ext2 filesystem mounted successfully\n");
    #endif
    
    return 0;
}

int ext2_unmount(void) {
    ext2_mounted = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[ext2] ext2 filesystem unmounted\n");
    #endif
    
    return 0;
}

int ext2_read_file(const char *filename, void *buffer, uint32_t size) {
    if (!ext2_mounted || !filename || !buffer) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[ext2] Reading file: ");
    serial_puts(SERIAL_PORT_A, filename);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return size;
}

int ext2_list_directory(void) {
    if (!ext2_mounted) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[ext2] Directory listing\n");
    #endif
    
    return 0;
}
