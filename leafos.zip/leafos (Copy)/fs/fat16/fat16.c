#include "fat16.h"
#include "serial.h"
#include <stddef.h>

static int fat16_mounted = 0;

int fat16_mount(void) {
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT16] Mounting FAT16 filesystem...\n");
    #endif
    
    fat16_mounted = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT16] FAT16 filesystem mounted successfully\n");
    #endif
    
    return 0;
}

int fat16_unmount(void) {
    fat16_mounted = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT16] FAT16 filesystem unmounted\n");
    #endif
    
    return 0;
}

int fat16_read_file(const char *filename, void *buffer, uint32_t size) {
    if (!fat16_mounted || !filename || !buffer) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT16] Reading file: ");
    serial_puts(SERIAL_PORT_A, filename);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return size;
}

int fat16_list_directory(void) {
    if (!fat16_mounted) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[FAT16] Directory listing\n");
    #endif
    
    return 0;
}
