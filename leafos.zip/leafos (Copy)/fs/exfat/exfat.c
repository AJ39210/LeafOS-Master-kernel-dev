#include "exfat.h"
#include "serial.h"
#include <stddef.h>

static int exfat_mounted = 0;

int exfat_mount(void) {
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[exFAT] Mounting exFAT filesystem...\n");
    #endif
    
    exfat_mounted = 1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[exFAT] exFAT filesystem mounted successfully\n");
    #endif
    
    return 0;
}

int exfat_unmount(void) {
    exfat_mounted = 0;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[exFAT] exFAT filesystem unmounted\n");
    #endif
    
    return 0;
}

int exfat_read_file(const char *filename, void *buffer, uint32_t size) {
    if (!exfat_mounted || !filename || !buffer) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[exFAT] Reading file: ");
    serial_puts(SERIAL_PORT_A, filename);
    serial_puts(SERIAL_PORT_A, "\n");
    #endif
    
    return size;
}

int exfat_list_directory(void) {
    if (!exfat_mounted) return -1;
    
    #ifdef CONFIG_SERIAL_DRIVER
    serial_puts(SERIAL_PORT_A, "[exFAT] Directory listing\n");
    #endif
    
    return 0;
}
