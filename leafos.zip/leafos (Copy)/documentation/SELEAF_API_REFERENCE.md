/**
 * SELeaf API Quick Reference
 */

# SELeaf Security Framework - API Quick Reference

## Core Headers

```c
#include "SELeaf/policy.h"        /* Capability-based policies */
#include "SELeaf/syscall_filter.h" /* Syscall filtering */
#include "SELeaf/audit.h"          /* Audit logging */
#include "SELeaf/labels.h"         /* Process/file labels */
#include "SELeaf/sandbox.h"        /* Sandbox isolation */
```

## Capability Policy API

### Initialization
```c
int policy_init(void);
```

### Rule Management
```c
/* Add capability rule */
uint32_t policy_add_rule(const char *name,
                        policy_action_t action,  /* ALLOW/DENY/AUDIT */
                        capability_t cap,        /* Capability type */
                        uint32_t target_id,      /* Process ID */
                        int learning);           /* Learning mode flag */
```

### Enforcement
```c
/* Check if process has capability */
int policy_check_capability(capability_t cap, uint32_t process_id);
```

### Learning Mode
```c
int policy_enable_learning_mode(void);   /* Audit without enforcement */
int policy_disable_learning_mode(void);  /* Enable enforcement */
int policy_get_learning_mode(void);      /* Query current state */
```

### Hot-Reload
```c
int policy_hot_reload(void);  /* Clear and reload all policies */
```

### Statistics
```c
void policy_get_stats(uint32_t *total_rules, uint32_t *violations);
const char *capability_name(capability_t cap);
```

## Syscall Filter API

### Initialization
```c
int syscall_filter_init(void);
```

### Profile Management
```c
/* Create filter profile */
uint32_t syscall_filter_create_profile(const char *name);

/* Add rule to profile */
int syscall_filter_add_rule(uint32_t profile_id,
                           uint32_t syscall_num,
                           syscall_filter_action_t action,  /* ALLOW/DENY/KILL/TRACE */
                           uint32_t arg_mask);
```

### Enforcement
```c
/* Check if syscall allowed */
int syscall_filter_check(uint32_t profile_id,
                        uint32_t syscall_num,
                        uint32_t *args);

/* Activate profile for enforcement */
int syscall_filter_activate_profile(uint32_t profile_id);

/* Deactivate profile */
int syscall_filter_deactivate_profile(uint32_t profile_id);
```

### Statistics
```c
void syscall_filter_get_stats(uint32_t *violations, uint32_t *allowed);
const char *filter_action_name(syscall_filter_action_t action);
```

## Audit Logging API

### Initialization
```c
int audit_init(void);
```

### Logging
```c
/* Log security event */
int audit_log_event(audit_event_type_t type,  /* Event type */
                   uint32_t pid,               /* Process ID */
                   uint32_t data0,             /* Custom data */
                   uint32_t data1,
                   uint32_t data2,
                   uint32_t data3);
```

### Configuration
```c
int audit_set_level(audit_level_t level);   /* DISABLED/ERRORS/ALL/VERBOSE */
int audit_enable(void);                     /* Enable logging */
int audit_disable(void);                    /* Disable logging */
int audit_get_level(void);                  /* Query current level */
```

### Inspection
```c
void audit_dump_recent(uint32_t count);     /* Display recent events */
void audit_clear_log(void);                 /* Clear audit buffer */
void audit_get_stats(uint32_t *total, uint32_t *buffered);
const char *audit_event_name(audit_event_type_t type);
```

## Label System API

### Initialization
```c
int label_init(void);
```

### Label Creation
```c
/* Create new label */
uint32_t label_create(label_type_t type,    /* Label type */
                     const char *name,      /* Human-readable name */
                     uint32_t permissions); /* Permission bitmask */
```

### Process Labels
```c
int label_assign_process(uint32_t process_id, uint32_t label_id);
uint32_t label_get_process(uint32_t process_id);
```

### File Labels
```c
int label_assign_file(uint32_t inode, uint32_t label_id);
uint32_t label_get_file(uint32_t inode);
```

### Access Control
```c
int label_check_access(uint32_t from_label,  /* Source label */
                      uint32_t to_label,     /* Target label */
                      uint32_t operation);   /* Operation type */
```

### Information
```c
const char *label_type_name(label_type_t type);
void label_get_stats(uint32_t *total_labels,
                    uint32_t *proc_labels,
                    uint32_t *file_labels);
```

## Sandbox API

### Initialization
```c
int sandbox_init(void);
```

### Process Sandboxing
```c
/* Enable sandbox for process */
int sandbox_enable_process(uint32_t process_id,
                          uint32_t capabilities,  /* Operation bitmask */
                          uint32_t max_memory_kb);

/* Disable sandbox */
int sandbox_disable_process(uint32_t process_id);

/* Check if sandbox active */
int sandbox_is_active(uint32_t process_id);
```

### Operation Checks
```c
/* Check if operation allowed in sandbox */
int sandbox_check_operation(uint32_t process_id, uint32_t operation);

/* Check memory allocation */
int sandbox_check_memory(uint32_t process_id,
                        uint32_t size_kb,
                        uint32_t current_kb);

/* Check file size */
int sandbox_check_file_size(uint32_t process_id, uint32_t size_kb);
```

### Configuration
```c
int sandbox_set_max_open_files(uint32_t process_id, uint32_t max);
int sandbox_set_device_access(uint32_t process_id, uint32_t device_mask);
```

### Statistics
```c
void sandbox_get_stats(uint32_t *total_sandboxes,
                      uint32_t *escape_attempts,
                      uint32_t *policy_violations);

void sandbox_reset_stats(void);
```

## Common Usage Patterns

### Pattern 1: Restrict Process to Read-Only

```c
/* Create untrusted label */
uint32_t untrusted = label_create(LABEL_UNTRUSTED, "app", 0);
label_assign_process(pid, untrusted);

/* Only allow file reading */
policy_add_rule("read_only", POLICY_ALLOW, 
                CAP_FILE_READ, pid, 0);
policy_add_rule("no_write", POLICY_DENY, 
                CAP_FILE_WRITE, pid, 0);
```

### Pattern 2: Sandbox Network Service

```c
/* Create network sandbox */
uint32_t ops = SANDBOX_OP_NETWORK_SEND | SANDBOX_OP_NETWORK_RECV;
sandbox_enable_process(server_pid, ops, 512*1024);

/* Restrict syscalls */
uint32_t profile = syscall_filter_create_profile("net_svc");
syscall_filter_add_rule(profile, SYS_sendto, SYSCALL_FILTER_ALLOW, 0);
syscall_filter_add_rule(profile, SYS_recvfrom, SYSCALL_FILTER_ALLOW, 0);
syscall_filter_add_rule(profile, SYS_socket, SYSCALL_FILTER_ALLOW, 0);
syscall_filter_activate_profile(profile);
```

### Pattern 3: Enable Learning Mode

```c
/* Start in learning mode */
policy_enable_learning_mode();

/* System runs and logs all operations */
sleep(1000);

/* Analyze logs */
audit_dump_recent(100);

/* Switch to enforcement */
policy_disable_learning_mode();
```

### Pattern 4: Monitor for Escape Attempts

```c
/* Enable audit logging */
audit_set_level(AUDIT_LEVEL_ALL);

/* Sandbox process */
sandbox_enable_process(untrusted_pid, 
                      SANDBOX_OP_FILE_READ,
                      64*1024);

/* Periodic monitoring */
while (1) {
    uint32_t escapes, violations;
    sandbox_get_stats(NULL, &escapes, &violations);
    
    if (escapes > 0) {
        printf("WARNING: %d escape attempts blocked!\n", escapes);
    }
    
    sleep(1);
}
```

### Pattern 5: Label-Based Access Control

```c
/* Create labels */
uint32_t trusted = label_create(LABEL_TRUSTED, "browser", 0xFFFF);
uint32_t restricted = label_create(LABEL_SANDBOXED, "plugin", 0x0001);

/* Assign labels */
label_assign_process(browser_pid, trusted);
label_assign_process(plugin_pid, restricted);
label_assign_file(sensitive_file, restricted);

/* Check access before file operation */
if (label_check_access(plugin_label, restricted, OP_FILE_READ)) {
    /* Access allowed */
    open_file(sensitive_file);
}
```

## Error Codes

```c
-1      /* Generic error / not found */
-EPERM  /* Permission denied (policy violation) */
-EACCES /* Access denied (label/sandbox violation) */
-ENOMEM /* Out of memory / table full */
```

## Configuration Defines

```c
#define LABEL_MAX               64      /* Max labels */
#define PROCESS_LABEL_MAX       128     /* Max process labels */
#define FILE_LABEL_MAX          256     /* Max file labels */
#define SANDBOX_MAX             32      /* Max active sandboxes */
#define AUDIT_BUFFER_SIZE       1024    /* Audit event buffer */
```

## Compile-Time Flags

```makefile
# Enable serial logging (recommended for debugging)
CFLAGS += -DCONFIG_SERIAL_DRIVER=1

# Enable audit system
CFLAGS += -DCONFIG_AUDIT_LOGGING=1

# Set initial audit level
CFLAGS += -DCONFIG_AUDIT_LEVEL=2  # LEVEL_ALL
```

## Performance Tips

1. **Minimize policy rules**: Fewer rules = faster lookup
2. **Use syscall filters**: Catch unauthorized calls early
3. **Enable learning mode first**: Generate optimal policies
4. **Batch label operations**: Assign multiple labels efficiently
5. **Monitor audit buffer**: Prevent overflow in high-frequency systems

---

**See Also**:
- SELEAF_SECURITY_FRAMEWORK.md - Comprehensive documentation
- policy.h - Full capability definitions
- sandbox.h - Sandbox operation flags
- audit.h - Event type definitions
