# LeafOS Filesystem Support

## Overview

LeafOS now includes modular support for 5 different filesystems with a clean separation of concerns via the `fs/` directory structure.

## Supported Filesystems

### 1. FAT12 (`fs/fat12/`)
- **Purpose**: Legacy floppy disk support
- **Location**: `/home/leafos/leafos/fs/fat12/fat12.c`
- **Configuration**: `CONFIG_FAT12_FS=y/n`
- **Features**:
  - 512-byte sector size
  - 1.44MB floppy disk support
  - Boot sector parsing
  - Directory enumeration
  - File read operations

### 2. FAT16 (`fs/fat16/`)
- **Purpose**: Legacy USB and IDE drives
- **Location**: `/home/leafos/leafos/fs/fat16/fat16.c`
- **Configuration**: `CONFIG_FAT16_FS=y/n`
- **Features**:
  - 16-bit FAT chain support
  - Up to 4GB volumes
  - Extended boot sector support
  - Root directory enumeration
  - Cluster chain following

### 3. FAT32 (`fs/fat32/`)
- **Purpose**: Modern USB drives and SD cards
- **Location**: `/home/leafos/leafos/fs/fat32/fat32.c`
- **Configuration**: `CONFIG_FAT32_FS=y/n`
- **Features**:
  - 32-bit FAT chain support
  - 4096-byte sector support
  - Up to 16TB volumes
  - Flexible root cluster location
  - LFN (Long Filename) ready

### 4. exFAT (`fs/exfat/`)
- **Purpose**: Large file support (files >4GB)
- **Location**: `/home/leafos/leafos/fs/exfat/exfat.c`
- **Configuration**: `CONFIG_EXFAT_FS=y/n`
- **Features**:
  - 64-bit partition offsets
  - Bitmap-based allocation
  - File fragmentation tracking
  - Large file support
  - Up to 128PB volumes

### 5. ext2 (`fs/ext2/`)
- **Purpose**: Linux filesystem compatibility
- **Location**: `/home/leafos/leafos/fs/ext2/ext2.c`
- **Configuration**: `CONFIG_EXT2_FS=y/n`
- **Features**:
  - Superblock parsing
  - Inode structures with 12 direct + 3 indirect pointers
  - Block group management
  - Symbolic link support
  - File permissions and ownership

## Directory Structure

```
fs/
├── fat12/
│   └── fat12.c
├── fat16/
│   └── fat16.c
├── fat32/
│   └── fat32.c
├── exfat/
│   └── exfat.c
└── ext2/
    └── ext2.c
```

## Headers

All filesystem headers are located in `include/`:
- `include/fat12.h` - FAT12 structures and function declarations
- `include/fat16.h` - FAT16 structures and function declarations
- `include/fat32.h` - FAT32 structures and function declarations
- `include/exfat.h` - exFAT structures and function declarations
- `include/ext2.h` - ext2 structures and function declarations

## Shared Functions

All filesystems implement these core functions:

```c
int fs_mount(void);              // Mount the filesystem
int fs_unmount(void);            // Unmount the filesystem
int fs_read_file(const char *filename, uint8_t *buffer, uint32_t size);
int fs_list_directory(void);     // List directory contents
int fs_get_file_size(const char *filename);
```

## Build Configuration

### Enable/Disable Filesystems

Edit `.config` to enable or disable specific filesystems:

```
CONFIG_FAT12_FS=y    # Enable FAT12
CONFIG_FAT16_FS=y    # Enable FAT16
CONFIG_FAT32_FS=y    # Enable FAT32
CONFIG_EXFAT_FS=y    # Enable exFAT
CONFIG_EXT2_FS=y     # Enable ext2
```

### Rebuild Kernel

```bash
cd /home/leafos/leafos
make clean
make run     # Builds and boots in QEMU
```

## Makefile Integration

The Makefile automatically:
1. Reads filesystem configuration from `.config`
2. Sets `CONFIG_*_FS` preprocessor definitions
3. Compiles only enabled filesystem drivers
4. Links filesystem objects into kernel binary
5. Displays compilation messages during build

## Serial Debug Output

During boot, each filesystem logs initialization to the serial console (COM1):

```
[    ] FAT12 Filesystem: mounting
[    ] FAT16 Filesystem: mounting
[    ] FAT32 Filesystem: mounting
[    ] exFAT Filesystem: mounting
[    ] ext2 Filesystem: mounting
```

## Memory Layout

All filesystems:
- Use the VFS driver for file operations
- Store metadata in kernel memory (not on actual media)
- Support file descriptor table with 32 slots
- Maintain per-filesystem mount state

## Future Enhancements

1. **Actual Media Reading**: Replace stubs with real disk I/O
2. **Filesystem Detection**: Auto-detect filesystem on boot
3. **Write Support**: Implement file creation and modification
4. **fsck**: Add filesystem consistency checking
5. **Performance**: Add caching and prefetching

## Testing

### Build Status ✓
- All 5 filesystems compile without errors
- Kernel binary: 24KB
- Object files successfully linked

### Execution Status ✓
- Filesystem initialization called during boot
- Serial logging shows all filesystems mounted
- VGA displays filesystem mount messages
- No compilation warnings for filesystem code

### Compilation Summary

```
Filesystem Drivers Compiled:
  fat12.o  (2.0K)
  fat16.o  (1.5K)
  fat32.o  (1.5K)
  exfat.o  (1.5K)
  ext2.o   (1.5K)

Total Filesystem Code: 8.0K
Total Kernel Binary: 24K
```
