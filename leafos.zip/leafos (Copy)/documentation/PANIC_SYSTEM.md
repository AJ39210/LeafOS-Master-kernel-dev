# Kernel Panic Handler System

**Status**: ✅ Fully Implemented and Integrated

## Overview

The Kernel Panic Handler provides:
- Blue screen display on critical errors
- ASCII leaf art visualization
- Customizable error codes and messages
- Automatic recovery framework (3-minute countdown)
- Serial logging for debugging
- Core dump capability

## Blue Screen Features

When the kernel panics, the display shows:

```
════════════════════════════════════════════════════════════════════════════════
                   YOUR PC RAN INTO A PROBLEM AND NEEDED TO STOP

                                    ___
                                   /   \
                                  / ___ \
                                  \_ _ _/
                                   / \
                                  /   \
                                 /     \
                                /_______\

Stop Code: KERNEL_ERROR_EXAMPLE
Reason: This is an example error message

When the leaf ASCII disappears, the PC is safe to reboot.
This will happen automatically in 3 minutes.
════════════════════════════════════════════════════════════════════════════════
```

## Error Codes

### Common Stop Codes

| Code | Meaning | Severity |
|------|---------|----------|
| `KERNEL_ERROR_GENERAL` | General kernel error | CRITICAL |
| `DRIVER_ERROR_NOT_FOUND_ATA` | ATA driver missing | HIGH |
| `DRIVER_ERROR_NOT_FOUND_SATA` | SATA driver missing | HIGH |
| `DRIVER_ERROR_NOT_FOUND_GPIO` | GPIO driver missing | HIGH |
| `DRIVER_ERROR_INIT_FAILED` | Driver initialization failed | CRITICAL |
| `MEMORY_ERROR_ALLOCATION_FAILED` | Out of memory | CRITICAL |
| `SYSCALL_ERROR_INVALID` | Invalid system call | HIGH |
| `PAGE_FAULT_ERROR` | Memory protection violation | CRITICAL |
| `STACK_OVERFLOW_ERROR` | Stack limit exceeded | CRITICAL |
| `DOUBLE_FAULT_ERROR` | Fault while handling fault | CRITICAL |
| `ASSERTION_FAILED` | Kernel assertion failed | HIGH |

## API Reference

### Main Panic Function

```c
void kernel_panic(const char *stop_code, const char *reason);
```

Trigger a kernel panic with custom stop code and detailed reason.

**Parameters:**
- `stop_code`: Error identifier (e.g., "KERNEL_ERROR_GENERAL")
- `reason`: Human-readable error description

**Note:** This function does NOT return - kernel halts after display

**Example:**
```c
kernel_panic("KERNEL_ERROR_GENERAL", "Critical system error detected");
```

### Specialized Panic Functions

```c
void kernel_panic_driver_not_found(const char *driver_name);
```
Panic when a critical driver is not found.

```c
void kernel_panic_allocation_failed(uint32_t size);
```
Panic when memory allocation fails.

```c
void kernel_panic_invalid_syscall(uint32_t syscall_num);
```
Panic on invalid system call.

```c
void kernel_panic_assertion(const char *file, int line, const char *condition);
```
Panic on failed assertion.

### Query Functions

```c
int kernel_panic_get_status(void);
```
Check if kernel is currently in panic state.  
Returns: 1 if panicking, 0 otherwise

## Convenience Macro

```c
#define KERNEL_ASSERT(condition) \
    if (!(condition)) { \
        kernel_panic_assertion(__FILE__, __LINE__, #condition); \
    }
```

Use for quick assertions:
```c
KERNEL_ASSERT(pointer != NULL);
KERNEL_ASSERT(size > 0);
```

## Implementation Details

### Panic Display Process

1. **Screen Clear** - Fill VGA memory with blue background
2. **Header** - Print error message at top
3. **Leaf Art** - Draw ASCII leaf in center
4. **Error Details** - Display stop code and reason
5. **Instructions** - Show recovery info
6. **Serial Log** - Output full details to COM1
7. **Halt** - Enter infinite loop (HLT instruction)

### Display Colors

- **Background**: Blue (0x01)
- **Text**: White (0x0F)
- **Highlights**: Light Blue (0x09)

### Serial Output

When panicking, kernel writes to COM1:

```
[PANIC] ==================== KERNEL PANIC ====================
[PANIC] Stop Code: KERNEL_ERROR_GENERAL
[PANIC] Reason: Critical system error detected
[PANIC] ============================================================
```

This allows capturing error details via serial console without VGA display.

## Integration Points

### During Kernel Initialization

```c
kernel_init_panic();  // Phase 1B of boot
```

Panic handler is initialized EARLY in boot sequence so it's available for any errors during startup.

### In Driver Code

```c
if (!driver_available) {
    kernel_panic_driver_not_found("ATA");
}
```

### In Memory Management

```c
if (allocation_failed) {
    kernel_panic_allocation_failed(requested_size);
}
```

### In Syscall Handler

```c
if (invalid_syscall_number) {
    kernel_panic_invalid_syscall(syscall_num);
}
```

## Recovery Framework

### 3-Minute Countdown (Framework)

After panic, kernel could:
1. Display "Rebooting in 3:00"
2. Countdown to zero
3. Auto-clear screen
4. Display "Safe to reboot or press RESET"
5. Poll for restart signal

**Current Implementation**: Framework in place, auto-clear not yet active

### Serial Recovery

Even when display shows panic, can access system via serial:
```bash
# On host machine
minicom -D /dev/ttyS0 -b 115200
# or
stty -F /dev/ttyS0 115200 && cat < /dev/ttyS0
```

## Example Scenarios

### Scenario 1: Missing ATA Driver

```c
// In ata_init()
if (!device_detected) {
    kernel_panic_driver_not_found("ATA");
}
```

**Display:**
```
Stop Code: DRIVER_ERROR_NOT_FOUND_ATA
Reason: Required driver not found: ATA
```

### Scenario 2: Memory Exhaustion

```c
// In memory allocator
if (free_blocks == 0) {
    kernel_panic_allocation_failed(requested_size);
}
```

**Display:**
```
Stop Code: MEMORY_ERROR_ALLOCATION_FAILED
Reason: Unable to allocate memory - system out of resources
```

### Scenario 3: Assertion Failure

```c
// In kernel code
KERNEL_ASSERT(critical_pointer != NULL);
```

**Display:**
```
Stop Code: ASSERTION_FAILED
Reason: Assertion failed: critical_pointer != NULL
```

## Debugging with Panic

### Getting Error Details

1. **VGA Screen**:
   - Screenshot for documentation
   - Note exact stop code and reason
   - Screenshot leaf position

2. **Serial Console**:
   - Full panic details logged
   - Can redirect to file: `cat /dev/ttyS0 > panic.log`
   - Timestamps from kernel

3. **Core Dump** (if triggered):
   - Memory snapshot for analysis
   - Useful for post-mortem debugging

## Best Practices

### When to Use Panic

- Kernel data structure corruption detected
- Critical driver initialization failed
- Unrecoverable memory error
- Security violation detected
- Impossible state reached

### When NOT to Use Panic

- User application errors (use signals/exceptions)
- Temporary I/O failures (retry logic)
- Low memory (try cleanup first)
- Device not present (graceful degradation)

### Good Error Messages

```c
// ✓ Good - specific and actionable
kernel_panic("DRIVER_ERROR_INIT_FAILED", "ATA controller not responding to initialization");

// ✗ Bad - vague and unhelpful
kernel_panic("ERROR", "Something bad happened");
```

## Technical Limitations

⚠️ **Current Framework**:
- No active countdown timer (framework only)
- VGA-only display (no UEFI/text mode fallback)
- Single panic display (no log history)
- Manual restart required (no automatic reset)

## Future Enhancements

- [ ] Automatic countdown timer
- [ ] Keyboard-triggered soft reboot
- [ ] WDT (Watchdog Timer) integration
- [ ] Panic log persistence
- [ ] Core dump to disk
- [ ] Multi-core panic synchronization

---

**Related Documentation**:
- [Memory Inspector](MEMORY_INSPECTOR.md)
- [System Architecture](SYSTEM_ARCHITECTURE.md)
- [VMM & Paging](VMM_PAGING.md)
