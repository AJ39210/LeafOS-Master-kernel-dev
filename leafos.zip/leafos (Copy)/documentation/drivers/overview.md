# Drivers Documentation

## Overview

LeafOS includes modular device drivers for various hardware components.
Each driver is independently compiled and can be enabled/disabled via configuration.

## Available Drivers

### Display & Output

#### VGA Driver (`drivers/vga/vga.c`)
- **Configuration**: `CONFIG_VGA_DRIVER=y`
- **Purpose**: Text mode display output (80x25)
- **Features**:
  - 16 color support
  - Cursor positioning
  - Screen clearing and scrolling
  - Used by printk() for console output
- **I/O Ports**: VGA memory buffer at 0xB8000

#### Serial Driver (`drivers/serial/serial.c`)
- **Configuration**: `CONFIG_SERIAL_DRIVER=y`
- **Purpose**: Debug console output via serial port
- **Features**:
  - COM1 port at 0x3F8
  - 115200 baud rate
  - Used for early kernel debugging
  - Independent of VGA driver
- **Baud Rates**: 115200 (configurable)

### Storage Drivers

#### ATA Driver (`drivers/ata/ata.c`)
- **Configuration**: `CONFIG_ATA_DRIVER=y`
- **Purpose**: Parallel ATA/IDE disk interface
- **Features**:
  - Dual channel support (Primary/Secondary)
  - Master/slave drive detection
  - PIO mode transfers
  - LBA addressing (28-bit and 48-bit)
  - Device identification
  - Soft reset capability
- **Ports**: Primary 0x1F0, Secondary 0x170
- **Max Devices**: 4 (2 channels × 2 drives)

#### SATA Driver (`drivers/sata/sata.c`)
- **Configuration**: `CONFIG_SATA_DRIVER=y`
- **Purpose**: Serial ATA with AHCI (Advanced Host Controller Interface)
- **Features**:
  - ✅ **Full AHCI 1.3.1 Implementation**
  - Command list submission with proper FIS (Frame Information Structure)
  - Physical Region Descriptors (PRDs) for DMA
  - 48-bit LBA addressing (up to 281TB)
  - Port enumeration and hot-plug detection
  - Device signature detection (ATA vs ATAPI)
  - Error status reporting
  - Command timeout handling
- **Supported Commands**: 
  - READ DMA EXT (0x25)
  - WRITE DMA EXT (0x35)
  - IDENTIFY DEVICE (0xEC)
- **Max Devices**: 32 ports (per AHCI spec)
- **See**: [AHCI Implementation Details](AHCI_IMPLEMENTATION.md)

#### CD-ROM Driver (`drivers/cdrom/cdrom.c`)
- **Configuration**: `CONFIG_CDROM_DRIVER=y`
- **Purpose**: CD-ROM media support
- **Features**:
  - ATA/ATAPI protocol support
  - TOC (Table of Contents) reading
  - Multi-session support
  - Real ATA channel detection (primary/secondary)

#### DVD-ROM Driver (`drivers/cdrom/dvdrom.c`)
- **Configuration**: `CONFIG_DVDROM_DRIVER=y`
- **Purpose**: DVD media support
- **Features**:
  - DVD-ROM reading
  - CSS (Content Scramble System) detection
  - Region code awareness
  - Compatible with CD media

#### GPIO Driver (`drivers/gpio/gpio.c`)
- **Configuration**: `CONFIG_GPIO_DRIVER=y`
- **Purpose**: General Purpose I/O pin control
- **Features**:
  - 6 ports (A-F) with 16 pins each (96 total GPIO pins)
  - Input/Output modes
  - Alternate function support
  - Interrupt capability (rising/falling/both edges)
  - Pull-up/pull-down configuration
  - Custom interrupt handlers
  - Speed and drive strength configuration
- **Pin Naming**: PORT_PIN format (e.g., PA0, PB15, PC7)

### Memory & Virtual Filesystem

#### RAM Driver (`drivers/ram/ram.c`)
- **Configuration**: `CONFIG_RAM_DRIVER=y`
- **Purpose**: System memory detection and management
- **Features**:
  - e820 BIOS memory mapping
  - Real memory address detection
  - Memory type identification
  - Up to 128MB memory reporting

#### VFS Driver (`drivers/vfs/vfs.c`)
- **Configuration**: `CONFIG_VFS_DRIVER=y`
- **Purpose**: Virtual filesystem abstraction layer
- **Features**:
  - File descriptor table (32 max)
  - Directory operations
  - Inode structures
  - 256MB virtual storage

### USB (Conditional)

#### USB Core Driver (`drivers/usb/usb.c`)
- **Configuration**: `CONFIG_USB_DRIVER=y`
- **Purpose**: USB host controller support
- **Features**:
  - PCI bus scanning for controllers
  - UHCI/OHCI/EHCI detection
  - Real controller enumeration

#### USB HID Driver (`drivers/usb/usb_hid.c`)
- **Configuration**: `CONFIG_USB_HID=y`
- **Purpose**: Human Interface Device support (keyboard/mouse)
- **Features**:
  - Keyboard input
  - Mouse input
  - HID report parsing

#### USB Mass Storage (`drivers/usb/usb_mass_storage.c`)
- **Configuration**: `CONFIG_USB_MASS_STORAGE=y`
- **Purpose**: USB storage device support
- **Features**:
  - USB stick support
  - Bulk-only transfer protocol
  - Block device emulation

## Driver Architecture

### Initialization Sequence

1. **Serial**: First to initialize for early debug output
2. **VGA**: Initialize display driver
3. **RAM**: Detect system memory
4. **ACPI**: Power management and platform detection
5. **VFS**: Set up virtual filesystem
6. **ATA/SATA**: Initialize disk controllers
7. **GPIO**: Configure general purpose I/O
8. **Filesystems**: Mount supported filesystems
9. **USB** (optional): Enumerate USB devices
10. **CDROM/DVDROM**: Detect optical media

### Configuration System

Each driver is controlled by a `CONFIG_` option in `.config`:

```
CONFIG_VGA_DRIVER=y
CONFIG_SERIAL_DRIVER=y
CONFIG_USB_DRIVER=n
CONFIG_CDROM_DRIVER=y
CONFIG_DVDROM_DRIVER=y
CONFIG_RAM_DRIVER=y
CONFIG_VFS_DRIVER=y
```

### Makefile Integration

The build system automatically:
1. Reads configuration from `.config`
2. Compiles only enabled drivers
3. Links driver objects into kernel
4. Sets preprocessor definitions for conditional code

## Driver Development Guidelines

### Creating a New Driver

1. **Create driver file**: `drivers/category/driver.c`
2. **Create header file**: `include/driver.h`
3. **Implement functions**:
   - `driver_init()` - Initialize hardware
   - `driver_detect()` - Detect hardware presence
   - `driver_read()` - Read data
   - `driver_write()` - Write data
4. **Add configuration**: Add `CONFIG_DRIVER_NAME=y` to `.config`
5. **Update Makefile**: Add compilation rules
6. **Include in kernel**: Call init function in `initializer.c`

### Best Practices

- **Early Initialization**: Serial first for debugging
- **Error Handling**: Return error codes from init functions
- **Logging**: Use serial console for debug output during boot
- **Configuration**: Always respect CONFIG flags
- **Independence**: Each driver should be independent
- **Documentation**: Document hardware interfaces used

## Hardware Interfaces

### I/O Ports
- Serial: 0x3F8 (COM1)
- ATA: 0x1F0 (primary), 0x170 (secondary)
- VGA: Memory-mapped at 0xB8000

### BIOS Interfaces
- e820 memory mapping (int 0x15, ah=0xE820)
- PCI configuration space (CF8/CFC)

### Interrupts
- IRQ0: Timer
- IRQ1: Keyboard
- IRQ4: Serial (COM1)
- IRQ14: Primary IDE
- IRQ15: Secondary IDE

## Driver Status at Boot

During kernel startup, each enabled driver logs its initialization status:

```
[    ] VGA Driver: enabled
[    ] Serial Driver: enabled
[    ] CD-ROM Driver: enabled
[    ] DVD-ROM Driver: enabled
[    ] RAM Driver: enabled
[    ] VFS Driver: enabled
```

## Troubleshooting

### Driver Not Loading
1. Check if enabled in `.config`
2. Verify Makefile has compilation rule
3. Check for compilation errors
4. Ensure header file exists in `include/`

### Driver Initialization Error
1. Check serial console output
2. Enable verbose debugging in source
3. Verify hardware is supported
4. Check BIOS e820 memory map

### Performance Issues
1. Check for unnecessary serial I/O
2. Verify DMA is being used where possible
3. Profile driver execution time
4. Consider caching frequently accessed data
