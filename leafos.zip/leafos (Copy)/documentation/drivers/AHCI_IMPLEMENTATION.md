# LeafOS AHCI (Advanced Host Controller Interface) Implementation

**Status**: ✅ Production Ready  
**Version**: 2.0 (Full AHCI Command Submission)  
**Last Updated**: February 2, 2026

## Overview

The LeafOS SATA driver now features a **complete AHCI (Advanced Host Controller Interface)** implementation with proper command submission, DMA transfers, and error handling.

## AHCI Architecture

### Memory Layout

AHCI uses memory-mapped I/O for controller communication:

```
AHCI Base Address (from PCI BAR5)
├── 0x00: CAP (Capabilities Register)
├── 0x04: GHC (Global Host Control)
├── 0x08: IS (Interrupt Status)
├── 0x0C: PI (Ports Implemented)
├── 0x10: VS (Version)
│
└── Port Registers (0x100 + port×0x80)
    ├── 0x00: CLB (Command List Base)
    ├── 0x08: FB (Received FIS Base)
    ├── 0x10: IS (Port Interrupt Status)
    ├── 0x14: IE (Port Interrupt Enable)
    ├── 0x18: CMD (Port Command)
    ├── 0x20: TFD (Task File Data)
    ├── 0x24: SIG (Signature)
    ├── 0x28: SSTS (Serial ATA Status)
    ├── 0x2C: SCTL (Serial ATA Control)
    ├── 0x30: SERR (Serial ATA Error)
    ├── 0x34: SACT (Serial ATA Active)
    ├── 0x38: CI (Command Issue)
    └── 0x3C: SNTF (Serial ATA Notification)
```

### Command Submission Flow

```
User Application
        ↓
    sata_read_sectors() / sata_write_sectors()
        ↓
    Build Command FIS (Host-to-Device)
        ↓
    Setup Command Table with PRDs (Physical Region Descriptors)
        ↓
    Update Command Header
        ↓
    Write to CI (Command Issue) register
        ↓
    Hardware processes command (DMA transfer)
        ↓
    Hardware clears CI bit on completion
        ↓
    Check completion & error status
        ↓
    Return to user
```

## Data Structures

### Command Header (32 bytes per slot)

```c
struct ahci_cmd_header {
    uint16_t opts;              /* Command FIS length, ATAPI flag, write bit */
    uint16_t prdtl;             /* PRD Table Length (# of PRD entries) */
    uint32_t prdbc;             /* Physical Region Descriptor Byte Count */
    uint32_t ctba;              /* Command Table Base Address (lower 32-bit) */
    uint32_t ctbau;             /* Command Table Base Address (upper 32-bit) */
    uint32_t reserved[4];       /* Reserved, must be 0 */
};
```

**`opts` field breakdown:**
- Bits [4:0] - Command FIS length in DWORDs (5 for 20 bytes)
- Bit 5 - ATAPI command (0=ATA, 1=ATAPI)
- Bit 6 - Write (0=read, 1=write to device)
- Bits [15:7] - Reserved

### Command FIS (Frame Information Structure)

```c
struct ahci_h2d_fis {
    uint8_t  fis_type;          /* 0x27 for Host-to-Device */
    uint8_t  pm_port;           /* Port multiplier port (bit 7=C flag) */
    uint8_t  command;           /* ATA command (0x25=READ DMA EXT, 0x35=WRITE DMA EXT) */
    uint8_t  features;          /* ATA features register */
    uint32_t lba_low;           /* LBA bits [0:31] */
    uint32_t lba_high;          /* LBA bits [32:47] */
    uint32_t reserved;
    uint16_t count;             /* Sector count */
    uint8_t  icc;               /* Isochronous Command Completion */
    uint8_t  control;           /* Control register */
    uint32_t reserved2;
};
```

### Physical Region Descriptor (PRD)

```c
struct ahci_prd {
    uint32_t dba;               /* Data Base Address (lower 32-bit) */
    uint32_t dbau;              /* Data Base Address (upper 32-bit) */
    uint32_t reserved;
    uint32_t dbc;               /* Data Byte Count (0-based, 0=1 byte, 0xFFFF=65536 bytes) */
                                /* Bit 31: I bit = 1 marks this as last PRD */
};
```

### Command Table

```c
struct ahci_cmd_table {
    ahci_h2d_fis_t cfis;        /* Command FIS (64 bytes) */
    uint8_t atapi_cmd[16];      /* ATAPI command (if ATAPI device) */
    uint8_t reserved[48];
    ahci_prd_t prd_table[248];  /* PRD entries (up to 248 entries) */
};
```

Total size: 4096 bytes (exactly one page)

### Received FIS

```c
struct ahci_received_fis {
    uint8_t dma_setup_fis[28];
    uint8_t reserved1[4];
    uint8_t pio_setup_fis[20];
    uint8_t reserved2[12];
    uint8_t d2h_register_fis[20];   /* Device-to-Host Register FIS (status) */
    uint8_t reserved3[4];
    uint8_t set_device_bits_fis[8];
    uint8_t unknown_fis[64];
    uint8_t reserved4[96];
};
```

Total size: 256 bytes

## Implementation Details

### Port Setup

When a port is detected with a device:

1. **Allocate Memory**:
   - Command List: 1024 bytes (32 command headers × 32 bytes)
   - Command Table(s): Per command slot (4096 bytes each)
   - Received FIS: 256 bytes

2. **Configure Registers**:
   ```c
   CLB  = Command List Base Address
   CLBU = Command List Base Address (upper 32-bit for 64-bit addressing)
   FB   = Received FIS Base Address
   FBU  = Received FIS Base Address (upper 32-bit)
   ```

3. **Enable Port**:
   ```c
   // Start command engine (set ST bit)
   PORT.CMD |= 0x00000001;
   ```

### Reading Sectors

```c
sata_read_sectors(port, lba, count, buffer)
```

**Flow**:
1. Build READ DMA EXT command FIS with LBA and sector count
2. Setup PRD entry pointing to buffer with byte count
3. Set command header options (FIS length=5, write=0)
4. Write to CI register to issue command
5. Poll CI register until bit clears (command complete)
6. Check error status in port IS register
7. Return success/failure

**LBA-48 Addressing**:
- Supports 48-bit LBA (up to 281TB drives)
- LBA split: lower 32-bit in LBA_LOW, upper 16-bit in LBA_HIGH

### Writing Sectors

```c
sata_write_sectors(port, lba, count, buffer)
```

**Flow**: Same as read, but:
- Uses WRITE DMA EXT (0x35) instead of READ (0x25)
- Sets write flag in command header (bit 6)
- Data flows: Buffer → Controller → Device

## ATA Commands

### Supported Commands

| Command | Code | Purpose |
|---------|------|---------|
| READ DMA EXT | 0x25 | Read sectors (48-bit LBA) |
| WRITE DMA EXT | 0x35 | Write sectors (48-bit LBA) |
| IDENTIFY DEVICE | 0xEC | Get device information |

### Command FIS Format

```
Byte 0: FIS Type (0x27 = Host-to-Device)
Byte 1: Port Multiplier Port & C bit
Byte 2: Command Code
Byte 3: Features
Bytes 4-7: LBA (bits 0-31)
Bytes 8-11: LBA (bits 32-47) + reserved
Bytes 12-13: Sector Count
Byte 14: ICC
Byte 15: Control Register
```

## Error Handling

### Port Interrupt Status (IS Register)

When a command completes or error occurs, check IS register:

| Bit | Flag | Meaning |
|-----|------|---------|
| 0 | DHRS | Device-to-Host Register FIS received |
| 1 | PSS | PIO Setup FIS received |
| 2 | DSS | DMA Setup FIS received |
| 3 | SDBS | Set Device Bits FIS received |
| 4 | UFS | Unknown FIS received |
| 5 | DPS | Descriptor Processed |
| 6 | PCS | Port Connect Change |
| 7 | DMPS | Device Mechanical Presence State Change |
| 30 | PRCS | PhyRdy Change Status |
| 31 | TFES | Task File Error Status |

**Critical Flags**:
- TFES (31) = Error occurred
- DHRS (0) = Command completed successfully

### Completion Detection

```c
// Poll CI register until command completes
do {
    ci_value = *(CI register);
} while (ci_value & (1 << slot_number));

// Check for errors
if (port->IS & 0x80000000) {  // TFES flag
    // Error occurred - check TFD register for status
}
```

## Memory Allocation

### Current Implementation

The driver uses fixed memory locations for command structures:

```c
Base: 0x10000 + (port × 0x2000)

Port Memory Layout:
├── 0x0000: Command List (1024 bytes)
├── 0x0400: [unused]
├── 0x1000: Command Table Slot 0 (4096 bytes)
└── 0x1400: Received FIS (256 bytes)
```

Max supported: 32 ports × 0x2000 bytes = 128KB

### DMA Buffers

User-supplied I/O buffers are directly used for DMA:

```c
// Buffer at user address, marked with physical address in PRD
cmd_table->prd_table[0].dba = (uint32_t)buffer;
cmd_table->prd_table[0].dbc = (count * 512) - 1;
cmd_table->prd_table[0].reserved = 0x80000000;  // I bit (last PRD)
```

## Performance Characteristics

### Read/Write Latency

- **Command submission**: ~100 CPU cycles (building FIS + PRD setup)
- **Hardware processing**: ~1-100ms (depends on device speed)
- **Completion polling**: ~1000 CPU cycles timeout check

### Throughput

- **Single command**: Up to device speed (typically 100+ MB/s for SATA 2)
- **Queued commands**: Can overlap with proper implementation
- **Current limitation**: No command queuing (processes one at a time)

## Configuration

Enable SATA driver in `.config`:

```bash
CONFIG_SATA_DRIVER=y
```

When enabled:
- SATA controller detected via AHCI base address
- All implemented ports enumerated
- Devices detected by signature
- Read/write operations fully functional

## Testing

### Verification

The driver logs all operations to serial:

```
[SATA] Initializing SATA driver
[SATA] Probing ports...
[SATA] Resetting port 0
[SATA] Port 0 enabled
[SATA] Detecting device on port 0
[SATA] SATA ATA drive detected
[SATA] Port 0 buffers initialized
[SATA] Found 1 device(s)
[SATA] SATA driver initialized
```

### Read/Write Operations

```
[SATA] Read 16 sectors from port 0
[SATA] Write 8 sectors to port 0
```

## Advanced Features (Future)

### Not Yet Implemented

- **Native Command Queuing (NCQ)** - Multiple concurrent commands
- **Port Multiplier** - Single port with multiple devices
- **Hotplug Support** - Device connect/disconnect detection
- **ATAPI Support** - CD-ROM/DVD-ROM command building
- **Power Management** - Link speed negotiation
- **MSI Interrupts** - Message Signaled Interrupts

### Interrupt-Driven Completion

Current implementation polls CI register. Future enhancement:

```c
// Enable port interrupts
PORT.IE = 0xFDC00000;  // Enable most interrupt types

// Handler
void sata_irq_handler() {
    uint32_t is = PORT.IS;
    if (is & 0x80000000) {  // TFES - error
        handle_error();
    } else if (is & 0x00000001) {  // DHRS - success
        mark_command_complete();
    }
}
```

## Code Structure

### sata.h

- AHCI register definitions
- FIS structure definitions
- PRD structure definitions
- API function declarations

### sata.c

- `sata_init()` - Initialize controller
- `sata_probe_ports()` - Enumerate ports
- `sata_setup_port()` - Allocate buffers, configure registers
- `sata_port_reset()` - Reset port link
- `sata_port_enable()` - Start command engine
- `sata_detect_device()` - Read device signature
- `sata_build_read_command()` - Build READ FIS
- `sata_build_write_command()` - Build WRITE FIS
- `sata_submit_command()` - Issue command, wait for completion
- `sata_read_sectors()` - Public read API
- `sata_write_sectors()` - Public write API

## Integration with LeafOS

### Kernel Initialization

The SATA driver is initialized during kernel boot:

```c
// In kernel/initializer.c
if (CONFIG_SATA_DRIVER) {
    if (!sata_init()) {
        printk("[BOOT] SATA initialization failed\n");
    }
}
```

### Filesystem Integration

SATA devices can be used as storage for filesystems:

```c
// In drivers/vfs/vfs.c
vfs_add_device("sata0", sata_read_sectors, sata_write_sectors, device_info);
```

### Error Recovery

If a command times out:

```c
// Soft reset port
sata_port_reset(port);
sata_port_enable(port);
// Retry operation
```

## Compatibility

### Tested Hardware

- ✅ QEMU AHCI emulation
- ✅ VirtualBox SATA controller
- ✅ Real SATA drives (Seagate, WD, Samsung)

### AHCI Specification

Implements AHCI 1.3.1 core features:
- Command submission (CI register)
- Completion status (IS register)
- Error reporting (TFES flag)
- Device detection (SIG register)
- Port control (SCTL register)

## References

- AHCI Specification 1.3.1 (Intel)
- Serial ATA Revision 3.0 Specification
- SATA Advanced Host Controller Interface (AHCI) 1.3 Specification

## License

Part of LeafOS Kernel - See copying file for details
