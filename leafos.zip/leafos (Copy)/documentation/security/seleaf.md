# SELeaf Security Module Documentation

## Overview

SELeaf is a Mandatory Access Control (MAC) security module for LeafOS, similar to SELinux but specifically designed for our kernel's architecture.

## Features

### Security Modes

1. **DISABLED** - No security checks (legacy boot mode)
2. **PERMISSIVE** - Log policy violations but allow access (debug mode)
3. **ENFORCING** - Strictly enforce security policies (production mode)

### Components

#### Security Contexts
Each subject (process, kernel, etc.) has a security context consisting of:
- **User**: Context user identifier
- **Role**: Functional role assignment
- **Type**: Object/subject classification
- **Level**: Security level

#### Object Classes
SELeaf recognizes these object types:
- `file` - Regular files
- `dir` - Directories
- `process` - Running processes
- `socket` - Network sockets
- `device` - Hardware devices
- `driver` - Kernel drivers
- `memory` - Memory regions
- `kernel` - Kernel itself

#### Permissions
Fine-grained permissions for each object class:
- `read` - Read access (0x01)
- `write` - Write access (0x02)
- `execute` - Execute permission (0x04)
- `create` - Create new objects (0x08)
- `delete` - Delete objects (0x10)
- `mount` - Mount/unmount (0x20)
- `ioctl` - Device I/O control (0x40)

### Policy Rules

Policy rules define allowed operations:

```c
source_type → target_type : object_class { permissions }
```

Example policies:
```
kernel → any : file { read write execute create delete mount }
driver → device : device { read write ioctl }
process → file : file { read execute }
```

## Implementation

### Core Functions

#### Initialization
```c
int seleaf_init(seleaf_mode_t mode);
```
Initialize SELeaf in the specified mode and load default policies.

#### Mode Management
```c
int seleaf_set_mode(seleaf_mode_t mode);
seleaf_mode_t seleaf_get_mode(void);
```
Change or query the current security mode.

#### Permission Checking
```c
int seleaf_check_permission(seleaf_context_t *subject,
                            seleaf_context_t *object,
                            seleaf_class_t object_class,
                            uint32_t permission);
```
Check if a subject has permission to perform an action.

#### Audit Logging
```c
int seleaf_log_audit(seleaf_audit_entry_t *entry);
```
Log a security-relevant event for audit trail.

## Directory Structure

```
kernel/SELeaf/
├── seleaf.h      - Header with data structures and declarations
├── seleaf.c      - Implementation of security module
└── README.md     - This file
```

## Default Policies

SELeaf loads these default policies on initialization:

1. **Kernel Access**: Kernel type has full access to all objects
2. **Driver Access**: Drivers can access assigned devices
3. **Process Access**: Processes follow principle of least privilege

## Usage in Kernel

### Check Filesystem Access
```c
seleaf_context_t kernel_context = { .type = 1 };
seleaf_context_t file_object = { .type = SELEAF_CLASS_FILE };

if (seleaf_check_permission(&kernel_context, &file_object,
                            SELEAF_CLASS_FILE, SELEAF_PERM_READ)) {
    // Access granted
}
```

### Log Audit Event
```c
seleaf_audit_entry_t audit = {
    .subject = subject_context,
    .object = object_context,
    .object_class = SELEAF_CLASS_FILE,
    .requested_permission = SELEAF_PERM_READ,
    .denied = 0,
    .in_enforcing_mode = (seleaf_get_mode() == SELEAF_MODE_ENFORCING)
};

seleaf_log_audit(&audit);
```

## Security Features

### Capability-Based Access Control
Instead of traditional Unix permissions, SELeaf uses capability lists
where each security context explicitly states what it can do.

### Fine-Grained Control
Each permission bit controls a specific operation, allowing precise policy:
- `0x01` = read
- `0x02` = write
- `0x04` = execute
- etc.

### Audit Trail
All permission checks (especially denials) can be logged for:
- Security investigation
- Compliance verification
- Attack detection
- Forensic analysis

### Kernel Protection
The kernel runs with maximum privileges and can't be restricted,
preventing privilege escalation through kernel access.

## Integration Points

### Filesystem Access
Before mounting or reading a filesystem, check:
```c
seleaf_check_permission(current_context, fs_context,
                        SELEAF_CLASS_DRIVER, SELEAF_PERM_MOUNT);
```

### Device Access
Before accessing a device driver:
```c
seleaf_check_permission(process_context, device_context,
                        SELEAF_CLASS_DEVICE, SELEAF_PERM_IOCTL);
```

### Memory Access
Before allocating or accessing memory:
```c
seleaf_check_permission(requestor_context, memory_context,
                        SELEAF_CLASS_MEMORY, SELEAF_PERM_READ);
```

## Future Enhancements

1. **Dynamic Policy Loading**: Load policies from configuration files
2. **Policy Audit**: Verify policies for conflicts or redundancies
3. **Transition Rules**: Allow controlled privilege elevation
4. **Role-Based Access Control (RBAC)**: Enhance with role hierarchy
5. **Type Enforcement**: Stricter type checking at compile time
6. **Denial Caching**: Cache permission decisions for performance

## Relationship to Other Kernel Components

- **main.c**: Can initialize SELeaf during boot
- **initializer.c**: Calls SELeaf to secure driver initialization
- **bootmsg.c**: Reports SELeaf mode in boot messages
- **drivers**: Check permissions before accessing devices
- **filesystems**: Check permissions before mount/read operations
