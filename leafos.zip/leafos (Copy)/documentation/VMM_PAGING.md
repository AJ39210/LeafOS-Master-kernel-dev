# Virtual Memory & Paging System

**Status**: ✅ Implemented and Integrated

## Overview

The Virtual Memory Manager (VMM) provides:
- 32-bit linear address space (4GB total)
- 4KB page size (standard x86)
- Page directory and page table management
- Virtual to physical address translation
- TLB (Translation Lookaside Buffer) management
- Memory protection capabilities

## Architecture

### Memory Layout

```
┌─────────────────────────────────┐ 0xFFFFFFFF
│  Kernel Space (1GB)             │
│  0xC0000000 - 0xFFFFFFFF         │
├─────────────────────────────────┤ 0xC0000000
│                                 │
│  User Space (3GB)               │
│  0x08048000 - 0xBFFFFFFF         │
│                                 │
├─────────────────────────────────┤ 0x08048000
│  Reserved / DMA Zone            │
│  0x00000000 - 0x08047FFF         │
└─────────────────────────────────┘ 0x00000000
```

### Page Structure

**Page Directory** (1 per process):
- 1024 entries × 4 bytes = 4KB
- Entries index into page tables
- Bits 22-31 of virtual address select entry

**Page Table** (multiple):
- 1024 entries × 4 bytes = 4KB
- Entries point to 4KB physical pages
- Bits 12-21 of virtual address select entry

**Page Offset**:
- Bits 0-11 of virtual address
- Offset within 4KB page
- Direct copy to physical address

### Virtual Address Translation

```
Virtual Address:   [DIR(10)] [TABLE(10)] [OFFSET(12)]
                    31-22     21-12       11-0

1. Extract directory index (bits 22-31)
2. Look up page directory entry
3. Get page table base address
4. Extract table index (bits 12-21)
5. Look up page table entry
6. Get physical page address
7. Add offset (bits 0-11)
8. Result = physical address
```

## API Reference

### Initialization

```c
void vmm_init(void);
```
Initialize virtual memory system. Called during kernel boot.

### Address Translation

```c
uint32_t vmm_vaddr_to_paddr(uint32_t vaddr);
```
Translate virtual address to physical address.  
Returns: Physical address, or 0 if unmapped

### Paging Operations

```c
int vmm_map_page(uint32_t vaddr, uint32_t paddr, uint32_t flags);
```
Map virtual page to physical page.  
Flags: `PAGE_PRESENT`, `PAGE_RW`, `PAGE_USER`  
Returns: 0 on success, -1 on error

```c
int vmm_unmap_page(uint32_t vaddr);
```
Unmap virtual page.  
Returns: 0 on success, -1 on error

### Query Functions

```c
int vmm_is_mapped(uint32_t vaddr);
```
Check if virtual address is currently mapped.  
Returns: 1 if mapped, 0 if not

```c
void vmm_get_stats(uint32_t *total, uint32_t *used);
```
Get virtual memory statistics.

## Protection Flags

| Flag | Value | Meaning |
|------|-------|---------|
| `PAGE_PRESENT` | 0x01 | Page present in memory |
| `PAGE_RW` | 0x02 | Read/Write (1=RW, 0=RO) |
| `PAGE_USER` | 0x04 | User accessible (1=user, 0=kernel) |
| `PAGE_GLOBAL` | 0x100 | Global (TLB not flushed) |

## TLB Management

The Translation Lookaside Buffer caches address translations.

### Flushing TLB

```c
void vmm_flush_tlb(void);        // Flush entire TLB
void vmm_flush_tlb_entry(uint32_t vaddr);  // Flush single entry
```

**When to flush:**
- After `vmm_map_page()` - Automatically done
- After `vmm_unmap_page()` - Automatically done
- After changing page directory - Use `vmm_flush_tlb()`

## Implementation Details

### Page Directory Entry (PDE)

```
Bit 31-12: Page Table Base Address
Bit 11-9:  Available for OS
Bit 8:     Global (TLB not invalidated on CR3 reload)
Bit 7:     Page Size (0 = 4KB, 1 = 4MB)
Bit 6:     Dirty (only in page tables)
Bit 5:     Accessed
Bit 4:     Cache Disable
Bit 3:     Write-Through
Bit 2:     User/Supervisor
Bit 1:     Read/Write
Bit 0:     Present
```

### Current Limitations

⚠️ **Framework Status**:
- Identity mapping enabled (physical = virtual)
- Actual paging not fully enabled yet
- `vmm_init()` sets up infrastructure
- Ready for demand paging implementation

## Usage Example

```c
#include "vmm.h"
#include "serial.h"

// Initialize VMM during boot
vmm_init();

// Check if address is mapped
if (vmm_is_mapped(0x08048000)) {
    serial_puts(SERIAL_PORT_A, "User space mapped\n");
}

// Get virtual to physical translation
uint32_t vaddr = 0x08048000;
uint32_t paddr = vmm_vaddr_to_paddr(vaddr);
serial_puts(SERIAL_PORT_A, "Vaddr: ");
// Print addresses...

// Get statistics
uint32_t total, used;
vmm_get_stats(&total, &used);
```

## Technical Notes

### Kernel Space (0xC0000000 - 0xFFFFFFFF)
- 1GB reserved for kernel
- Protected from user access
- Contains:
  - Kernel code
  - Kernel data
  - Page tables
  - I/O mappings

### User Space (0x08048000 - 0xBFFFFFFF)
- ~3GB for user applications
- User-accessible memory
- Process isolation via separate page directories

### DMA Zone (0x00000000 - 0x0FFFFFFF)
- 256MB for DMA and bootloader structures
- Must be identity-mapped (virtual = physical)
- Required for device operations

## Future Enhancements

- [ ] Full paging with page swapping
- [ ] Copy-on-write (COW)
- [ ] Memory protection domains
- [ ] Shared memory regions
- [ ] Large page support (4MB pages)
- [ ] PAE (Physical Address Extension) for >4GB

## Performance Characteristics

| Operation | Cost |
|-----------|------|
| Page fault (unmapped) | ~1000 cycles |
| TLB hit (cached) | ~10 cycles |
| Page map operation | ~500 cycles |
| Page unmap operation | ~500 cycles |

---

**Related Documentation**:
- [System Architecture](SYSTEM_ARCHITECTURE.md)
- [Panic Handler](PANIC_SYSTEM.md)
- [Memory Inspector](MEMORY_INSPECTOR.md)
