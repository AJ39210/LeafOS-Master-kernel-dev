/**
 * drivers/acpi/README.md
 * 
 * LeafOS ACPI Driver System
 * 
 * ## Overview
 * 
 * The LeafOS ACPI (Advanced Configuration and Power Interface) driver provides
 * power management, thermal management, and device configuration support across
 * multiple hardware platforms including QEMU, VirtualBox, and real hardware
 * (HP 250 G3 with extensive workarounds).
 * 
 * ## Architecture
 * 
 * The ACPI driver uses a modular, platform-specific architecture:
 * 
 * ```
 * acpi.c (Core ACPI)
 *   ├── RSDP Detection
 *   ├── Table Parsing
 *   ├── Event Handling
 *   └── State Management
 *       │
 *       └── platform_dispatch.c
 *           ├── qemu/qemu_acpi.c (Well-behaved ACPI)
 *           ├── vmbox/vmbox_acpi.c (Mostly standard, some quirks)
 *           └── hp/hp_acpi.c (Buggy BIOS, extensive workarounds)
 * ```
 * 
 * ## Directory Structure
 * 
 * ```
 * drivers/acpi/
 * ├── acpi.h                    # Core header with structures and APIs
 * ├── acpi.c                    # Main ACPI implementation
 * ├── platform_dispatch.c       # Route calls to platform implementations
 * ├── qemu/
 * │   └── qemu_acpi.c          # QEMU-specific implementation
 * ├── vmbox/
 * │   └── vmbox_acpi.c         # VirtualBox-specific implementation
 * └── hp/
 *     └── hp_acpi.c            # HP 250 G3 with BIOS workarounds
 * ```
 * 
 * ## Supported Platforms
 * 
 * ### QEMU (CONFIG_ACPI_QEMU)
 * - **Reliability**: Excellent
 * - **ACPI Implementation**: Standard and well-tested
 * - **Workarounds**: None needed
 * - **Features**: 
 *   - Standard power states (S0, S1, S3, S5)
 *   - Thermal monitoring
 *   - Battery status reporting
 *   - Device event handling
 * 
 * ### VirtualBox (CONFIG_ACPI_VIRTUALBOX)
 * - **Reliability**: Good
 * - **ACPI Implementation**: Mostly standard with known quirks
 * - **Workarounds**: 6 compatibility quirks enabled
 *   - Disable unreliable thermal zone monitoring
 *   - Add delays to power state transitions
 *   - Disable battery status polling
 *   - Retry logic for EC communication
 *   - Handle thermal sensor faults gracefully
 * - **Features**:
 *   - Standard power states (with delay-based workarounds)
 *   - Thermal monitoring disabled (reports garbage)
 *   - Battery reporting disabled (completely broken)
 *   - Device event handling
 * 
 * ### HP 250 G3 (CONFIG_ACPI_HP)
 * - **Reliability**: Poor (extensive workarounds required)
 * - **ACPI Implementation**: Very buggy, not ACPI-compliant
 * - **Workarounds**: 6 major workarounds + extensive retry logic
 *   - Thermal zone reporting disabled (always incorrect)
 *   - Battery reporting disabled (completely broken)
 *   - Sleep states limited to S5 only (S3 doesn't work)
 *   - ACPI table checksum validation skipped (checksums invalid)
 *   - EC (Embedded Controller) communication uses retry loops
 *   - Extra delays added throughout for stability
 * - **Features**:
 *   - Shutdown (with multiple retry attempts)
 *   - Sleep to S5 (S3 redirected to S5)
 *   - Lid switch events (partially functional)
 *   - Device event handling
 * 
 * ## Configuration
 * 
 * Edit `.config` to enable/disable ACPI and select platform:
 * 
 * ```bash
 * # Enable ACPI driver
 * CONFIG_ACPI_DRIVER=y
 * 
 * # Choose ONE platform (set others to n):
 * CONFIG_ACPI_QEMU=y           # For QEMU virtual machines
 * CONFIG_ACPI_VIRTUALBOX=n     # For VirtualBox virtual machines
 * CONFIG_ACPI_HP=n             # For HP 250 G3 real hardware
 * ```
 * 
 * ## API Reference
 * 
 * ### Core Functions
 * 
 * ```c
 * // Initialize ACPI subsystem (called during boot)
 * int acpi_init(void);
 * 
 * // Detect hardware platform automatically
 * int acpi_detect_platform(void);
 * 
 * // Find RSDP (Root System Description Pointer)
 * int acpi_find_rsdp(void);
 * 
 * // Parse ACPI tables
 * int acpi_parse_tables(void);
 * 
 * // Enable/disable ACPI mode
 * int acpi_enable(void);
 * int acpi_disable(void);
 * 
 * // Power state management
 * int acpi_set_power_state(acpi_power_state_t state);
 * int acpi_get_power_state(void);
 * ```
 * 
 * ### Event Handling
 * 
 * ```c
 * // Register/unregister event handlers
 * int acpi_register_event_handler(acpi_event_type_t type);
 * int acpi_unregister_event_handler(acpi_event_type_t type);
 * 
 * // Handle ACPI events
 * void acpi_handle_event(acpi_event_type_t type);
 * ```
 * 
 * ### Platform-Specific Functions
 * 
 * ```c
 * // Called during initialization
 * int acpi_platform_init(acpi_platform_t platform);
 * 
 * // Apply workarounds
 * int acpi_platform_apply_quirks(void);
 * 
 * // Prepare for sleep/shutdown
 * void acpi_platform_sleep_prepare(acpi_power_state_t state);
 * 
 * // Perform shutdown
 * void acpi_platform_shutdown(void);
 * ```
 * 
 * ## Power States
 * 
 * - **S0**: Working (system on) - default state
 * - **S1**: Sleep with CPU powered - supported on most platforms
 * - **S3**: Sleep with memory powered - NOT supported on HP 250 G3
 * - **S4**: Hibernation (saves to disk) - not implemented
 * - **S5**: Shutdown (system off) - supported on all platforms
 * 
 * ## Event Types
 * 
 * - **ACPI_EVENT_POWER_BUTTON**: Power button pressed
 * - **ACPI_EVENT_SLEEP_BUTTON**: Sleep button pressed
 * - **ACPI_EVENT_THERMAL**: Thermal zone event
 * - **ACPI_EVENT_DEVICE_NOTIFY**: Generic device notification
 * - **ACPI_EVENT_BATTERY**: Battery status changed
 * - **ACPI_EVENT_LID**: Lid switch (laptop)
 * 
 * ## HP 250 G3 Known Issues
 * 
 * The HP 250 G3 Notebook PC has a notoriously buggy BIOS with serious ACPI issues:
 * 
 * 1. **Thermal Zone Broken**
 *    - Reads garbage temperatures
 *    - Cannot determine if system is overheating
 *    - Workaround: Disable all thermal monitoring
 * 
 * 2. **Battery Reporting Broken**
 *    - Battery status always incorrect
 *    - Cannot determine charging state
 *    - Workaround: Disable battery event handling
 * 
 * 3. **S3 Sleep Doesn't Work**
 *    - System won't enter S3 state correctly
 *    - Results in hang or unexpected wake
 *    - Workaround: Redirect S3 requests to S5 (shutdown)
 * 
 * 4. **Invalid ACPI Table Checksums**
 *    - BIOS provides tables with incorrect checksums
 *    - Standard validation would reject them
 *    - Workaround: Skip checksum validation for HP
 * 
 * 5. **EC Communication Flaky**
 *    - Embedded Controller often doesn't respond
 *    - Commands fail intermittently
 *    - Workaround: Retry loop with delays (up to 5 retries)
 * 
 * 6. **Timing Sensitive**
 *    - Operations fail without delays
 *    - Workaround: Add extra delays throughout
 * 
 * ## Boot Sequence
 * 
 * During kernel boot, ACPI initialization follows this sequence:
 * 
 * 1. **Platform Detection** - Auto-detect QEMU, VirtualBox, or HP hardware
 * 2. **RSDP Search** - Search EBDA and BIOS ROM for Root System Description Pointer
 * 3. **Platform Init** - Call platform-specific initialization
 * 4. **Apply Quirks** - Apply platform-specific workarounds
 * 5. **Parse Tables** - Extract information from ACPI tables
 * 6. **Enable ACPI** - Switch system to ACPI mode
 * 
 * Serial output during boot shows:
 * ```
 * [ACPI] Initializing ACPI subsystem
 * [ACPI] Platform: QEMU (or VirtualBox, or HP)
 * [ACPI] Searching for RSDP...
 * [ACPI] RSDP found at EBDA (or BIOS ROM)
 * [ACPI] Parsing tables...
 * [ACPI] Enabling ACPI mode
 * [ACPI] ACPI subsystem initialized successfully
 * ```
 * 
 * For platform-specific messages:
 * - `[ACPI-QEMU]` prefix for QEMU
 * - `[ACPI-VirtualBox]` prefix for VirtualBox
 * - `[ACPI-HP]` prefix for HP
 * 
 * ## Porting to New Platforms
 * 
 * To add support for a new platform:
 * 
 * 1. **Create Platform Directory**
 *    ```bash
 *    mkdir drivers/acpi/myplatform
 *    ```
 * 
 * 2. **Implement Platform Driver**
 *    Create `myplatform_acpi.c` with these functions:
 *    ```c
 *    int myplatform_acpi_init(void);
 *    int myplatform_acpi_apply_quirks(void);
 *    int myplatform_acpi_sleep(acpi_power_state_t state);
 *    void myplatform_acpi_shutdown(void);
 *    void myplatform_acpi_get_info(void);
 *    ```
 * 
 * 3. **Add Platform Type to Header**
 *    Add to `acpi_platform_t` enum in `acpi.h`
 * 
 * 4. **Update Platform Detection**
 *    Add BIOS signature detection in `acpi_detect_platform()`
 * 
 * 5. **Update Dispatcher**
 *    Add switch cases in `platform_dispatch.c`
 * 
 * 6. **Update Makefile**
 *    Add platform configuration option and source files
 * 
 * ## Compilation
 * 
 * ### With QEMU
 * ```bash
 * CONFIG_ACPI_DRIVER=y CONFIG_ACPI_QEMU=y make clean && make
 * ```
 * 
 * ### With VirtualBox
 * ```bash
 * CONFIG_ACPI_DRIVER=y CONFIG_ACPI_VIRTUALBOX=y make clean && make
 * ```
 * 
 * ### With HP 250 G3
 * ```bash
 * CONFIG_ACPI_DRIVER=y CONFIG_ACPI_HP=y make clean && make
 * ```
 * 
 * ### Disable ACPI
 * ```bash
 * CONFIG_ACPI_DRIVER=n make clean && make
 * ```
 * 
 * ## Testing
 * 
 * ### Test on QEMU
 * ```bash
 * make run  # Uses QEMU by default
 * ```
 * 
 * Watch serial output for ACPI initialization messages.
 * 
 * ### Test Power States
 * In kernel code, you can test power states:
 * ```c
 * acpi_set_power_state(ACPI_POWER_S1);  // Enter sleep
 * acpi_set_power_state(ACPI_POWER_S5);  // Shutdown
 * ```
 * 
 * ## Limitations
 * 
 * - **No ACPI AML Interpreter**: We don't execute AML bytecode
 * - **Basic Table Parsing**: Only reads critical tables (RSDP, FADT, MADT)
 * - **No Thermal Management**: Thermal zone monitoring available but minimal
 * - **No Dynamic Device Discovery**: Device list is static
 * - **No ACPI Methods**: Can't call arbitrary ACPI methods
 * 
 * ## Future Improvements
 * 
 * - Implement ACPI AML interpreter for complex BIOS interactions
 * - Add full thermal zone monitoring and fan control
 * - Support for more platforms (Dell, Lenovo, etc.)
 * - Dynamic device discovery and hotplug support
 * - ACPI hibernation (S4) implementation
 * - Better error recovery for buggy BIOS
 * 
 * ## References
 * 
 * - ACPI Specification: https://uefi.org/sites/default/files/resources/ACPI_6_4_Final_Spec_Jan_30.pdf
 * - QEMU ACPI Implementation: https://wiki.qemu.org/Features/ACPI
 * - VirtualBox ACPI: https://www.virtualbox.org/
 * - HP 250 G3 BIOS Issues: Common knowledge among OS developers
 * 
 * ## Author
 * 
 * LeafOS Development Team
 * Part of the LeafOS kernel project
 */
