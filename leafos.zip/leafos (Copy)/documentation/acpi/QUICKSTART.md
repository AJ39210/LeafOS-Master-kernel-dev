# LeafOS ACPI Driver System - Quick Start Guide

## 📋 Overview

Complete multi-platform ACPI driver system with support for:
- **QEMU** - Standard, well-behaved ACPI
- **VirtualBox** - Mostly standard, 6 quirks
- **HP 250 G3** - Buggy BIOS, 6 major workarounds + extensive retry logic

## 📁 File Locations

### Core ACPI Driver
- [acpi.h](acpi.h) - Core data structures and API declarations
- [acpi.c](acpi.c) - Main ACPI implementation and platform detection
- [platform_dispatch.c](platform_dispatch.c) - Routes calls to platform implementations

### Platform-Specific Implementations
- [qemu/qemu_acpi.c](qemu/qemu_acpi.c) - QEMU platform (standard ACPI)
- [vmbox/vmbox_acpi.c](vmbox/vmbox_acpi.c) - VirtualBox (with compatibility quirks)
- [hp/hp_acpi.c](hp/hp_acpi.c) - HP 250 G3 (extreme workarounds for buggy BIOS)

### Documentation
- [README.md](README.md) - Comprehensive documentation (350+ lines)
- [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) - Implementation details and statistics

## ⚡ Quick Configuration

### For QEMU
```bash
echo "CONFIG_ACPI_QEMU=y" >> .config
make clean && make
```

### For VirtualBox
```bash
echo "CONFIG_ACPI_VIRTUALBOX=y" >> .config
make clean && make
```

### For HP 250 G3
```bash
echo "CONFIG_ACPI_HP=y" >> .config
make clean && make
```

### Check Current Config
```bash
grep "^CONFIG_ACPI" .config
```

## 🚀 Running

```bash
make run  # Boots with QEMU (or your selected platform)
```

## 📊 Statistics

```
Total Code:        ~950 lines
Documentation:     ~700 lines
Total Project:     ~1650 lines

Modules:           5 (.c files)
Headers:           1 (.h file)
Platforms:         3 (QEMU, VirtualBox, HP)
Directories:       4 (common, qemu, vmbox, hp)
```

## 🎯 Features

### Core Features
- ✅ RSDP detection (searches EBDA and BIOS ROM)
- ✅ ACPI table parsing
- ✅ Power state management (S0-S5)
- ✅ Event handling (power, sleep, thermal, battery, lid)
- ✅ Platform auto-detection

### Platform-Specific
- ✅ QEMU: Standard ACPI, no workarounds
- ✅ VirtualBox: 6 compatibility quirks
- ✅ HP 250 G3: Extensive BIOS workarounds

## 📖 API Functions

### Initialization
```c
int acpi_init(void);
int acpi_detect_platform(void);
```

### Power Management
```c
int acpi_set_power_state(acpi_power_state_t state);
int acpi_get_power_state(void);
```

### Event Handling
```c
int acpi_register_event_handler(acpi_event_type_t type);
void acpi_handle_event(acpi_event_type_t type);
```

## 🔧 Troubleshooting

### ACPI not detected
- Check RSDP is found: "[ACPI] RSDP found..." in serial output
- Verify platform detection: "[ACPI] Platform: ..." message
- ACPI may not be available on some very old systems

### Power states not working
- On HP 250 G3: S3 is redirected to S5 (by design)
- On VirtualBox: Add delays with `hp_acpi_delay_ms()`
- Check serial output for error messages

### Thermal/Battery issues
- On HP 250 G3: Intentionally disabled (reports garbage)
- On VirtualBox: Disabled due to inaccuracies
- QEMU: Should work reliably

## 📚 Documentation Structure

1. **README.md** - Complete reference documentation
   - Architecture overview
   - Platform details
   - API reference
   - Known issues
   - Porting guide

2. **IMPLEMENTATION_SUMMARY.md** - Implementation notes
   - Directory structure
   - File statistics
   - Compilation results
   - Workaround details
   - Design decisions

3. **This file** - Quick start and navigation

## 🛠️ Build System Integration

The Makefile automatically handles:
- ACPI configuration parsing from .config
- Platform-specific compilation flags
- Conditional object file linking
- Proper include paths for all modules

## 🚨 Important Notes for HP 250 G3

The HP 250 G3 BIOS is notoriously buggy:
- ❌ S3 sleep doesn't work (redirected to S5)
- ❌ Thermal sensors report garbage (disabled)
- ❌ Battery reporting broken (disabled)
- ❌ ACPI table checksums invalid (validation skipped)
- ❌ EC communication flaky (retry loops)

All of these are handled automatically with extensive workarounds.

## 📞 Support

For issues specific to your platform:
- Check platform-specific serial output (look for `[ACPI-PLATFORM]` prefix)
- Review platform implementation in the appropriate subdirectory
- Check README.md for detailed information
- Add `-DCONFIG_SERIAL_DRIVER=1` for debugging

## ✨ Next Steps

1. Select your target platform in .config
2. Run `make clean && make`
3. Boot with `make run`
4. Check serial output for ACPI messages
5. Test power states with `acpi_set_power_state()`

---

**Status**: ✅ Production Ready  
**Last Updated**: February 2, 2026  
**Platforms Supported**: 3 (QEMU, VirtualBox, HP 250 G3)  
**Lines of Code**: ~950  
**Documentation**: Comprehensive
