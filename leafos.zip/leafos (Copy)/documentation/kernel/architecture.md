# LeafOS Kernel Architecture

## Overview

The LeafOS kernel is built with a modular architecture, separating concerns into distinct compilation units that work together to boot and initialize the system.

## Kernel Modules

### main.c - Kernel Entry Point
- **Purpose**: Primary kernel entry point called by bootloader
- **Responsibility**: Orchestrates initialization sequence
- **Key Functions**: `kernel_main()` - boots the system in phases
- **Initialization Order**:
  1. Serial communication
  2. Memory detection
  3. Virtual filesystem
  4. Boot messages
  5. Filesystems
  6. Kernel complete

### initializer.c - Driver Initialization
- **Purpose**: Initialize all hardware drivers and subsystems
- **Functions**:
  - `kernel_init_serial()` - Initialize serial console for debugging
  - `kernel_init_memory()` - Detect system memory with e820 BIOS calls
  - `kernel_init_vfs()` - Initialize virtual filesystem
  - `kernel_init_filesystems()` - Mount all supported filesystems
- **Responsibility**: Correct initialization sequence and dependency management

### bootmsg.c - Boot Messages
- **Purpose**: Handle all boot-time display output
- **Functions**:
  - `bootmsg_clear_screen()` - Clear VGA display
  - `bootmsg_header()` - Print kernel banner
  - `bootmsg_memory_map()` - Display e820 memory map
  - `bootmsg_multiboot()` - Print multiboot information
  - `bootmsg_status()` - Print system status
  - `bootmsg_drivers()` - List enabled drivers
  - `bootmsg_complete()` - Print completion message
- **Output Targets**: Both VGA text mode and serial console

## Compilation Dependencies

```
boot.s (bootloader stub)
    ↓
main.c (entry point)
    ├── initializer.c (driver init)
    │   ├── ram.c (memory detection)
    │   ├── vfs.c (filesystem)
    │   └── fat*.c, ext2.c, exfat.c (filesystems)
    │
    └── bootmsg.c (display output)
        ├── vga.c (text mode)
        └── serial.c (debug console)
```

## Module Communication

### main.c → initializer.c
- Calls initialization functions in sequence
- Passes control through initialization phases

### main.c → bootmsg.c
- Requests boot messages to be printed
- Coordinates display output

### initializer.c → drivers
- Loads hardware drivers
- Configures hardware resources

### bootmsg.c → drivers
- Uses VGA driver for screen output
- Uses serial driver for console logging

## Data Flow

1. **Bootloader** transfers control to `kernel_main()` in main.c
2. **main.c** calls `kernel_init_serial()` to enable debugging
3. **initializer.c** detects memory and initializes subsystems
4. **bootmsg.c** displays boot information and status
5. **main.c** calls `kernel_init_filesystems()` to mount storage
6. System enters infinite loop in `main.c`

## Future Modularization

Candidates for future module extraction:
- **syscall.c** - System call handler (from main.c)
- **sched.c** - Process scheduler (from main.c)
- **irq.c** - Interrupt handler (could be separate)
- **mm.c** - Memory manager (could be separate from RAM driver)
