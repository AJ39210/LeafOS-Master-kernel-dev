# LeafOS Project Structure

Quick reference for navigating the LeafOS codebase after modular refactoring.

## Directory Layout

```
/home/leafos/leafos/
│
├── boot/                           # Bootloader code
│   └── boot.s                     # Multiboot header & stack setup
│
├── kernel/                         # MODULAR KERNEL COMPONENTS
│   ├── main.c                     # Entry point & boot orchestration
│   ├── initializer.c              # Driver initialization sequence
│   ├── bootmsg.c                  # Boot message & display output
│   ├── kernel.c                   # (DEPRECATED - old monolithic)
│   └── SELeaf/                    # Security module
│       ├── seleaf.h               # Security context & policy structures
│       └── seleaf.c               # MAC implementation
│
├── drivers/                        # Hardware drivers
│   ├── vga/                       # Text mode display
│   │   └── vga.c
│   ├── serial/                    # Serial console
│   │   └── serial.c
│   ├── usb/                       # USB support (optional)
│   │   ├── usb.c
│   │   ├── usb_hid.c
│   │   └── usb_mass_storage.c
│   ├── cdrom/                     # Optical media
│   │   ├── cdrom.c
│   │   └── dvdrom.c
│   ├── ram/                       # Memory detection
│   │   └── ram.c
│   └── vfs/                       # Virtual filesystem
│       └── vfs.c
│
├── fs/                            # MODULAR FILESYSTEMS
│   ├── fat12/
│   │   └── fat12.c
│   ├── fat16/
│   │   └── fat16.c
│   ├── fat32/
│   │   └── fat32.c
│   ├── exfat/
│   │   └── exfat.c
│   └── ext2/
│       └── ext2.c
│
├── include/                       # Header files
│   ├── bootmsg.h                 # Boot messaging
│   ├── initializer.h             # Initialization functions
│   ├── printk.h                  # Printf-like functions
│   ├── string.h                  # String utilities
│   ├── serial.h                  # Serial console
│   ├── ram.h                     # Memory detection
│   ├── vfs.h                     # Virtual filesystem
│   ├── fat12.h, fat16.h, fat32.h, exfat.h, ext2.h  # Filesystems
│   ├── usb.h, usb_hid.h, usb_mass_storage.h  # USB
│   ├── cdrom.h, dvdrom.h         # Optical media
│   └── (individual driver headers)
│
├── lib/                          # Standard libraries
│   └── string.c                 # String manipulation
│
├── documentation/                # COMPREHENSIVE DOCS
│   ├── kernel/
│   │   └── architecture.md      # Kernel module design
│   ├── drivers/
│   │   └── overview.md          # Driver system
│   ├── filesystems/
│   │   └── (future)
│   ├── security/
│   │   ├── seleaf.md            # SELeaf security module
│   │   └── (future)
│   └── build/
│       └── (future)
│
├── build/                        # Build artifacts (generated)
│   ├── *.o                       # Object files
│   ├── kernel.bin                # Final kernel binary
│   └── iso/                      # ISO staging directory
│
├── .config                       # Build configuration
├── Makefile                      # Build system
├── linker.ld                     # Memory layout
├── grub.cfg                      # GRUB bootloader config
│
├── FILESYSTEMS.md                # Filesystem support docs
├── KERNEL_REFACTORING.md         # This refactoring guide
└── leafos.iso                    # Bootable ISO image

```

## Key Files by Purpose

### Boot & Entry Point
- `boot/boot.s` - Bootloader interface (calls kernel_main)
- `kernel/main.c` - Kernel entry point (orchestrates boot)

### Kernel Modules (NEW - MODULAR)
- `kernel/initializer.c` - Initializes all drivers & subsystems
- `kernel/bootmsg.c` - Handles all boot-time display output
- `kernel/SELeaf/seleaf.c` - Security module with MAC

### Drivers
- `drivers/vga/vga.c` - VGA text mode (80x25)
- `drivers/serial/serial.c` - Serial COM1 console
- `drivers/ram/ram.c` - Memory detection via e820
- `drivers/vfs/vfs.c` - Virtual filesystem layer
- `drivers/usb/*` - USB controllers & peripherals
- `drivers/cdrom/*` - CD/DVD support

### Filesystems (MODULAR - ONE PER DIRECTORY)
- `fs/fat12/fat12.c` - Floppy disk support
- `fs/fat16/fat16.c` - Legacy FAT filesystem
- `fs/fat32/fat32.c` - Modern FAT filesystem
- `fs/exfat/exfat.c` - Large file support (>4GB)
- `fs/ext2/ext2.c` - Linux ext2 compatibility

### Configuration & Build
- `.config` - Feature flags (CONFIG_*_DRIVER=y/n, CONFIG_*_FS=y/n)
- `Makefile` - Build system (reads .config)
- `linker.ld` - Kernel memory layout
- `grub.cfg` - Boot menu configuration

### Documentation
- `documentation/kernel/architecture.md` - Kernel design
- `documentation/drivers/overview.md` - Driver subsystem
- `documentation/security/seleaf.md` - Security module (SELinux-like)
- `FILESYSTEMS.md` - Filesystem support details
- `KERNEL_REFACTORING.md` - This refactoring summary

## Build Output

After `make`:
```
build/
├── boot.o              # Bootloader
├── main.o              # Kernel main
├── initializer.o       # Initialization
├── bootmsg.o           # Boot messages
├── seleaf.o            # Security module
├── vga.o, serial.o, ram.o, vfs.o  # Drivers
├── fat12.o, fat16.o, fat32.o, exfat.o, ext2.o  # Filesystems
├── string.o            # Library
├── kernel.bin          # KERNEL BINARY (25KB)
└── iso/                # ISO structure
    └── boot/grub/
        ├── grub.cfg
        └── kernel.bin
```

## How to Navigate Code

### Boot Process
1. `boot/boot.s` - Entry point (from GRUB)
2. `kernel/main.c` - Kernel entry (kernel_main function)
3. `kernel/initializer.c` - Driver initialization
4. `kernel/bootmsg.c` - Display messages

### Driver Interaction
1. Check `kernel/initializer.c` to see initialization order
2. Find specific driver in `drivers/` directory
3. Check `.config` for `CONFIG_*_DRIVER` flag
4. Verify Makefile compilation rule

### Adding New Module
1. Create `kernel/module.c` and `include/module.h`
2. Add compilation rule to Makefile
3. Call from `kernel/main.c`
4. Document in `documentation/kernel/`

### Filesystem Operations
1. Check `kernel/initializer.c` for mounting order
2. Find filesystem in `fs/*/fs.c`
3. Check `.config` for `CONFIG_*_FS` flag
4. Verify VFS integration in `drivers/vfs/vfs.c`

## Configuration Options

### Enable/Disable Features

Edit `.config` to control what gets compiled:

**Display & Debug**:
- `CONFIG_VGA_DRIVER=y` - Text mode display
- `CONFIG_SERIAL_DRIVER=y` - Serial console

**Storage**:
- `CONFIG_CDROM_DRIVER=y` - CD-ROM support
- `CONFIG_DVDROM_DRIVER=y` - DVD support
- `CONFIG_FAT12_FS=y` - Floppy disks
- `CONFIG_FAT16_FS=y` - Legacy USB
- `CONFIG_FAT32_FS=y` - Modern USB
- `CONFIG_EXFAT_FS=y` - Large files
- `CONFIG_EXT2_FS=y` - Linux compat

**Core Drivers**:
- `CONFIG_RAM_DRIVER=y` - Memory detection
- `CONFIG_VFS_DRIVER=y` - Virtual filesystem
- `CONFIG_USB_DRIVER=y` - USB controllers
- `CONFIG_USB_HID=y` - USB keyboard/mouse
- `CONFIG_USB_MASS_STORAGE=y` - USB drives

### Rebuild After Changes

```bash
cd /home/leafos/leafos
make clean        # Remove old binaries
make config       # Show current configuration
make              # Rebuild with new config
make run          # Test in QEMU
```

## Compilation Breakdown

### Kernel Modules (NEW)
- `kernel/main.c` → main.o (1.1KB) - Entry point
- `kernel/initializer.c` → initializer.o (2.2KB) - Initialization
- `kernel/bootmsg.c` → bootmsg.o (3.8KB) - Boot messages
- `kernel/SELeaf/seleaf.c` → seleaf.o (3.2KB) - Security

### Boot & Library
- `boot/boot.s` → boot.o (804B) - Bootloader stub
- `lib/string.c` → string.o (648B) - String library

### Drivers (conditional)
- VGA, Serial, USB, CD/DVD, RAM, VFS

### Filesystems (conditional)
- FAT12, FAT16, FAT32, exFAT, ext2

### Total Kernel Size
- **25KB** - Includes all core modules + default drivers + security

## Modular Architecture Benefits

✅ **Clear Separation of Concerns**
- Each module has single responsibility
- Easy to understand code flow

✅ **Scalability**
- Easy to add new modules
- Pattern for new features established

✅ **Maintainability**
- Changes in one module don't affect others
- Isolated debugging

✅ **Security**
- SELeaf provides MAC layer
- Security policies manageable independently

✅ **Testability**
- Modules can be unit tested
- Mock implementations easier

✅ **Documentation**
- Each module documented separately
- Clear integration points

## Quick Commands

```bash
cd /home/leafos/leafos

# Show configuration
make config

# Build everything
make clean
make

# Boot in QEMU
make run

# Show build structure
tree kernel/
find fs/ -name "*.c"
ls -la build/

# Check compilation flags
grep CFLAGS Makefile | head -20

# View boot messages in real-time
timeout 5 qemu-system-i386 -m 128M -cdrom leafos.iso -serial stdio
```

## Related Documentation

- `FILESYSTEMS.md` - Details on each filesystem
- `KERNEL_REFACTORING.md` - Architecture refactoring guide
- `documentation/kernel/architecture.md` - Kernel module design
- `documentation/drivers/overview.md` - Driver system details
- `documentation/security/seleaf.md` - Security module docs
