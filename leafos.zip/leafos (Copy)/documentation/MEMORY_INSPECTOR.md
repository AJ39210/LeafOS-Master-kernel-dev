# Memory Inspector & Dumper

**Status**: ✅ Fully Implemented

## Overview

The Memory Inspector provides kernel-space memory debugging tools:
- Hexdumps with ASCII representation
- Memory searching and pattern matching
- Checksums and verification
- Core dump capture (64KB max)
- Memory statistics and layout
- Memory range comparison

## Features

### Hexdumps

Display memory in hex and ASCII format:

```
Address  : [hexadecimal] - [hexadecimal] (size bytes)

[addr]: [byte] [byte] [byte] ... | ASCII-representation
[addr]: [byte] [byte] [byte] ... | ASCII-representation
```

### Memory Searching

Find specific byte patterns in memory:
- Pattern matching algorithm
- Limited to prevent hanging
- Up to 10 matches reported
- Useful for finding structures

### Core Dumps

Capture memory snapshot:
- Maximum 64KB per dump
- Stored in kernel memory
- Can be displayed at any time
- Useful for post-mortem analysis

## API Reference

### Memory Hexdump

```c
void mem_hexdump(uint32_t addr, uint32_t size, int line_width);
```

Print hex dump of memory to serial console.

**Parameters:**
- `addr`: Starting address
- `size`: Number of bytes to dump
- `line_width`: Bytes per line (typically 16)

**Example:**
```c
mem_hexdump(0x08048000, 256, 16);  // Dump 256 bytes starting at user space
```

### Memory Searching

```c
uint32_t mem_search(uint32_t search_addr, uint32_t search_size, 
                    uint8_t *pattern, uint32_t pattern_size);
```

Search for byte pattern in memory.

**Returns:** Address of first match, or 0 if not found

**Example:**
```c
uint8_t pattern[] = {0x55, 0x89, 0xE5};  // "push ebp; mov ebp, esp" prologue
uint32_t found = mem_search(0x08048000, 0x10000, pattern, 3);
```

### Memory Statistics

```c
void mem_statistics(void);
```

Print memory layout and statistics to serial:
- Total addressable memory
- Kernel/user space boundaries
- DMA zone
- Page size information

### Memory Comparison

```c
uint32_t mem_compare(uint32_t addr1, uint32_t addr2, uint32_t size);
```

Compare two memory regions.

**Returns:** 0 if identical, offset of first difference if not

**Example:**
```c
uint32_t diff_offset = mem_compare(backup_addr, current_addr, 1024);
if (diff_offset != 0) {
    serial_puts(SERIAL_PORT_A, "Memory changed at offset: ");
    // print diff_offset
}
```

### Memory Operations

```c
void mem_fill(uint32_t addr, uint32_t size, uint8_t value);
```
Fill memory region with byte value.

```c
void mem_copy(uint32_t dest, uint32_t src, uint32_t size);
```
Copy memory region (handles overlap).

```c
uint32_t mem_checksum(uint32_t addr, uint32_t size);
```
Calculate checksum of memory region.

### Core Dump Functions

```c
int memdump_capture_core(uint32_t addr, uint32_t size);
```

Capture memory region for core dump.

**Parameters:**
- `addr`: Starting address
- `size`: Number of bytes (max 64KB)

**Returns:** 0 on success, -1 if size too large

**Example:**
```c
// Capture first 4KB of kernel space
memdump_capture_core(0xC0000000, 4096);
```

```c
void memdump_dump_core(void);
```

Output previously captured core dump to serial console.

### Pattern Scanning

```c
void mem_scan_for_pattern(uint8_t *pattern, uint32_t pattern_size);
```

Scan memory for pattern, reporting all matches (up to 10).

**Limits search to first 256MB to prevent hanging**

## Usage Examples

### Example 1: Dump User Stack

```c
#include "memdump.h"

// Dump 512 bytes of user stack
uint32_t esp = 0xBFFFF000;  // Approximate stack location
mem_hexdump(esp - 256, 512, 16);
```

**Output:**
```
[esp-256]: 0x00 0x00 0xAA 0xBB ... | ...
[esp-240]: 0x12 0x34 0x56 0x78 ... | ...
...
```

### Example 2: Search for String

```c
// Find "LeafOS" in kernel memory
uint8_t pattern[] = {'L', 'e', 'a', 'f', 'O', 'S'};
uint32_t addr = mem_search(0xC0000000, 0x100000, pattern, 6);

if (addr) {
    serial_puts(SERIAL_PORT_A, "Found 'LeafOS' at: 0x");
    // print addr
}
```

### Example 3: Verify Memory Integrity

```c
// Take snapshot of important data
memdump_capture_core(kernel_data_addr, 1024);

// ... do something ...

// Verify it hasn't changed
uint32_t diff = mem_compare(
    kernel_data_addr,           // Current
    kernel_data_backup_addr,    // Original
    1024
);

if (diff != 0) {
    serial_puts(SERIAL_PORT_A, "MEMORY CORRUPTION DETECTED\n");
    kernel_panic("MEMORY_CORRUPTION", "Kernel data modified");
}
```

### Example 4: Memory Checksum

```c
// Calculate checksum of critical section
uint32_t checksum = mem_checksum(0xC0001000, 4096);
serial_puts(SERIAL_PORT_A, "Checksum: ");
// print checksum
```

### Example 5: Core Dump on Error

```c
// In error handler
if (critical_error) {
    // Capture kernel data for analysis
    memdump_capture_core(0xC0000000, 16384);  // 16KB
    
    // Output immediately
    memdump_dump_core();
    
    // Then panic
    kernel_panic("CRITICAL_ERROR", "See core dump above");
}
```

## Memory Layout Reference

### Kernel Space (0xC0000000 - 0xFFFFFFFF)
- Kernel code and data
- Page tables
- Kernel stack
- I/O mappings
- VGA framebuffer

### User Space (0x08048000 - 0xBFFFFFFF)
- Application code (text segment)
- Initialized data (data segment)
- Uninitialized data (bss segment)
- Heap
- Memory mapped files
- Stack

### DMA Zone (0x00000000 - 0x0FFFFFFF)
- Bootloader structures
- Real-mode code
- DMA buffers (must be identity-mapped)

## Serial Output

All memory inspector functions output to COM1 (SERIAL_PORT_A):

### Enabling Serial Output

Serial output is conditional on CONFIG_SERIAL_DRIVER:

```c
#ifdef CONFIG_SERIAL_DRIVER
// Output appears on serial console
mem_hexdump(0x08048000, 256, 16);
#endif
```

### Capturing to File (on host)

```bash
# Monitor serial output
minicom -D /dev/ttyS0 -b 115200 -C dump.log

# Or redirect directly
stty -F /dev/ttyUSB0 115200
cat /dev/ttyUSB0 > memory_dump.txt
```

## Performance Characteristics

| Operation | Time |
|-----------|------|
| Hexdump (256 bytes) | ~100 cycles/byte |
| Memory search | ~10 cycles/byte |
| Core dump capture (16KB) | ~50 µs |
| Checksum (4KB) | ~200 µs |

## Limitations

⚠️ **Current Implementation**:
- Hexdump limited to 64 lines (1KB max at 16 bytes/line)
- Pattern search limited to 10 matches
- Core dump limited to 64KB
- Single core dump buffer (no history)
- Serial-only output (no VGA fallback)
- No symbolic name resolution

## Best Practices

### When to Use Memory Inspector

- Kernel initialization debugging
- Data structure verification
- Memory corruption detection
- Driver development and testing
- Post-panic analysis
- Security validation

### Memory Addresses to Inspect

```
0x00000000 - 0x00100000    Bootloader/DMA structures
0x00100000 - 0xBFFFFFFF    Available for user/drivers
0xC0000000 - 0xC0100000    Kernel code
0xC0100000 - 0xC0200000    Kernel data
0xC0200000 - 0xC0300000    Page tables
0xB8000                    VGA framebuffer
0xC0400000 - 0xFFFFFFFF    Kernel heap/stacks
```

## Future Enhancements

- [ ] Symbolic name resolution
- [ ] Watch expressions (breakpoints on change)
- [ ] Memory breakpoints
- [ ] Persistent core dump to disk
- [ ] Enhanced hexdump with more context
- [ ] Memory profiling/statistics
- [ ] Unwind stack traces
- [ ] Symbol table integration

---

**Related Documentation**:
- [Panic Handler](PANIC_SYSTEM.md)
- [VMM & Paging](VMM_PAGING.md)
- [Syscall API](SYSCALL_API.md)
