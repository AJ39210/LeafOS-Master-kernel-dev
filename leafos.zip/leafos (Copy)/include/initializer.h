#ifndef INITIALIZER_H
#define INITIALIZER_H

#include <stdint.h>

/**
 * kernel/initializer.h
 * Kernel initialization module header
 */

void kernel_init_serial(void);
void kernel_init_memory(void);
void kernel_init_vfs(void);
void kernel_init_filesystems(void);

#endif
