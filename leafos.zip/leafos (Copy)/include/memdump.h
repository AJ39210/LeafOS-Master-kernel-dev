/**
 * include/memdump.h
 * 
 * Memory Inspector and Dumper
 * 
 * Provides memory analysis and debugging utilities:
 * - Hexdumps
 * - Memory searching
 * - Checksums
 * - Core dumps
 */

#ifndef MEMDUMP_H
#define MEMDUMP_H

#include <stdint.h>

/**
 * mem_hexdump()
 * 
 * Print hex dump of memory to serial console
 * 
 * Parameters:
 *   addr: Starting address
 *   size: Number of bytes to dump
 *   line_width: Bytes per line (default 16)
 */
void mem_hexdump(uint32_t addr, uint32_t size, int line_width);

/**
 * mem_search()
 * 
 * Search for byte pattern in memory
 * 
 * Returns: Address of first match, or 0 if not found
 */
uint32_t mem_search(uint32_t search_addr, uint32_t search_size, uint8_t *pattern, uint32_t pattern_size);

/**
 * mem_statistics()
 * 
 * Print memory statistics and layout to serial
 */
void mem_statistics(void);

/**
 * mem_compare()
 * 
 * Compare two memory regions
 * 
 * Returns: 0 if identical, offset of first difference if not
 */
uint32_t mem_compare(uint32_t addr1, uint32_t addr2, uint32_t size);

/**
 * mem_fill()
 * 
 * Fill memory region with byte value
 */
void mem_fill(uint32_t addr, uint32_t size, uint8_t value);

/**
 * mem_copy()
 * 
 * Copy memory region
 */
void mem_copy(uint32_t dest, uint32_t src, uint32_t size);

/**
 * mem_checksum()
 * 
 * Calculate checksum of memory region
 */
uint32_t mem_checksum(uint32_t addr, uint32_t size);

/**
 * memdump_capture_core()
 * 
 * Capture memory region for core dump analysis
 * Limited to 64KB
 * 
 * Returns: 0 on success, -1 if size too large
 */
int memdump_capture_core(uint32_t addr, uint32_t size);

/**
 * memdump_dump_core()
 * 
 * Output captured core dump to serial
 */
void memdump_dump_core(void);

/**
 * mem_scan_for_pattern()
 * 
 * Scan for pattern in memory and report matches
 * Reports up to 10 matches
 */
void mem_scan_for_pattern(uint8_t *pattern, uint32_t pattern_size);

#endif // MEMDUMP_H
