/**
 * include/syscall.h
 * 
 * LeafOS System Call Interface
 * 
 * Provides syscall declarations and constants for:
 * - ATA disk I/O
 * - SATA disk I/O
 * - GPIO operations
 * - Device queries
 */

#ifndef SYSCALL_H
#define SYSCALL_H

#include <stdint.h>

/* ============================================================
   Syscall Numbers
   ============================================================ */

/* ATA Syscalls (0x100-0x10F) */
#define SYS_ATA_READ        0x100    /* Read sectors from ATA drive */
#define SYS_ATA_WRITE       0x101    /* Write sectors to ATA drive */
#define SYS_ATA_IDENTIFY    0x102    /* Identify ATA device */
#define SYS_ATA_DETECT      0x103    /* Detect ATA devices */

/* SATA Syscalls (0x110-0x11F) */
#define SYS_SATA_READ       0x110    /* Read sectors from SATA drive */
#define SYS_SATA_WRITE      0x111    /* Write sectors to SATA drive */
#define SYS_SATA_DETECT     0x112    /* Detect SATA device on port */
#define SYS_SATA_PROBE      0x113    /* Probe all SATA ports */

/* GPIO Syscalls (0x120-0x12F) */
#define SYS_GPIO_CONFIG     0x120    /* Configure GPIO pin */
#define SYS_GPIO_SET        0x121    /* Set GPIO pin state */
#define SYS_GPIO_READ       0x122    /* Read GPIO pin state */
#define SYS_GPIO_TOGGLE     0x123    /* Toggle GPIO pin state */

/* Query Syscalls (0x130-0x13F) */
#define SYS_DISK_INFO       0x130    /* Query disk information */
#define SYS_GPIO_INFO       0x131    /* Query GPIO information */

/* ============================================================
   GPIO Modes
   ============================================================ */
#define GPIO_MODE_INPUT     0        /* Input mode */
#define GPIO_MODE_OUTPUT    1        /* Output/Push-pull */
#define GPIO_MODE_ALTERNATE 2        /* Alternate function */
#define GPIO_MODE_ANALOG    3        /* Analog mode */

/* ============================================================
   GPIO States
   ============================================================ */
#define GPIO_STATE_LOW      0        /* Pin low (0V) */
#define GPIO_STATE_HIGH     1        /* Pin high (3.3V/5V) */

/* ============================================================
   GPIO Ports
   ============================================================ */
#define GPIO_PORT_A         0        /* Port A (PA0-PA15) */
#define GPIO_PORT_B         1        /* Port B (PB0-PB15) */
#define GPIO_PORT_C         2        /* Port C (PC0-PC15) */
#define GPIO_PORT_D         3        /* Port D (PD0-PD15) */
#define GPIO_PORT_E         4        /* Port E (PE0-PE15) */
#define GPIO_PORT_F         5        /* Port F (PF0-PF15) */

/* ============================================================
   Result Structure
   ============================================================ */
typedef struct {
    int32_t result;       /* Return value (-1 on error, >=0 on success) */
    uint32_t error_code;  /* Error code: 0=success, 1=invalid args, 2=operation failed, 255=unknown */
    uint32_t data;        /* Additional data (e.g., GPIO read value) */
} syscall_result_t;

/* ============================================================
   Syscall Functions
   ============================================================ */

/**
 * syscall_dispatch()
 * 
 * Main syscall dispatcher. Routes syscalls to appropriate handlers.
 * 
 * Parameters:
 *   syscall_num: Syscall number
 *   arg0-arg4: Up to 5 arguments (varies by syscall)
 * 
 * Result is stored in global state, retrieve with syscall_get_result()
 */
void syscall_dispatch(uint32_t syscall_num, uint32_t arg0, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);

/**
 * syscall_get_result()
 * 
 * Retrieve the result from the last syscall
 * 
 * Returns: syscall_result_t with result, error_code, and data
 */
syscall_result_t syscall_get_result(void);

/**
 * syscall_init()
 * 
 * Initialize syscall subsystem and all associated drivers
 * Called during kernel initialization
 */
void syscall_init(void);

/* ============================================================
   High-Level Syscall Wrappers (for C programs)
   ============================================================ */

/**
 * ATA disk read wrapper
 * Returns: number of sectors read, or -1 on error
 */
static inline int32_t syscall_ata_read(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    syscall_dispatch(SYS_ATA_READ, channel, drive, lba, count, (uint32_t)buffer);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * ATA disk write wrapper
 * Returns: number of sectors written, or -1 on error
 */
static inline int32_t syscall_ata_write(uint8_t channel, uint8_t drive, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    syscall_dispatch(SYS_ATA_WRITE, channel, drive, lba, count, (uint32_t)buffer);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * SATA disk read wrapper
 * Returns: number of sectors read, or -1 on error
 */
static inline int32_t syscall_sata_read(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    syscall_dispatch(SYS_SATA_READ, port, lba, count, (uint32_t)buffer, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * SATA disk write wrapper
 * Returns: number of sectors written, or -1 on error
 */
static inline int32_t syscall_sata_write(uint32_t port, uint32_t lba, uint16_t count, uint8_t *buffer)
{
    syscall_dispatch(SYS_SATA_WRITE, port, lba, count, (uint32_t)buffer, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * GPIO configure wrapper
 * Returns: 0 on success, -1 on error
 */
static inline int32_t syscall_gpio_configure(uint8_t port, uint8_t pin, uint8_t mode)
{
    syscall_dispatch(SYS_GPIO_CONFIG, port, pin, mode, 0, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * GPIO set wrapper
 * Returns: 0 on success, -1 on error
 */
static inline int32_t syscall_gpio_set(uint8_t port, uint8_t pin, uint8_t state)
{
    syscall_dispatch(SYS_GPIO_SET, port, pin, state, 0, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * GPIO read wrapper
 * Returns: 0 (low), 1 (high), or -1 on error
 */
static inline int32_t syscall_gpio_read(uint8_t port, uint8_t pin)
{
    syscall_dispatch(SYS_GPIO_READ, port, pin, 0, 0, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

/**
 * GPIO toggle wrapper
 * Returns: 0 on success, -1 on error
 */
static inline int32_t syscall_gpio_toggle(uint8_t port, uint8_t pin)
{
    syscall_dispatch(SYS_GPIO_TOGGLE, port, pin, 0, 0, 0);
    syscall_result_t res = syscall_get_result();
    return res.result;
}

#endif // SYSCALL_H
