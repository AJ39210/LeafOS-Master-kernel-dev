/**
 * include/panic.h
 * 
 * Kernel Panic Handler
 * 
 * Displays blue screen with error information and leaf ASCII art
 */

#ifndef PANIC_H
#define PANIC_H

#include <stdint.h>

/* Stop codes */
#define PANIC_KERNEL_ERROR_GENERAL              "KERNEL_ERROR_GENERAL"
#define PANIC_DRIVER_NOT_FOUND_ATA              "DRIVER_ERROR_NOT_FOUND_ATA"
#define PANIC_DRIVER_NOT_FOUND_SATA             "DRIVER_ERROR_NOT_FOUND_SATA"
#define PANIC_DRIVER_NOT_FOUND_GPIO             "DRIVER_ERROR_NOT_FOUND_GPIO"
#define PANIC_DRIVER_INIT_FAILED                "DRIVER_ERROR_INIT_FAILED"
#define PANIC_MEMORY_ALLOCATION_FAILED          "MEMORY_ERROR_ALLOCATION_FAILED"
#define PANIC_SYSCALL_INVALID                   "SYSCALL_ERROR_INVALID"
#define PANIC_PAGE_FAULT                        "PAGE_FAULT_ERROR"
#define PANIC_STACK_OVERFLOW                    "STACK_OVERFLOW_ERROR"
#define PANIC_DOUBLE_FAULT                      "DOUBLE_FAULT_ERROR"

/**
 * kernel_panic()
 * 
 * Trigger kernel panic with custom stop code and reason
 * Displays blue screen with leaf ASCII art
 * 
 * Parameters:
 *   stop_code: Error code name (e.g., "KERNEL_ERROR_GENERAL")
 *   reason: Detailed reason for the panic
 * 
 * Note: This function does NOT return
 */
void kernel_panic(const char *stop_code, const char *reason);

/**
 * kernel_panic_assertion()
 * 
 * Panic on failed assertion
 */
void kernel_panic_assertion(const char *file, int line, const char *condition);

/**
 * kernel_panic_driver_not_found()
 * 
 * Panic when critical driver is not found
 */
void kernel_panic_driver_not_found(const char *driver_name);

/**
 * kernel_panic_allocation_failed()
 * 
 * Panic when memory allocation fails
 */
void kernel_panic_allocation_failed(uint32_t size);

/**
 * kernel_panic_invalid_syscall()
 * 
 * Panic on invalid syscall
 */
void kernel_panic_invalid_syscall(uint32_t syscall_num);

/**
 * kernel_panic_get_status()
 * 
 * Check if kernel is currently in panic state
 * Returns: 1 if panicking, 0 otherwise
 */
int kernel_panic_get_status(void);

/* Convenience macro for assertions */
#define KERNEL_ASSERT(condition) \
    if (!(condition)) { \
        kernel_panic_assertion(__FILE__, __LINE__, #condition); \
    }

#endif // PANIC_H
