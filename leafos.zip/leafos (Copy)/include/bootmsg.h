#ifndef BOOTMSG_H
#define BOOTMSG_H

#include <stdint.h>

/**
 * kernel/bootmsg.h
 * Boot message module header
 */

void bootmsg_clear_screen(void);
void bootmsg_header(void);
void bootmsg_memory_map(void);
void bootmsg_multiboot(unsigned long magic);
void bootmsg_status(void);
void bootmsg_drivers(void);
void bootmsg_complete(void);

#endif
